import { registerModel } from '../utils/common';

export function technologyRouter(app) {
  return (
    [
      {
        path: '/technology',   //技术中心
        //havTop:false,        //是否有头部,默认有
        getComponent(nextState, cb){
          require.ensure([], (require) => {
            registerModel(app, require('../models/technology/Technology'))
            registerModel(app, require('../models/home/Home'))
            cb(null, require('../routes/technology/Technology'))
          },'technology')
        },
        getIndexRoute (nextState, cb) {
          require.ensure([], (require) => {
            registerModel(app, require('../models/technology/Technology'));
            // cb(null, { component:require('../routes/brand/StaticState')}) //静态页面
            cb(null, { component:require('../routes/technology/Dynamic')})  //d
          },'technology/static');
        },
        childRoutes: [
          {
            path: 'safeLabel',   //安全标签搜索页面
            getComponent(nextState, cb) {
              require.ensure([], (require) => {
                registerModel(app, require('../models/technology/Technology'))
                registerModel(app,require('../models/goodsDetail/goodsDetail'));
                cb(null, require('../routes/technology/safeLabel'))
              }, 'technology/safeLabel')
            }
          },
          {
            path: 'safeLabelPrint',   //安全标签打印列表页面
            getComponent(nextState,cb){
            require.ensure([],(require)=>{
              registerModel(app,require('../models/technology/Technology'));
              registerModel(app,require('../models/goodsDetail/goodsDetail'));
              cb(null,require('../routes/technology/safeLabelPrint'))
            },'technology/safeLabelPrint')
            }
         },
          {
            path: 'goodsCMSPrint',   //搜索页面
            getComponent(nextState, cb) {
              require.ensure([], (require) => {
                registerModel(app, require('../models/technology/Technology'))
                registerModel(app,require('../models/goodsDetail/goodsDetail'));
                cb(null, require('../routes/technology/goodsCMSPrint'))
              }, 'technology/goodsCMSPrint')
            }
          },
          {
            path: 'goodsPrintList',   //CMD打印列表页面
            getComponent(nextState,cb){
            require.ensure([],(require)=>{
              registerModel(app,require('../models/technology/Technology'));
              registerModel(app,require('../models/goodsDetail/goodsDetail'));
              cb(null,require('../routes/technology/goodsPrintList'))
            },'technology/goodsPrintList')
            }
        },
        {
            path: 'goodsPrintListMSDS',   //MSDS打印列表页面
            getComponent(nextState,cb){
            require.ensure([],(require)=>{
              registerModel(app,require('../models/technology/Technology'));
              registerModel(app,require('../models/goodsDetail/goodsDetail'));
              cb(null,require('../routes/technology/goodsPrintListMSDS'))
            },'technology/goodsPrintListMSDS')
            }
         },
         {
          path: 'propaganda',   //宣传资料页面
          getComponent(nextState,cb){
          require.ensure([],(require)=>{
            registerModel(app,require('../models/technology/Technology'));
            cb(null,require('../routes/technology/propaganda'))
          },'technology/propaganda')
          }
        },
       {
         path: 'standardMethod',   //方法标准一
         getComponent(nextState,cb){
         require.ensure([],(require)=>{
           registerModel(app,require('../models/technology/Technology'));
           cb(null,require('../routes/technology/standardMethod'))
         },'technology/standardMethod')
         }
       },
       //二级
       {
        path: 'twoStandardMethod',   //
        getComponent(nextState,cb){
        require.ensure([],(require)=>{
          registerModel(app,require('../models/technology/Technology'));
          cb(null,require('../routes/technology/standardMethodTwo'))
        },'technology/twoStandardMethod')
        }
       },
        //三级
        {
          path: 'threeStandardMethod',
          getComponent(nextState,cb){
          require.ensure([],(require)=>{
            registerModel(app,require('../models/technology/Technology'));
            cb(null,require('../routes/technology/threeStandardMethod'))
          },'technology/threeStandardMethod')
          }
         },


        ],

      }
    ]
  )
}
