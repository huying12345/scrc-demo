import { registerModel } from '../utils/common';
//import {request} from "../utils/request";

export function groupRouter(app) {
  return (
    [
      {
        path: 'group/fav/:role',//群组收藏夹
        getComponent(nextState, cb){
          require.ensure([],(require) => {
            registerModel(app, require('../models/group/Fav'))
            cb(null,require('../routes/group/Fav'))
          },'group/fav')
        }
      },
      {
        path: 'group/manageFav',//群组收藏夹
        getComponent(nextState, cb){
          require.ensure([],(require) => {
            registerModel(app, require('../models/group/FavList'))
            cb(null,require('../routes/group/ManageFav'))
          },'group/ManageFav')
        }
      },
      {
        path: 'group/groupFavOpear',//群组收藏夹管理
        getComponent(nextState, cb){
          require.ensure([],(require) => {
            registerModel(app, require('../models/group/GroupFavOpear'))
            cb(null,require('../routes/group/ManageFavOpera'))
          },'group/GroupFavOpear')
        }
      },
      {
        path: 'group/mianManage',//群组主页
        getComponent(nextState, cb){
          require.ensure([],(require) => {
            registerModel(app, require('../models/group/mianManage'))
            cb(null,require('../routes/group/mianManage'))
          },'group/mianManage')
        }
      },
      {
        path: 'group/opproval',//群组审批流管理
        getComponent(nextState, cb){
          require.ensure([],(require) => {
            registerModel(app, require('../models/group/Opproval'))
            cb(null,require('../routes/group/Opproval'))
          },'group/opproval')
        }
      },
      {
        path: 'group/manage',//群组项目管理
        getComponent(nextState, cb){
          require.ensure([],(require) => {
            registerModel(app, require('../models/group/Manage'))
            cb(null,require('../routes/group/Manage'))
          },'group/manage')
        }
      },
      {
        path: 'group/manage-member',//群组成员管理
        getComponent(nextState, cb){
          require.ensure([],(require) => {
            registerModel(app, require('../models/group/ManageMember'))
            cb(null,require('../routes/group/ManageMember'))
          },'group/manageMember')
        }
      },
      {
        path: 'group/opproval-order',//群组订单管理
        getComponent(nextState, cb){
          require.ensure([],(require) => {
            registerModel(app, require('../models/group/OpprovalOrder'))
            cb(null,require('../routes/group/OpprovalOrder'))
          },'group/opprovalOrder')
        }
      },
      {
        path: 'group/manage-order', //群组审批订单
        getComponent(nextState, cb){
          require.ensure([],(require) => {
            registerModel(app, require('../models/group/ManageOrder'))
            cb(null,require('../routes/group/ManageOrder'))
          },'group/manageOrder')
        }
      },
     {
      path: 'group/fund',//群组经费管理
      getComponent(nextState, cb){
       require.ensure([],(require) => {
        registerModel(app, require('../models/group/Fund'))
        cb(null,require('../routes/group/Fund'))
       },'group/fund')
      }
     },
     {
      path: 'group/address',//群组信息管理
      getComponent(nextState, cb){
       require.ensure([],(require) => {
        registerModel(app, require('../models/group/address'))
        cb(null,require('../routes/group/informatManage'))
       },'group/informatManage')
      }
     },
    ]
  )
}
