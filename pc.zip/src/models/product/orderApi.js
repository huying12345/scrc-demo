import { post, get } from '../../utils/request';



export  function goodsbatchlistAPI(obj) {
  return get('/goodsApi/goodsbatchlist',obj);
}



export  function deletePurTemplateItemAPI(itemId) {
  return get('/purtemplateapi/deletePurTemplateItem', { itemId });
}
//保存模板
export  function savePurTemplateAPI(obj) {
  // post(url,values,json)
  return post('/purtemplateapi/savePurTemplate', obj, 'json');
}

export  function getPurTemplateListAPI(obj) {
  return post('/purtemplateapi/getPurTemplateList',obj);
}
//采购模板的内容
export  function getPurTemplateItemAPI(obj) {
  return get('/purtemplateapi/getPurTemplateItem',obj);
}

export  function getPurTemplateItemsListAPI(obj) {
  return post('/purtemplateapi/getPurTemplateItemsList',obj);
}


//批量加入购物车
export  function getAddCartBachAPI(arr) {
   return  post('/tradeApi/addCartBach', { list:arr } , 'json'); 
}

// export  function getAddCartBachAPI(arr) {
// //console.log(arr)
//   return  post('/cartapi/addCartBach', { list:arr } , 'json');  //[{goodsId,goodsNum,newGoodsPrice}]
// }

export  function getRecentPurGoodsAPI(obj) {
  return get('/goods/api/getRecentPurGoods',obj);
}

export  function getGoodsFavoritesAPI(obj) {
  return get('/goods/api/getGoodsFavorites',obj);
}
