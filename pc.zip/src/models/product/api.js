import { post, get } from '../../utils/request';

//提交搜索结果
export function accurateSearchAPI(obj){
  return post('',obj)
}

//获得拼音列表
export function getpinchecklistAPI(){
  return get('')
}

//获得产品推荐
export function getRecommendAPI({page}){
  return get('/indexApi/indexAdvList',{apKey:'recomProducts',...page})
}

//新品上市
export function getNewProductsAPI({page}){
  return get('/indexApi/indexAdvList',{apKey:'newProduct',...page})
}

//促销清仓
export function getPromotionsAPI({page}){
  return get('/indexApi/indexAdvList',{apKey:'salesPromotion',...page})
}

//活动列表
export function getEnrollmentAPI({page}){
  return get('/indexApi/activityEnroll',{...page})
}
//报名活动提交
export  function saveActivityInfoAPI({values}) {
 console.log(values);
 return post('/indexApi/activityInfo',{...values},'json')
}
//报名活动详情
export  function getActivityDetailAPI({activityId}) {
 return get('/indexApi/getActivityDetail',{...activityId},)
}

//精确搜索页面
export function getGoodsListExactAPI(obj){
  return get('/goodsApi/getGoodsListExact',obj)
}

 //广告点击量
 export function clickNumAPI(val){
  return get('/indexApi/clickNum',val)
 }
