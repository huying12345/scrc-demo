import {  goodsbatchlistAPI,deletePurTemplateItemAPI, savePurTemplateAPI, getPurTemplateListAPI, getPurTemplateItemAPI, getPurTemplateItemsListAPI, getAddCartBachAPI, getRecentPurGoodsAPI, getGoodsFavoritesAPI,getStoreorglistAPI } from './orderApi';
import { routerRedux } from 'dva/router';
import { message, Icon } from 'antd';
import {isLogin} from '../../utils/request';
import pathToRegexp from 'path-to-regexp';

export default {
  namespace:'purchase',
  state:{
    goodsbatchlist:[],
    PurTemplateList:[],
    selectData:[],
    storeOrgListData:[],
    PurTemplateItem:{
      templateId:'',
      data:[],
      totalRows:0,
      pageNo:1,
      pageSize:10
    },
    RecentPurGoods:{
      storeId:'',
      goodsName:'',
      dataType:'',
      data:[],
      totalRows:0,
      pageNo:1,
      pageSize:10
    }
  },
  effects:{

    *goodsbatchlistEFF({ obj },{ put, call }){
      const data=yield call( goodsbatchlistAPI, obj );
      console.log(data)
      if(data.result==1){
        yield put({type: 'addList', reducesObj:{ goodsbatchlist: data.data }});
      }else{
        message.error(data.msg,1.5,()=>{});
      }
    },

    *savePurTemplateEFF({ obj },{ put, call }){
      const data=yield call( savePurTemplateAPI, obj );
      if(data.result==1){
        // yield put({type: 'addList', goodsbatchlist: data.data});
        message.success(data.msg,1.5,()=>{});
        yield put({ type: 'getPurTemplateListEFF'});
      }else{
        message.error(data.msg,1.5,()=>{});
      }
    },

    *getAddCartBachEFF({ arr },{ put, call }){
      const data=yield call( getAddCartBachAPI, arr );
      if(data.result==1){
        yield put({type: 'app/getcartCountEFF'});
        // yield put({type: 'app/cartCount', preload: data});
        // yield put({type: 'addList', goodsbatchlist: data.data});
        message.success(data.msg,1.5,()=>{});
      }else{
        message.error(data.msg,1.5,()=>{});
      }
    },


    *getPurTemplateListEFF({ obj },{ put, call }){
      const data=yield call( getPurTemplateListAPI, obj );
      if(data.result==1){
        yield put({type: 'addList', reducesObj:{
          PurTemplateList: data.data,
          PurTemplateItem:{
            templateId:'',
            data:[],
            totalRows:0,
            pageNo:1,
            pageSize:10
          }
        }});
      }else{
        message.error(data.msg,1.5,()=>{});
      }
    },
    *getPurTemplateItemEFF({ obj },{ put, call, select }){
      const purchase = yield select(state => state.purchase);
      console.log(purchase)
      const { templateId, pageNo, pageSize  } = purchase.PurTemplateItem;
      const data=yield call( getPurTemplateItemAPI, { templateId, pageNo, pageSize, ...obj } );
      if(data.result==1){
        yield put({type: 'PurTemplateItem', obj: { data:data.data, totalRows:data.totalRows, ...obj }});
      }else{
        message.error(data.msg,1.5,()=>{});
      }
    },

    *deleteSelectEEF({ itemId },{ put, call ,select}){
      console.log(itemId)
      const data=yield call( deletePurTemplateItemAPI, itemId );
      console.log(data)
      if(data.result==1){
         message.success(data.msg,1.5,()=>{});
        //  yield put({type: 'addTemplateId', });
         yield put({type: 'getPurTemplateItemEFF', reducesObj:{ goodsbatchlist: data.data }});
      }else{
        message.error(data.msg,1.5,()=>{});
      }
    },


    *getPurTemplateItemsListEFF({ obj },{ put, call }){
      const data=yield call( getPurTemplateItemsListAPI, obj );
      if(data.result==1){
        // yield put({type: 'addList', goodsbatchlist: data.data});
      }else{
        message.error(data.msg,1.5,()=>{});
      }
    },

   

  


    *getStoreorglistEFF({ },{ put, call }){
      const data=yield call( getStoreorglistAPI);
      if(data.result==1){
        yield put({ type: 'storeorglist', list:data });
      }else{
        message.error(data.msg,1.5,()=>{});
      }
    },

    // *deleteSelectEEF({ obj },{ put, call }){
    //   const data=yield call( goodsbatchlistAPI, obj );
    //   console.log(data)
    //   if(data.result==1){
    //     yield put({type: 'addList', reducesObj:{ goodsbatchlist: data.data }});
    //   }else{
    //     message.error(data.msg,1.5,()=>{});
    //   }
    // },
 



  },

  subscriptions: {
    setup({ dispatch, history }) {
      return history.listen(({ pathname, query }) => {
        //dispatch({ type: 'userAddressListEFF',});
       
        // if (pathname=='/person/purchaseTemplet'||pathname=='person/purchaseTemplet') {
        if (pathname=='/presonAccount/purchaseTemplet'||pathname=='presonAccount/purchaseTemplet') {
           dispatch({ type: 'getPurTemplateListEFF',});       
        }
      });
    }
  },

  reducers:{
    addList(state,{ reducesObj }){
      return {
        ...state,
        ...reducesObj
      }
    },



    addSelectData(state,{ arr }){

      return {
        ...state,
        selectData:[...state.selectData, ...arr]
      }
    },

    PurTemplateItem(state,{ obj }){
       
      return {
        ...state,
        PurTemplateItem:{...state.PurTemplateItem, ...obj}
      }
    },
    addTemplateId(state,{ obj }){
      return{
         ...state,
         PurTemplateItem:{...state.PurTemplateItem, ...obj}
      }
      console.log(PurTemplateItem)
    },

    // deleteSelect(state,{idarr}){
    //   const arr=state.selectData;
    //   let data=arr.filter((i,index)=>{
    //     return idarr.indexOf(i.goodsId)==-1;
    //   })
    //   // console.log(data)
    //   return {
    //     ...state,
    //     selectData:data
    //   }
    // },
    
    deleteSelect(state,{idarr}){
      const arr=state.selectData;
      let data=arr.filter((i,index)=>{
        console.log(idarr.indexOf(i.goodsId))
        return idarr.indexOf(i.goodsId)==-1;
      })
     console.log(data)
      return {
        ...state,
        selectData:data
      }
    },

    storeorglist(state,{list}){
      const {data} = list;
      return {
        ...state,
        storeOrgListData:data
      }
    }

  }
}
