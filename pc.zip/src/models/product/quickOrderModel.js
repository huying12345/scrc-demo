import {  goodsbatchlistAPI, savePurTemplateAPI, getPurTemplateListAPI, getPurTemplateItemAPI, getPurTemplateItemsListAPI, getAddCartBachAPI, getRecentPurGoodsAPI, getGoodsFavoritesAPI} from './orderApi';
import { routerRedux } from 'dva/router';
import { message, Icon } from 'antd';
import {isLogin} from '../../utils/request';
import pathToRegexp from 'path-to-regexp';

export default {
  namespace:'QuickOrder',
  state:{
    goodsbatchlist:[],
    PurTemplateList:[],
    selectData:[],
    haveData:[],
   
    PurTemplateItem:{
      templateId:'',
      data:[],
      total:0,
      pageNo:1,
      pageSize:10
    },
    RecentPurGoods:{
      storeId:'',
      goodsName:'',
      dataType:'',
      data:[],
      total:0,
      pageNo:1,
      pageSize:10
    }
  },
  effects:{

    *goodsbatchlistEFF({ obj },{ put, call }){
      const data=yield call( goodsbatchlistAPI, obj );
      if(data.result==1){
        console.log(data)
        yield put({type: 'addList', reducesObj:{ goodsbatchlist: data.data }});
      }else{
        message.error(data.msg,1.5,()=>{});
      }
    },

    *savePurTemplateEFF({ obj },{ put, call }){
      const data=yield call( savePurTemplateAPI, obj );
      if(data.result==1){
       // yield put({type: 'addList', goodsbatchlist: data.data});
       yield put({ type:'deleteAllList' });
        message.success(data.msg,1.5,()=>{});
      }else{
        message.error(data.msg,1.5,()=>{});
      }
    },
   //批量加入购物车
    *getAddCartBachEFF({ arr },{ put, call }){
      const data=yield call( getAddCartBachAPI, arr );
      if(data.result==1){

        yield put({ type:'deleteAllList' });
        yield put({ type:'app/getcartCountEFF' });
        message.success(data.msg,1.5,()=>{});
      }else{
        message.error(data.msg,1.5,()=>{});
      }
    },

    //删除模板
    *getPurTemplateListEFF({ obj },{ put, call }){
      const data=yield call( getPurTemplateListAPI, obj );
      if(data.result==1){
         yield put({type: 'addList', reducesObj:{
           PurTemplateList: data.data,
           PurTemplateItem:{
             templateId:'',
             data:[],
             total:0,
             pageNo:1,
             pageSize:10
           }
         }});
      }else{
        message.error(data.msg,1.5,()=>{});
      }
    },
    *getPurTemplateItemEFF({ obj },{ put, call, select }){
      const QuickOrder = yield select(state => state.QuickOrder);
      const { templateId, pageNo, pageSize  } = QuickOrder.PurTemplateItem;
      const data=yield call( getPurTemplateItemAPI, { templateId, pageNo, pageSize, ...obj } );
      // console.log(data)
      if(data.result==1){
         yield put({type: 'PurTemplateItem', obj: { data:data.data,total:data.totalRows, ...obj }});
      }else{
        message.error(data.msg,1.5,()=>{});
      }
    },


    *getPurTemplateItemsListEFF({ obj },{ put, call }){
      const data=yield call( getPurTemplateItemsListAPI, obj );
      if(data.result==1){
        // yield put({type: 'addList', goodsbatchlist: data.data});
      }else{
        message.error(data.msg,1.5,()=>{});
      }
    },

    *getRecentPurGoodsEFF({ obj },{ put, call, select }){
      // console.log("aaaa")
      const QuickOrder = yield select(state => state.QuickOrder);
      const {  storeId, goodsName, dateType, pageNo, pageSize  } = QuickOrder.RecentPurGoods;
      //console.log(4);
      const data=yield call( getRecentPurGoodsAPI, { storeId, goodsName, dateType, pageNo, pageSize, ...obj });
      if(data.result==1){
        // message.success(data.msg,1.5,()=>{});
        yield put({type: 'addList', reducesObj:{
          RecentPurGoods:{
            storeId,
            goodsName,
            dateType,
            pageNo,
            pageSize,
            ...obj,
            data:data.data,
            total:0,
          }
        }});
      }else{
        message.error(data.msg,1.5,()=>{});
      }
    },

  },

  subscriptions: {
    setup({ dispatch, history }) {
      return history.listen(({ pathname, query }) => {

        // if (pathname.startsWith('/product/quickOrder') ) {
        //   if(!isLogin()){
        //     // window.location.href = 'login';
        //     console.log('11111')
        //     message.error('请先登录账号')
        //   }else{
        //     console.log('2222')
        //   }
        // }
      });
    }
  },

  reducers:{
    addList(state,{ reducesObj }){
      //单个加入商品
      return {
        ...state,
        ...reducesObj
      }
    },
    deleteAllList(state,{ }){
      //清空所有商品
      return {
        ...state,
        selectData:[],
      }
    },

    addressItem(state,{ addressitem }){
      return {
        ...state,
        addressitem
      }
    },

    addSelectData(state,{ arr }){
      console.log(arr)
      let oldArr=state.selectData;
      // console.log(oldArr)
      let newArr=[];
      let haveArr=[];
      if(oldArr.length>0){
        oldArr.forEach((i,index)=>{
            arr.forEach((good,ind)=>{
                if(i.goodsErpCode==good.goodsErpCode){
                  arr.splice(arr.indexOf(arr[ind]),1)
                  //  console.log(good)
                   haveArr.push(good)
                }else {
                    //  message.error(good.goodsCode+'已经加入购物清单',1.5);
                }
            })
                     
         })
         newArr=arr

      }else{
        newArr=arr
      }
      // console.log(newArr)
      console.log(haveArr)
      return {
        ...state,
        selectData:[...state.selectData, ...newArr],
        haveData:[...haveArr]
      }
    },

    PurTemplateItem(state,{ obj }){
     console.log(obj)
      return {
        ...state,
        PurTemplateItem:{...state.PurTemplateItem, ...obj}
      }
    },

    deleteSelect(state,{idarr}){
      const arr=state.selectData;
      let data=arr.filter((i,index)=>{
        console.log(idarr.indexOf(i.goodsId))
        return idarr.indexOf(i.goodsId)==-1;
      })
     console.log(data)
      return {
        ...state,
        selectData:data
      }
    },

 

  }
}
