import {  get,post } from '../../utils/request';

export  function getReturnList(values) {
  return get('/orderApi/returnList',values);
}


//六级导航
export function getNavListSide(val){
  return get('/indexApi/getNavigationList',val)
}

//公路提货网点列表
export function getInfoListAPI(){
  return get('')
}

//默认页面
export function getDefaultInfoAPI(){
  return get('')
}

//公路提货网点详情
export function getNetworkDetailsAPI(id){
  return get('',{id})
}
