import { message } from 'antd'
import { routerRedux } from 'dva/router';
import { pointAPI } from './memberApi'

export default {
  namespace: 'point',
  state: {
   total:0,
   pageNo:0,
   pageSize:0
  },
  effects: {
   //积分信息
   *pointEFF({val}, {put, call}){
    //console.log(val)
    const data=yield call(pointAPI,val)
    if(data.result==1) {
     yield put({ type: 'setInfor',data})
    }else{
     message.error(data.msg,1.5,()=>{})
    }
   },
  },
  subscriptions: {
    setup({ dispatch, history }){
      return history.listen(({ pathname, query }) => {
        if(pathname == '/presonAccount/point'){
           dispatch({ type: 'pointEFF',val:{pageNo:1,pageSiza: 10} })
        }
      })
    }
  },
  reducers: {
   setInfor(state, {data}){
    return {
     ...state,
     data,
     total:data.count ? data.count : 0,
     pageNo:data.pageNo ? data.pageNo : 0,
     pageSize:data.pageSize ? data.pageSize : 0
    }
   }
  }
}
