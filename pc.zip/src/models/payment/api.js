
import { post, get } from '../../utils/request';
// 去支付
export function goPayAPI(val){
 return get('/orderApi/getOrderPay',val)
}
