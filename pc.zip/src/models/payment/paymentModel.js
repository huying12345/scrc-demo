import { goPayAPI} from './api';
import { routerRedux } from 'dva/router';
import { message, Icon } from 'antd';
import { compare } from '../../utils/common';
import pathToRegexp from 'path-to-regexp';

export default {
 namespace:'payment',
 state:{
  saveOrderDate:[]
 },
 effects:{
//去支付
  *getPayInfoEFF({val},{ put, call}){
   const data=yield call( goPayAPI, val)
   if(data.result==1) {
    yield put({type: 'saveOrder', preload: data.data})

   }else{
    message.error(data.msg,1.5,()=>{});
   }
  }
 },
 subscriptions: {
  setup({dispatch, history}) {
   return history.listen(({pathname, query}) => {
    let orderId = sessionStorage.getItem("orderId")
    console.log(pathname.startsWith("/payment/W"))
    if(pathname.startsWith("/payment/W")){
     dispatch({ type: 'getPayInfoEFF',val: {orderId}});
    }
   });
  }
 },
 reducers:{
  //保存订单后的数据
  saveOrder(state, {preload}) {
   return {
    ...state,
    saveOrderDate: preload
   }
  }
 }
}
