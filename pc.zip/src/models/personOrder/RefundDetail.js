import pathToRegexp from 'path-to-regexp';
import {message} from 'antd';
import {getReturnDetailAPI,refundOrderAPI,cancelRefundAPI} from './RefundDetailApi'
import {routerRedux} from 'dva/router';
export default {
	namespace: 'refundDetail',
	state: {
		  refundDetailData: {}
	  },
  effects: {
	  *getReturnDetailEFF({val}, {call, put}){
    const data = yield call(getReturnDetailAPI, val);
    if (data.result == 1) {
     yield put({type: 'ReturnDetail', refundDetailData: data});
    } else {
     message.error(data.msg, 1.5, () => {
     });
    }
   },
   *refundOrderEFF({obj},{ put, call, select }){
    const {refundId}=yield select(state=>state.refundDetail.refundDetailData);
    const data=yield call(refundOrderAPI, {refundId,...obj})
    if(data.result==1){
     yield put(routerRedux.push({
      pathname:`/personOrder/refundDetail/${refundId}`
     }))
     message.success(data.msg,1.5,()=>{});
    }else{
     message.error(data.msg,1.5,()=>{});
    }
   },
   *cancelRefundEEF({refundId}, {put, call}) {
    const data = yield call(cancelRefundAPI, refundId)
    if (data.result == 1) {
     message.success('取消退货成功', 3, () => {});
     yield put(routerRedux.push({
      pathname:`/personOrder/refundList`
     }))
    } else {
     message.error(data.msg, 3, () => {
     });
    }
   }
  },
 subscriptions: {
  setup({dispatch, history}) {
   return history.listen(({pathname, query}) => {
    const match = pathToRegexp('/personOrder/refundDetail/:id').exec(pathname);
    if (match && match[0].startsWith('/personOrder/refundDetail')) {
     dispatch({type: 'getReturnDetailEFF', val:{refundId: match[1]}})
    }
   });
  }
 },
 reducers: {
  ReturnDetail(state, {refundDetailData}){
   const {data} = refundDetailData
   return {
    ...state,
    refundDetailData: data[0] || {}
   }
  }
 }
}
