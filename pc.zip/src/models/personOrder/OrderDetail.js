import pathToRegexp from 'path-to-regexp';
import {message} from 'antd';
import {getOrderDetail, addCart, getAddCartBachAPI, cancleOrder,checkOrderAPI,finishorderAPI,getBankAccountAPI} from "./MyOrderApi";
import {routerRedux} from 'dva/router';

export default {
 namespace: 'orderDetail',
 state    : {
  personOrdeDetailData: [],
  dosageFormGoodsNum  : 0,
  isButton            : '',
  getBankAccountData  : [],

 },
 effects: {
  * getOrderDetailEFF({orderId}, {put, call}) {
   const data = yield call(getOrderDetail, {orderId: orderId});
   if (data.result == 1) {
    yield put({type: 'OrderDetail', OrderDetailData: data});
   } else {
    message.error(data.msg, 1.5, () => {
    });
   }
  },
  * getOrderDetailEFF2({orderId}, {put, call}) {
    const data = yield call(getOrderDetail, orderId);
    if (data.result == 1) {
     yield put({type: 'OrderDetail2', OrderDetailData: data});
    } else {
     message.error(data.msg, 1.5, () => {
     });
    }
   },
  * addCartEFF({val}, {put, call}) {
   const data = yield call(addCart, val);
   if (data.result == 1) {
    message.success(data.msg, 1.5);
    yield put({type: 'app/getcartCountEFF', preload: data});
   } else {
    message.error(data.msg, 1.5, () => {
    });
   }
  },
  * getAddCartBachEFF({arr}, {put, call}) {
   const data = yield call(getAddCartBachAPI, arr);
   if (data.result == 1) {
    yield put({type: 'app/getcartCountEFF', preload: data});
    message.success(data.msg, 1.5, () => {
    });
   } else {
    message.error(data.msg, 1.5, () => {
    });
   }
  },
  * cancleOrderEFF({val}, {put, call}) {
   let   orderSn = val.orderSn
   let   orderId = val.orderId
   const data    = yield call(cancleOrder, {orderSn: val.orderSn, cancelReason: val.cancelReason});
   if (data.result == 1) {
    yield put({type: 'cancleOrder', orderSn})
    message.success(data.msg, 1.5);
    if (orderId) {
     yield put(routerRedux.push({
      pathname: `/personOrder/orderDetail/${orderId}`
     }))
    }
   } else {
    message.error(data.msg, 1.5, () => {
    });
   }
  },
  * checkOrderEFF({val}, {put, call}) {
     const data = yield call(checkOrderAPI, val);
     if (data.result == 1) {
        message.success(data.msg, 1.5, () => {
      });
     } else {
        message.error(data.msg, 1.5, () => {
      });
     }
    },
    * finishorderEFF({orderId}, {put, call}) {
      const data = yield call(finishorderAPI,{orderId} );
      if (data.result == 1) {
         message.success(data.msg, 1.5, () => { });
         yield put({type: 'getOrderDetailEFF', orderId: orderId})
      } else {
         message.error(data.msg, 1.5, () => {
       });
      }
    },
    * getBankAccountEFF({ }, {put, call, select}) {
       const data = yield call(getBankAccountAPI, );

      if (data.result == 1) {
         yield put({type: 'getBankAccountData', preload: data});
      } else {
       message.error(data.msg, 1.5, () => {
       });
      }
     },
 },
 subscriptions: {
  setup({dispatch, history}) {
   return history.listen(({pathname, query}) => {
    const match     = pathToRegexp('/personOrder/orderDetail/:cartId').exec(pathname);
    const matchType = pathToRegexp('/personOrder/orderDetailtype/:cartId').exec(pathname);
    if (match && match[0].startsWith('/personOrder/orderDetail')) {
     dispatch({type: 'getOrderDetailEFF', orderId: match[1]})
     dispatch({type: 'getBankAccountEFF'});
    }
    //群组用户的按钮显示，根据路径
    if (matchType && matchType[0].startsWith('/personOrder/orderDetailtype')) {
      dispatch({type: 'getOrderDetailEFF2',orderId:{  isButton: 'isButton', orderId : matchType[1]}})
    }


   })
  }
 },
 reducers: {
  OrderDetail(state, {OrderDetailData}) {
   const {data}          = OrderDetailData;
   let   dosageFormGoods = data[0].orderItemsList.filter((goods, index) => {
    return goods.dosageForm == "0"
   })
   console.log(dosageFormGoods)
   return {
    ...state,
    personOrdeDetailData: data,
    dosageFormGoodsNum  : dosageFormGoods.length
   }
  },
  OrderDetail2(state, {OrderDetailData}) {
   const {data,isButton} = OrderDetailData;
   let   dosageFormGoods = data[0].orderItemsList.filter((goods, index) => {
    return goods.dosageForm == "0"
   })
   console.log(dosageFormGoods)
   return {
    ...state,
    personOrdeDetailData: data,
    dosageFormGoodsNum  : dosageFormGoods.length,
    isButton            : isButton,
   }
  },
  cancleOrder(state, {orderSn}) {
   let data = [...state.personOrdeDetailData]
   data.forEach(item => {
    if (item.orderSn == orderSn) {
     item.orderState     = 7
     item.orderStateMemo = '订单已取消'
    }
   })
   return {
    ...state,
    personOrdeDetailData: data
   }
  },
    getBankAccountData(state, {preload}) {
     const { data} = preload
     return {
      ...state,
      getBankAccountData: data,
     }
    },
 }
}
