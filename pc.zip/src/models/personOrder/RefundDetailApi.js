import { get } from '../../utils/request';

export function getReturnDetailAPI(val){
 return get('/orderApi/returnDetail',val);
}

export function refundOrderAPI(obj){
 return get('/orderApi/refundOrder', obj)
}

//取消退货
export function cancelRefundAPI(refundId){
 return get('/orderApi/cancelRefund',{refundId});
}
