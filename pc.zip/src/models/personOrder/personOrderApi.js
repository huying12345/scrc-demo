//订单结算接口
import { post, get } from '../../utils/request';

//订单结算
export function subCartToOrder(cartIds,activityIds){
 return post('/tradeApi/subCartToOrder',{cartIds,activityIds})
}


//提交订单
export function saveOrderForSinopharmAPI(value){
 console.log(value)
    return post('/orderApi/saveOrderForSinopharm',value , 'json');
}
//保存收货地址信息
export function saveAddressAPI( value ){
    return get('/tradeApi/saveOrderAddress',value)
}

//设置默认地址
export function setDefaultAddressAPI( orderAddressId ){
    return get('/tradeApi/saveDefaultOrderAddress', {orderAddressId} )
}
//删除地址deleteOrderAddress
export function deleteOrderAddressAPI( addressId ){
 return get('/tradeApi/deleteOrderAddress', addressId )
}
//获取地区数据
export function getArea(){
 return post('/dictApi/areaList')
}
//getOrderAddressList获取收货地址列表
export function getOrderAddressListApi(){
 return post('/tradeApi/getOrderAddressList')
}
//getOrderInvoiceList获取发票列表
export function getOrderInvoiceListApi(cartIds){
 return post('/tradeApi/getOrderInvoiceList',{cartIds})
}
export function getOrderInvoiceList2Api(memberType){
 return post('/tradeApi/getOrderInvoiceList',{memberType})
}

//选择配送方式 getDeliveryMethod
export function getDeliveryMethodAPI( value ){
 return post('/tradeApi/getDeliveryMethod',value,"json")
}
//保存发票信息saveOrderInvoice
export function saveOrderInvoiceAPI( value ){
 console.log(value)
 return post('/tradeApi/saveOrderInvoice',value,'json')
}
//获取支付方式 paymentList
export function getPaymentListAPI( values ){
 return post('/tradeApi/paymentList',values)
}
// 非网销用户结算页面，银行转账的汇款账户信息
export function getBankAccountAPI(values) {
 return post('/orderApi/getBankAccount', values)
}

//保存收货地址信息
export function saveAddressGroupAPI( value ){
 return get('/groupApi/saveAddress',value)
}
//弹框获取收货地址信息
export function modalAddressListGroupAPI( value ){
 return get('/groupApi/getOrderAddressList',value)
}
// 页面的地址列表：tradeApi/getOrderAddressList
export function pageAddressListGroupAPI( value ){
 return get('/tradeApi/getOrderAddressList',value)
}
// 项目列表  /groupApi/objectList   type 1 项目列表 2 经费列表
//群组列表
export function objectListAPI( obj ){
 return post('/groupApi/objectList',obj)
}
export function approvalsListAPI( obj ){
 return post('/groupApi/groupApprovalsList',obj)
}
//getOrderInvoiceList获取群组发票列表
export function getOrderInvoiceListGroupApi(obj){
 return post('/tradeApi/getOrderInvoiceList',obj)
}
// /orderApi/getBankAccount
