import {message} from 'antd';
import {returnListApi,cancelRefundAPI} from './RefundListApi';

export default {
	namespace: 'refundList',
	state: {
		personConsultListData: [],
		consultListTotal: 1,
		refundListData:[],
  pageSize: 10,
  pageNo: 1
    },
	effects: {
		//退货申请列表
		*returnListEEF({payload}, {put, call}) {
			const data = yield call(returnListApi,payload);
			if (data.result == 1) {
			 yield put({type: 'getReturnList', preload: data});
			} else {
			 message.error(data.msg, 1.5, () => {
			 });
			}
		},
  //取消退货
  *cancelRefundEEF({refundId}, {put, call}) {
   let Id = refundId
   const data = yield call(cancelRefundAPI, refundId)
   if (data.result == 1) {
    message.success('取消退货成功', 3, () => {});
    yield put({type: 'cancelRefund', refundId: Id});
   } else {
    message.error(data.msg, 3, () => {});
   }
  }
	},
	subscriptions: {
		setup({dispatch, history}) {
			return history.listen(({pathname, query}) => {
			 if (pathname === '/personOrder/refundList') {
			  dispatch({type: 'returnListEEF'});
			 }
			});
		}

	},
	reducers: {

		getReturnList(state, {preload}) {
			const {data} = preload;
			return {
			 ...state,
			 refundListData: data,
    consultListTotal: preload.total || 1,
    pageSize: preload.pageSize,
    pageNo: preload.pageNo
			}
		},
  cancelRefund(state, {refundId}){
   let data = [...state.refundListData]
   let newData = []
   data.forEach(item => {
    if(item.refundId != refundId){
     newData.push(item)
    }
   })
   return {
    ...state,
    refundListData: newData
   }
  }
	}
}
