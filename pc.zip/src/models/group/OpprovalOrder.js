import { routerRedux } from 'dva/router';
import { message, Icon } from 'antd';
import pathToRegexp from 'path-to-regexp';
import {groupOrderListAPI} from "../group/groupApi";
import {getAreaData} from "../../utils/getArea";

export default {
  namespace: 'opprovalOrder',
  state: {
    checkAll: false,
    groupOrderCheckListData:[],
    count:1,
    pageNo:1,
    pageSize: 10,
    orderIds:'',

  },
  effects: {
    *groupOrderCheckListEFF({ val},{put,call}){
      const data = yield call(groupOrderListAPI,{pageSize:10,...val});
      // console.log(data)
      if(data.result == 1){
         yield put({type: 'groupOrderCheckList', groupOrderCheckListData: data});
      }else{
         message.error(data.msg,1.5,()=>{});
      }
     },
  },
  subscriptions: {
    setup({ dispatch, history }) {
      return history.listen(({ pathname, query }) => {
        if (pathname == '/group/opproval-order') {
          dispatch({ type: 'groupOrderCheckListEFF' });
        }
      })
    }
  },
  reducers: {
    groupOrderCheckList(state, { groupOrderCheckListData }) {
      const { data,count,pageNo ,orderIds } = groupOrderCheckListData
      return {
        ...state,
        groupOrderCheckListData: data,
        pageNo:pageNo,
        count:count,
        orderIds:orderIds,

      }
    },
  }
}
