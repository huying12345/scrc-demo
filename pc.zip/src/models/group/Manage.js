import { routerRedux } from 'dva/router';
import { message, Icon } from 'antd';
import pathToRegexp from 'path-to-regexp';
import {objectListAPI,groupObjectAPI,getGroupMemberListAPI} from "../group/groupApi";
import {getAreaData} from "../../utils/getArea";

export default {
  namespace: 'manage',
  state    : {
    checkAll              : false,
    objectListListData    : [],
    groupObjectData       : [],
    getGroupMemberListData: [],
    count                 : 0,
    pageNo                : 1,
  },
  effects: {
  *objectListListEFF({ val},{put,call}){
      const data = yield call(objectListAPI,val);
      // console.log(data)
      if(data.result == 1){
         yield put({type: 'objectList', objectListListData: data});
      }else{
         message.error(data.msg,1.5,()=>{});
      }
     },
       //群组项目管理
     *groupObjectEFF({ val},{put,call}){
      const data = yield call(groupObjectAPI,val);
      // console.log(data)
      if(data.result == 1){
        //  yield put({type: 'groupObject', groupObjectData: data});
         yield put({type: 'objectListListEFF'});
      }else{
         message.error(data.msg,1.5,()=>{});
      }
     },
     *getGroupMemberListEFF({ val},{put,call}){
      const data = yield call(getGroupMemberListAPI,val);
      // console.log(data)
      if(data.result == 1){
         yield put({type: 'getGroupMemberList', getGroupMemberListData: data});
      }else{
         message.error(data.msg,1.5,()=>{});
      }
     },

  },
  subscriptions: {
    setup({ dispatch, history }) {
      return history.listen(({ pathname, query }) => {
        if (pathname == '/group/manage') {
          dispatch({ type: 'objectListListEFF' });
          dispatch({ type: 'getGroupMemberListEFF',val:{type:1} });
        }
      })
    }
  },
  reducers: {
    objectList(state, { objectListListData }) {
      const { data,count,pageNo  } = objectListListData
      return {
        ...state,
        objectListListData: data,
        pageNo            : pageNo,
        count             : count,
      }
    },
    getGroupMemberList(state, { getGroupMemberListData }) {
      const { data } = getGroupMemberListData
      // console.log(data)
      data.forEach((val,index)=>{
          if(val.isContact=='0'){//0是未关联，1是关联
           val.checked = false;
          }else if(val.isContact=='1'){
             val.checked = true;
          }
      })

      return {
        ...state,
        getGroupMemberListData: data,
        checkAll              : false,
      }
    },
    checkGoods(state, {value}) {
       value.getGroupMemberListData.forEach((val,index)=>{
         if (val.memberId == value.checkedGoods.memberId) {
           val.checked = value.checked;
         }
       })
       let isCheckAll = true;
        value.getGroupMemberListData.find((val,index)=>{
          if (!val.checked) {
            isCheckAll = false;
          }
        })
      //  console.log(isCheckAll+'111')
      return {
       ...state,
       checkAll              : isCheckAll,
       getGroupMemberListData: value.getGroupMemberListData,
      }
     },
     checkAll(state, {preload}) {
        let isCheckAll = false;
        if(preload){
          isCheckAll = true,
          state.getGroupMemberListData.forEach((val,index)=>{
            val.checked = true;
          })
        }else{
          isCheckAll = false,
          state.getGroupMemberListData.forEach((val,index)=>{
            val.checked = false;

          })
        }
      return {
       ...state,
       checkAll              : isCheckAll,
       getGroupMemberListData: state.getGroupMemberListData
      }
     },

    // groupObject(state, { groupObjectData }) {
    //   const { data } = groupObjectData
    //   return {
    //     ...state,
    //     groupObjectData: data,
    //   }
    // },
  }
}
