import { routerRedux } from 'dva/router';
import { message, Icon } from 'antd';
import pathToRegexp from 'path-to-regexp';
import {objectListAPI,groupOrderCheckListAPI,getMyGroupInfoAPI,setApprovalOrderNotifyAPI} from "../group/groupApi";
import {getAreaData} from "../../utils/getArea";

export default {
  namespace: 'manageOrder',
  state    : {
    checkAll               : false,
    checkAll2              : false,
    groupOrderCheckListData: [],
    count                  : 1,
    pageNo                 : 1,
    pageSize               : 10,
    orderIds               : '',
    getMyGroupInfoData     : [],
  },
  effects: {
       //我的群组主页初始展示
       *getMyGroupInfoShowEFF({ val },{ put, call }){
        const data = yield call( getMyGroupInfoAPI ,val);
          if(data.result==1){
             yield put({type: 'getMyGroupInfo', getMyGroupInfoData: data});
          }else{
             message.error(data.msg,1.5,()=>{});
          }
        },
      *groupOrderCheckListEFF({ val},{put,call}){
        const data = yield call(groupOrderCheckListAPI,{pageSize:10,orderType:1,...val});
        // console.log(data)
        if(data.result == 1){
           yield put({type: 'groupOrderCheckList', groupOrderCheckListData: data});
        }else{
           message.error(data.msg,1.5,()=>{});
        }
       },
       //设置邮箱提醒
       *setApprovalOrderNotifyAPIEFF({ val },{ put, call }){
          const data = yield call( setApprovalOrderNotifyAPI ,val);
           if(data.result==1){
              message.success(data.msg,1.5,()=>{});
              yield put({type: 'getMyGroupInfoShowEFF',});
           }else{
                message.error(data.msg,1.5,()=>{});
          }
       },
  },
  subscriptions: {
    setup({ dispatch, history }) {
      return history.listen(({ pathname, query }) => {
        if (pathname == '/group/manage-order') {
          dispatch({ type: 'groupOrderCheckListEFF' });
          dispatch({ type: 'getMyGroupInfoShowEFF' });
        }
      })
    }
  },
  reducers: {
    groupOrderCheckList(state, { groupOrderCheckListData }) {
      const { data,count,pageNo ,orderIds } = groupOrderCheckListData
      return {
        ...state,
        groupOrderCheckListData: data,
        orderIds               : orderIds,
        pageNo                 : pageNo,
        count                  : count,

      }
    },
    getMyGroupInfo(state, { getMyGroupInfoData }) {
     const { data } = getMyGroupInfoData
     console.log(data)
     let isCheckAll  = false;
     let isCheckAll2 = false;
      data.forEach((val,index)=>{
           if(val.isEmailNotify=='0'){//0是未选，1是选
               isCheckAll = false;
           }else if(val.isEmailNotify=='1'){
               isCheckAll = true;
           }
           if(val.isApprovalPhoneNotify=='0'){//0是未选，1是选
                isCheckAll2 = false;
            }else if(val.isEmailNotify=='1'){
                isCheckAll2 = true;
            }
       })
     return {
       ...state,
       getMyGroupInfoData: data[0],
       checkAll          : isCheckAll,
       checkAll2         : isCheckAll2,
     }
   },
     checkAll(state, {preload}) {
        let isCheckAll = false;
        if(preload){
            isCheckAll = true
        }else{
            isCheckAll = false
        }
      return {
       ...state,
        checkAll          : isCheckAll,
        getMyGroupInfoData: state.getMyGroupInfoData
      }
     },
     checkAll2(state, {preload}) {
        let isCheckAll = false;
        if(preload){
            isCheckAll = true
        }else{
            isCheckAll = false
        }
      return {
       ...state,
        checkAll2         : isCheckAll,
        getMyGroupInfoData: state.getMyGroupInfoData
      }
     },
  }
}
