import { routerRedux } from 'dva/router';
import { message, Icon } from 'antd';
import pathToRegexp from 'path-to-regexp';
import { getGroupMemberListAPI,groupChildInfoAPI,groupApprovalsListAPI,objectListAPI, } from "../group/groupApi";
import {getAreaData} from "../../utils/getArea";

export default {
  namespace: 'manageMember',
  state    : {
    checkAll              : false,   //审批流
    checkAll2             : false,   //项目
    checkAll3             : false,   //经费
    getGroupMemberListData: [],
    approvalsListData     : [],
    objectListListData    : [],
    fundsListListData     : [],
    count                 : 0,
    pageNo                : 1,
    loginResult           : '1',

  },
  effects: {
      //群组成员列表
    *getGroupMemberListEFF({ val},{put,call}){
      const data = yield call(getGroupMemberListAPI,val);
      if(data.result == 1){
         yield put({type: 'getGroupMemberList', getGroupMemberListData: data});
      }else{
         message.error(data.msg,1.5,()=>{});
      }
     },
      //群组成员管理
      *groupChildInfoEFF({ val},{put,call}){
        const data = yield call(groupChildInfoAPI,val);
        if(data.result == 1){
           yield put({type: 'getGroupMemberListEFF'});
           yield put({type: 'groupLoginNameNone'});
        }else{
           message.error(data.msg,1.5,()=>{});
           yield put({type: 'groupLoginName'});
           // console.log('已经有账户名字')
        }
       },
      //审批流列表
       *groupApprovalsListEFF({ val},{put,call}){
        const data = yield call(groupApprovalsListAPI,val);
        // console.log(data)
        if(data.result == 1){
           yield put({type: 'approvalsList', approvalsListData: data});
        }else{
           message.error(data.msg,1.5,()=>{});
        }
       },
         //群组项目列表 ，经费列表
       *objectListListEFF({ val},{put,call}){
        const data = yield call(objectListAPI,val);
        // console.log(data)
        if(data.result == 1){
           yield put({type: 'objectList', objectListListData: data});
        }else{
           message.error(data.msg,1.5,()=>{});
        }
       },
       *fundsListListEFF({ val},{put,call}){
        const data = yield call(objectListAPI,val);
        // console.log(data)
        if(data.result == 1){
           yield put({type: 'fundsListList', fundsListListData: data});
        }else{
           message.error(data.msg,1.5,()=>{});
        }
       },



  },
  subscriptions: {
    setup({ dispatch, history }) {
      return history.listen(({ pathname, query }) => {
        if (pathname == '/group/manage-member') {
          dispatch({ type: 'getGroupMemberListEFF' });
          // dispatch({ type: 'groupApprovalsListEFF' });//审批流
          // dispatch({ type: 'objectListListEFF' });//项目
          // dispatch({ type: 'fundsListListEFF',val:{type:2} });//经费

        }
      })
    }
  },
  reducers: {
   groupLoginNameNone(state, {  }) {
    return {
      ...state,
      loginResult: '1',
    }
  },
    groupLoginName(state, {  }) {
      return {
        ...state,
        loginResult: '2',
      }
    },
    getGroupMemberList(state, { getGroupMemberListData }) {
      const { data ,pageNo ,count} = getGroupMemberListData
      return {
        ...state,
        getGroupMemberListData: data,
        pageNo                : pageNo,
        count                 : count,
      }
    },
    approvalsList(state, { approvalsListData }) {//审批流列表
      const { data  } = approvalsListData
      data.forEach((val,index)=>{
         if(val.isContact=='0'){//0是未关联，1是关联
             val.checked = false;
         }else if(val.isContact=='1'){
             val.checked = true;
         }
      })
      return {
        ...state,
        approvalsListData: data,
        checkAll         : false,
      }
    },
    checkGoods(state, {value}) {
      value.approvalsListData.forEach((val,index)=>{
        if (val.id == value.checkedGoods.id) {
          val.checked = value.checked;
        }
      })
      let isCheckAll = true;
       value.approvalsListData.find((val,index)=>{
         if (!val.checked) {
           isCheckAll = false;
         }
       })
     return {
      ...state,
      checkAll         : isCheckAll,
      approvalsListData: value.approvalsListData,
     }
    },
    checkAll(state, {preload}) {
       let isCheckAll = false;
       if(preload){
         isCheckAll = true,
         state.approvalsListData.forEach((val,index)=>{
           val.checked = true;
         })
       }else{
         isCheckAll = false,
         state.approvalsListData.forEach((val,index)=>{
           val.checked = false;
         })
       }
     return {
      ...state,
      checkAll         : isCheckAll,
      approvalsListData: state.approvalsListData
     }
    },
    checkGoods2(state, {value}) {
      value.objectListListData.forEach((val,index)=>{
        if (val.id == value.checkedGoods.id) {
          val.checked = value.checked;
        }
      })
      let isCheckAll = true;
       value.objectListListData.find((val,index)=>{
         if (!val.checked) {
           isCheckAll = false;
         }
       })
     return {
      ...state,
      checkAll2         : isCheckAll,
      objectListListData: value.objectListListData,
     }
    },
    checkAll2(state, {preload}) {
       let isCheckAll = false;
       if(preload){
         isCheckAll = true,
         state.objectListListData.forEach((val,index)=>{
           val.checked = true;
         })
       }else{
         isCheckAll = false,
         state.objectListListData.forEach((val,index)=>{
           val.checked = false;
         })
       }
     return {
      ...state,
      checkAll2         : isCheckAll,
      objectListListData: state.objectListListData
     }
    },
    checkAll(state, {preload}) {
      let isCheckAll = false;
      if(preload){
        isCheckAll = true,
        state.approvalsListData.forEach((val,index)=>{
          val.checked = true;
        })
      }else{
        isCheckAll = false,
        state.approvalsListData.forEach((val,index)=>{
          val.checked = false;
        })
      }
    return {
     ...state,
     checkAll         : isCheckAll,
     approvalsListData: state.approvalsListData
    }
   },
   checkGoods3(state, {value}) {
     value.fundsListListData.forEach((val,index)=>{
       if (val.id == value.checkedGoods.id) {
         val.checked = value.checked;
       }
     })
     let isCheckAll = true;
      value.fundsListListData.find((val,index)=>{
        if (!val.checked) {
          isCheckAll = false;
        }
      })
    return {
     ...state,
     checkAll3        : isCheckAll,
     fundsListListData: value.fundsListListData,
    }
   },
   checkAll3(state, {preload}) {
      let isCheckAll = false;
      if(preload){
        isCheckAll = true,
        state.fundsListListData.forEach((val,index)=>{
          val.checked = true;
        })
      }else{
        isCheckAll = false,
        state.fundsListListData.forEach((val,index)=>{
          val.checked = false;
        })
      }
    return {
     ...state,
     checkAll3        : isCheckAll,
     fundsListListData: state.fundsListListData
    }
   },

    objectList(state, { objectListListData }) {
      const { data } = objectListListData
      data.forEach((val,index)=>{
        if(val.isContact=='0'){//0是未关联，1是关联
            val.checked = false;
        }else if(val.isContact=='1'){
            val.checked = true;
        }
       })
      // data.forEach((val,index)=>{
      //   val.checked = false;
      // })
      return {
        ...state,
        objectListListData: data,
        checkAll2         : false,
      }
    },
    fundsListList(state, { fundsListListData }) {
      const { data } = fundsListListData
        data.forEach((val,index)=>{
         if(val.isContact=='0'){//0是未关联，1是关联
             val.checked = false;
         }else if(val.isContact=='1'){
             val.checked = true;
         }
      })
      // data.forEach((val,index)=>{
      //   val.checked = false;
      // })
      return {
        ...state,
        fundsListListData: data,
        checkAll3        : false,
      }
    },
  }
}
