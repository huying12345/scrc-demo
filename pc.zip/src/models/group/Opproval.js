import { routerRedux } from 'dva/router';
import { message, Icon } from 'antd';
import pathToRegexp from 'path-to-regexp';
import { groupApprovalsListAPI,groupApprovalsAPI,getGroupMemberListAPI,defaultApprovalAPI,deleteGroupApprovalsAPI} from "../group/groupApi";
import {getAreaData} from "../../utils/getArea";
export default {
  namespace: 'opproval',
  state    : {
    checkAll              : false,   //审批流
    approvalsListData     : [],
    getGroupMemberListData: [],
    count                 : 0,
    pageNo                : 1,
  },
  effects: {
        //审批流列表
       *groupApprovalsListEFF({ val},{put,call}){
        const data = yield call(groupApprovalsListAPI,val);
        // console.log(data)
        if(data.result == 1){
           yield put({type: 'approvalsList', approvalsListData: data});
        }else{
           message.error(data.msg,1.5,()=>{});
        }
       },
       //审批流编辑
       *groupApprovalsEFF({ objOppoval },{put,call}){
        const data1 = yield call(groupApprovalsAPI,objOppoval);
        if(data1.result == 1){
           message.success(data1.msg, 1.5);
           yield put({type: 'groupApprovalsListEFF', });
        }else{
           message.error(data1.msg,1.5,()=>{});
        }
       },
          // 设置审批流启用/禁用：
           *defaultApprovalEFF({ val },{put,call}){
            const data1 = yield call(defaultApprovalAPI,val);
            if(data1.result == 1){
               message.success(data1.msg, 1.5);
               yield put({type: 'groupApprovalsListEFF', });
            }else{
               message.error(data1.msg,1.5,()=>{});
            }
           },
    //审批流删除一项
      *deleteGroupApprovalsEFF({ val },{put,call}){
         const data1 = yield call(deleteGroupApprovalsAPI,val);
           if(data1.result == 1){
              message.success(data1.msg, 1.5);
             yield put({type: 'groupApprovalsListEFF', });
           }else{
              message.error(data1.msg,1.5,()=>{});
           }
      },

             //群组成员列表
    *getGroupMemberListEFF({ val},{put,call}){
     const data = yield call(getGroupMemberListAPI,val);
     if(data.result == 1){
        yield put({type: 'getGroupMemberList', getGroupMemberListData: data});
     }else{
        message.error(data.msg,1.5,()=>{});
     }
    },



  },
  subscriptions: {
    setup({ dispatch, history }) {
      return history.listen(({ pathname, query }) => {
        if (pathname == '/group/opproval'){
           dispatch({ type: 'groupApprovalsListEFF' });//审批流列表
           dispatch({ type: 'getGroupMemberListEFF' });
        }
      })
    }
  },
  reducers: {
   getGroupMemberList(state, { getGroupMemberListData }) {
    const { data } = getGroupMemberListData
    return {
      ...state,
      getGroupMemberListData: data,

    }
  },
   approvalsList(state, { approvalsListData }) {//审批流列表
     const { data  ,pageNo ,count} = approvalsListData

     return {
       ...state,
       approvalsListData: data,
       pageNo           : pageNo,
       count            : count,
     }
   },
   checkGoods(state, {value}) {
      value.approvalsListData.forEach((val,index)=>{
        if (val.id == value.checkedGoods.id) {
          val.checked = value.checked;
        }
      })
      let isCheckAll = true;
       value.approvalsListData.find((val,index)=>{
         if (!val.checked) {
           isCheckAll = false;
         }
       })
     return {
      ...state,
      checkAll         : isCheckAll,
      approvalsListData: value.approvalsListData,
     }
    },
    checkAll(state, {preload}) {
       let isCheckAll = false;
       if(preload){
         isCheckAll = true,
         state.approvalsListData.forEach((val,index)=>{
           val.checked = true;
         })
       }else{
         isCheckAll = false,
         state.approvalsListData.forEach((val,index)=>{
           val.checked = false;
         })
       }
     return {
      ...state,
      checkAll         : isCheckAll,
      approvalsListData: state.approvalsListData
     }
    },



  }
}
