 //我的群组
import { routerRedux } from 'dva/router';
import { message, Icon } from 'antd';
import pathToRegexp from 'path-to-regexp';
import {getOrderAddressListApi,getMyGroupInfoAPI} from "../group/groupApi";


export default {
    namespace: 'mianManage',
    state    : {
      getMyGroupInfoData: [],
      checkAll          : false,
    },
    effects: {
       //我的群组主页初始展示
       *getMyGroupInfoShowEFF({ val },{ put, call }){
        const data = yield call( getMyGroupInfoAPI ,val);
          if(data.result==1){
             yield put({type: 'getMyGroupInfo', getMyGroupInfoData: data});
          }else{
             message.error(data.msg,1.5,()=>{});
          }
        },
          //我的群组主页修改列表
        *getMyGroupInfoEFF({ val },{ put, call }){
         const data = yield call( getMyGroupInfoAPI ,val);
           if(data.result==1){
              yield put({type: 'getMyGroupInfo', getMyGroupInfoData: data});
              message.success(data.msg,1.5,()=>{});
           }else{
              message.error(data.msg,1.5,()=>{});
           }
         },

    },
    subscriptions: {
      setup({ dispatch, history }) {
        return history.listen(({ pathname, query }) => {
          if (pathname == '/group/mianManage') {
            dispatch({ type: 'getMyGroupInfoShowEFF' });
          }
        })
      }
    },
    reducers: {
      getMyGroupInfo(state, { getMyGroupInfoData }) {
        const { data } = getMyGroupInfoData
        // console.log(data)
        let isCheckAll = false;
        data.forEach((val,index)=>{
           if(val.isApprovalEmilNotify=='0'){//0是未选，1是选
               isCheckAll = false;
           }else if(val.isApprovalEmilNotify=='1'){
               isCheckAll = true;
           }
        })
        return {
          ...state,
          getMyGroupInfoData: data[0],
          checkAll          : isCheckAll,
        }
      },
      checkAll(state, {preload}) {
          let isCheckAll = false;
          if(preload){
            isCheckAll = true
          }else{
            isCheckAll = false
          }
        return {
         ...state,
         checkAll          : isCheckAll,
         getMyGroupInfoData: state.getMyGroupInfoData
        }
       },
    }
  }
