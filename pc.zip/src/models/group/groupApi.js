//订单结算接口
import { post, get } from '../../utils/request';
//订单结算
export function subCartToOrder(cartIds,activityIds){
 //console.log(cartId)
 // alert(cartIds)
 return post('/tradeApi/subCartToOrder',{cartIds,activityIds},"json")
}
//提交订单
export function saveOrderForSinopharmAPI(value){
 console.log(value)
    return post('/orderApi/saveOrderForSinopharm',value , 'json');
}

//群组信息管理
//群组信息管理  群组公告
export function editorGroupNoticeAPI( value ){
    return get('/groupApi/editorGroupNotice',value)
}
//保存收货地址信息
export function saveAddressAPI( value ){
    return get('/groupApi/saveOrderAddress',value)
}

//设置默认地址
export function setDefaultAddressAPI( orderAddressId ){
    return get('/groupApi/saveDefaultOrderAddress', {orderAddressId} )
}
//删除地址deleteOrderAddress
export function deleteOrderAddressAPI( addressId ){
 return get('/groupApi/deleteOrderAddress', {addressId} )
}
//获取地区数据
export function getArea(){
 return post('/dictApi/areaList')
}
//getOrderAddressList获取收货地址列表
export function getOrderAddressListApi(){
 return post('/groupApi/getOrderAddressList')
}
//getOrderInvoiceList获取发票列表
export function getOrderInvoiceListApi(cartIds){
 return post('/tradeApi/getOrderInvoiceList',{cartIds})
}

//选择配送方式 getDeliveryMethod
export function getDeliveryMethodAPI( value ){
 return post('/tradeApi/getDeliveryMethod',value,"json")
}
//保存发票信息saveOrderInvoice
export function saveOrderInvoiceAPI( value ){
 console.log(value)
 return post('/tradeApi/saveOrderInvoice',value,'json')
}
//获取支付方式 paymentList
export function getPaymentListAPI( values ){
 return post('/tradeApi/paymentList',values)
}
// 群组订单管理
//
// export function groupOrderCheckListAPI( obj ){
//     return post('/groupApi/groupOrderCheckList',obj)
// }


//群组主页页面
export function getMyGroupInfoAPI( obj ){
    return post('/groupApi/getMyGroupInfo',obj)
}
//群组项目管理页面
//群组项目新建
export function groupObjectAPI( obj ){
    return post('/groupApi/groupObject',obj)
}
//群组列表   经费列表type：1
export function objectListAPI( obj ){
    return post('/groupApi/objectList',obj)
}
//使用人范围
export function getGroupMemberListAPI( obj ){
    return post('/groupApi/getGroupMemberList',obj)
}
//群组经费管理页面
//经费新建
export function groupFundsAPI( obj ){
    return post('/groupApi/groupFunds',obj)
}

//群组成员管理页面
//创建编辑等
export function groupChildInfoAPI( obj ){
    return post('/groupApi/groupChildInfo',obj)
}
//审批流列表
export function groupApprovalsListAPI( obj ){
    return post('/groupApi/groupApprovalsList',obj)
}
//审批流列表删除某一列
export function deleteGroupApprovalsAPI( obj ){
 return post('/groupApi/deleteGroupApprovals',obj)
}
//项目列表，经费列表在上面
// 群组审批订单和 群组订单管理，参数不同
//审批订单，orderType=1， orderStatus不传
// 订单管理，orderType=0可不传，默认是0， checkStatus不传
// 群组审批订单
export function groupOrderCheckListAPI( obj ){
    return post('/groupApi/groupOrderList',obj)
}
// 群组订单管理
export function groupOrderListAPI( obj ){
    return post('/groupApi/groupOrderList',obj)
}
//群组审批流管理页面
//群组审批流管理（新建审批流和编辑）
export function groupApprovalsAPI( objOppoval ){
 return post('/groupApi/groupApprovals',objOppoval)
}
// 设置审批流启用/禁用：
// 传参：approvalId  审批流ID
// isUse   1启用，0禁用
export function defaultApprovalAPI( obj ){
 return post('/groupApi/defaultApproval',obj)
}
//设置邮箱手机提醒
export function setApprovalOrderNotifyAPI( obj){
 return post('/groupApi/setApprovalOrderNotify',obj)
}








