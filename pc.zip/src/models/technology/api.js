import {  get,post } from '../../utils/request';

//下载
export function downloadAPI(payload){
  // return get('',{payload})
}

//左侧导航栏
export function getleftNavAPI(){
  return get('')
}

//品牌中心动态页面内容
export function getDynamicDataAPI(){
  return get('')
}

export  function GetGoodsDetail(goodsId) {
  // 获取验证码  goodsApp
  return get('/goodsApp/getGoodsDetail',{ goodsId });
}

/*OOA报告查询（产品检验报告）*/
export  function coaListApi(val) {
  return get('/goodsApi/coaList',val);
}
// /goodsApi/csdsList

/*MSDS(化学品安全说明书)*/
export  function csdsListApi(val) {
  return get('/goodsApi/csdsList',val);
}

// 六级导航
export function getNavListSide(val){
  return get('/indexApi/getNavigationList',val);
}


//宣传资料
export function propagandaAPI({page}){
  return get('/indexApi/indexAdvList',{apKey:'propaganda',...page})
}

 //广告点击量
 export function clickNumAPI(val){
  return get('/indexApi/clickNum',val)
 }
//方法标准
export function standardMethodAPI(val){
 return get('/technologyApi/getTechnology',val)
}

