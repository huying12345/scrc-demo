import React, { Component } from 'react'
import { BodyHeadImg } from '../../components/Advertising/Advertising'
import { Form, Breadcrumb, Button, Table, Row, Col, Pagination, Input, Icon, Modal } from 'antd'
import {routerRedux, Link } from 'dva/router'
import { connect } from 'dva'
import { order_detail } from './OrderDetail.less'
import Img from "../../components/Img/Img"
import Search from '../../components/Search/Search'
import Navigation from '../../components/Navigation/Navigation'
import OrderDetailFloor from './OrderDetailFloor'
import { IMAGE_DOMAIN } from '../../utils/common';
import {printOrderPDF,exportOrderDirectDialAPI} from './api';

const FormItem       = Form.Item;
const formItemLayout = {
  labelCol: { span: 8 }
};


class OrderDetail extends Component {
  constructor(props) {
    super(props)
    this.state = {
      startValue     : null,
      endValue       : null,
      endOpen        : false,
      data           : [],
      pagination     : {},
      loading        : true,
      visible        : false,
      orderSn        : '',
      visibleApproval: false,
    }
  }

  disabledStartDate = (startValue) => {
    const endValue = this.state.endValue;
    if (!startValue || !endValue) {
      return false;
    }
    return startValue.valueOf() > endValue.valueOf();
  }

  disabledEndDate = (endValue) => {
    const startValue = this.state.startValue;
    if (!endValue || !startValue) {
      return false;
    }
    return endValue.valueOf() <= startValue.valueOf();
  }

  onChange = (field, value, dateString) => {
    console.log(field, value, dateString)
    this.setState({
      [field]: dateString,
    });
  }

  onStartChange = (value, dateString) => {
    this.onChange('startValue', value, dateString);
  }

  onEndChange = (value, dateString) => {
    this.onChange('endValue', value, dateString);
  }

  handleStartOpenChange = (open) => {
    if (!open) {
      this.setState({ endOpen: true });
    }
  }

  handleEndOpenChange = (open) => {
    this.setState({ endOpen: open });
  }

  handleTableChange = (pagination) => {
    this.setState({ loading: true });
    const pager         = { ...this.state.pagination };
          pager.current = pagination.current;
          data          = data.concat(data);
    let   _this         = this;
    setTimeout(function () {
      _this.setState({
        pagination: pager,
        data      : data,
        loading   : false,
      });
    }, 2000)
  }
 addCart = (val) => {
  this.props.dispatch({type:'orderDetail/addCartEFF',val})
 }
 handleAddCarts = ()=>{
  let purTemplateItems = [];
  this.props.orderDetail.personOrdeDetailData[0].orderItemsList.forEach((v, index, array) => {
   //整单加入只能是平台商品
   if(v.goodsId!='' && v.dosageForm == "0"){
    purTemplateItems.push({ goodsId:v.goodsId, newGoodsPrice:v.productSellPrice, goodsNum:1,goodsSource: v.dosageForm,goodsMaterial: v.goodsMaterial })
   }
  })
  this.props.dispatch({
   type: 'orderDetail/getAddCartBachEFF',
   arr : purTemplateItems
  })
 }

  handleSubmit = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        console.log('Received values of form: ', values);
      }
    });
  }
 goPay = (orderId) => {
  this.props.dispatch({type: 'myOrder/goPayEFF', val: {orderId}});
 }

  handleOk = () => {
   if(this.state.orderSn) {
    this.props.form.validateFields((err, values) => {
     this.props.dispatch({type:'orderDetail/cancleOrderEFF',val:{orderSn: this.state.orderSn,cancelReason: values.remark,orderId:this.props.params.orderId}})
     this.setState({
      visible: false,
      orderSn: ''
     })
    })
   }
  }
  showModal = (orderSn) => {
   this.setState({
    visible: true,
    orderSn: orderSn
   })
  }
  handleCancel = (e) => {
   this.setState({
    visible: false,
    orderSn: ''
   });
  }



  onPrint2 = (orderId) => {
    console.log(orderId)
    const value={
     orderId: orderId,
     type:1
   }
    console.log(value)
    let path = window.open('about:blank');
    exportOrderDirectDialAPI(value).then(r => {
      if (r.result == 1) {
         console.log(r.url)
         let url = `${IMAGE_DOMAIN}${r.url}`;
         console.log(url)
       //  path.location.href='http://www.baidu.com'
       path.location.href = url
         console.log(url);

      } else {
       message.error(r.msg, 1.5);
      }
     })

  }

  onPrint = (orderId) => {
     console.log(orderId)
     const value={
      orderId: orderId
    }
     console.log(value)
     let path = window.open('about:blank');
     printOrderPDF(value).then(r => {
       if (r.result == 1) {
          console.log(r.url)
          let url = `${IMAGE_DOMAIN}${r.url}`;
          console.log(url)
        //  path.location.href='http://www.baidu.com'
        path.location.href = url
          console.log(url);

       } else {
        message.error(r.msg, 1.5);
       }
      })

   }
   approvalNo=(checkStatus)=>{
    this.setState({
        visibleApproval: true,
        // checkStatus    : '0',
        // orderId        : this.props.params.orderId,
        // checkRemark:'不同意的意见',
       })
   }
   handleOkApproval = (e) => {
     e.preventDefault();
     this.props.form.validateFields(['remarkApproval'],(err, values) => {
        if(!err){
            console.log(values)
            let remarkApproval = values.remarkApproval
            this.props.dispatch({type:'orderDetail/checkOrderEFF',
            val:{checkRemark:remarkApproval,orderId:this.props.params.orderId,checkStatus:'0'}})
            this.props.dispatch(routerRedux.push(`/group/manage-order`));
            this.setState({ visibleApproval: false, })
        }
     })
   }
   approvalYes=()=>{
      this.props.dispatch({type:'orderDetail/checkOrderEFF',
      val:{orderId:this.props.params.orderId,checkStatus:'1'}})
      this.props.dispatch(routerRedux.push(`/group/manage-order`));
   }
   handleCancelApproval = () => {
     this.setState({ visibleApproval: false,});
   }
  render() {
    const { getFieldDecorator }                                                    = this.props.form;
    let   { personOrdeDetailData, dosageFormGoodsNum ,isButton,getBankAccountData} = this.props.orderDetail
    const { startValue, endValue, endOpen }                                        = this.state;
    const formItemLayout                                                           = {
     labelCol  : { span: 6 },
     wrapperCol: { span: 16 },
    };
    let det = personOrdeDetailData[0] || {}
    return (
      <div>
        <Search></Search>
        <Navigation preson={true}>
          <div className={order_detail}>
          <div className="my_account_dynamic_Topimg"></div>
            <Breadcrumb separator=">" className='security_nav_bar'>
              <Breadcrumb.Item href="/presonAccunt/myAccount">我的账户</Breadcrumb.Item>
              <Breadcrumb.Item>订单详情</Breadcrumb.Item>
            </Breadcrumb>
            <div className="wapper">
              <p><b>订单信息：</b> </p>
              <div className="btn_area">
                 <span style={{background: '#3497ce', color: '#666', fontWeight: 'bold',fontStyle:'normal',color:'#fff',cursor:'pointer'}} onClick={()=>this.onPrint(det.orderId)}>导出订单</span>
                 {
                  det.member && det.member.isMaterial == 0?null:<span style={{background: '#3497ce', color: '#666', fontWeight: 'bold',fontStyle:'normal',color:'#fff',cursor:'pointer',width:'110px'}} onClick={()=>this.onPrint2(det.orderId)}>导出验收直拨单</span>
                 }


                {/* {det.orderState == '1' && det.paymentState == '0' ?
                  <span
                      style   = {{background: '#e5e5e5', color: '#666', fontWeight: 'bold'}}
                      onClick = {(orderSn)=>this.showModal(det.orderSn)}>订单取消
                  </span>
                  :                                                   ''
                } */}
                { det.member && det.member.memberType == '3'?
                    (
                      //det.checkStatus=='1'&& isButton=='1'?
                      ''

                       //: ''
                    )
                    :
                    (
                     det.orderState == '1' && det.paymentState == '0' ?
                       <span
                           style   = {{background: '#e5e5e5', color: '#666', fontWeight: 'bold'}}
                           onClick = {(orderSn)=>this.showModal(det.orderSn)}>订单取消
                       </span>
                       :           ''
                    )
                }
                {det.paymentState == 0 && det.paymentCode=='1' && (det.orderState == 1 || det.orderState == 3) ?
                  <span style={{background: '#fc0d1b'}} onClick={()=>this.goPay(det.orderId)}>在线支付</span>
                  :                                                   ''
                }
                 {/* <i style={{background:'#3497ce',display:'inline-block',padding:'5px',fontStyle:'normal',borderRadius:'10%',float:'right',color:'#fff',cursor:'pointer'}}   onClick={()=>this.onPrint(det.orderId)}>导出订单</i> */}
                {/*{(det.orderState != 7 && det.orderState != 8) ?*/}
                  {/*<span>订单导出</span>*/}
                  {/*: ''*/}
                {/*}*/}
              </div>
             <Row className="detial_info">
              { det.dangerousRemarkList && det.dangerousRemarkList.length > 0?
               <Col span={8}>订单编号：{
                det.dangerousRemarkList.map((item,i)=>{
                 return <Img key={i} style={{width: '23px', marginRight: '10px',verticalAlign:'middle'}} src={item}/>
                })
               }
                {det.orderSn}</Col>
               :<Col span={6}>订单编号：{det.orderSn}</Col>
              }
              <Col span={6}>下单时间：{det.createTimeStr && det.createTimeStr.slice(0,19)}</Col>
              <Col span={6}>订单状态：{det.orderStateMemo}</Col>
             </Row>
             <Row className="detial_info">
              <Col span={6}>商品总价：<span className="em">￥{det.goodsAmount}</span></Col>
              {det.shippingFee&&det.shippingFee!='0'&&det.shippingFee!=''?
                <Col span={6}>总运费：<span className="em">￥{det.shippingFee}</span></Col>
                :                                null
              }
              {  det.member && det.member.memberType == '0' ?
                 <Col span={6}>积分抵扣：<span className="em">￥{det.pointRmbNum ? det.pointRmbNum.toFixed(2) : '0.00'}</span></Col>
                 :                                                                                          null
               }
              <Col span={6}>订单总价：<span className="em">￥{det.orderTotalPrice}</span></Col>
             </Row>
             <Row className="detial_info">
             {
                det.member && det.member.memberType == '0' ?
                 <Col span={6}>预存款支付：<span className="em">￥{(det.predepositAmount) || '0.00'}</span></Col>
                 :                                                                                          null
               }
               {
                  det.member && det.member.memberType == '0' ?
                  <Col span={6}>应支付金额：<span className="em">￥{det.orderAmount>0 ? det.orderAmount : '0.00'}</span></Col>
                  :                                                                                          null
               }
              <Col span={6}>商品种类：<span className="em">{det.orderItemsCount ? det.orderItemsCount : '0'} 种</span></Col>
              <Col span={6}>商品总数量：<span className="em">{det.goodsTotalNum ? det.goodsTotalNum : '0'} 个</span></Col>
             </Row>
             {
              det.controlInfo ?
               <p className="detial_info" style={{color: '#fc0d1b'}}>订单包含管制类产品（一般危险化学品／易制爆化学品／一类易制毒化学品／二、三类易制毒化学品／剧毒化学品），要按照国家规定提供相关证件备案后方可购买</p>: null
             }
             {
              det.controlInfo ? <Link to='/customservice?parentId=6&articleId=513ace30b988496b835227c55a17a473' target="_blank" className="detial_info blue_btn">点击查看管制类商品所需相关购买材料>></Link> : null
             }
              <p className="line"></p>
              <p className="detial_info"><b>订货人信息：</b></p>
              <Row className="detial_info">
                <Col span={6}>登录名称：{det.buyerName}</Col>
                <Col span={6}>订货人姓名：{det.buyerTrueName}</Col>
                <Col span={6}>绑定手机：{det.buyerTel}</Col>
              </Row>
              <p className="line"></p>
              <p className="detial_info"><b>收货人信息：</b></p>
              <Row className="detial_info">
                <Col span={6}>收货人：{det.address && det.address.trueName}</Col>
                <Col span={6}>收货地区：{det.address && det.address.provinceName}{det.address && det.address.cityName}{det.address && det.address.areaInfo}</Col>
                <Col span={6}>收货地址：{det.address && det.address.address}</Col>
                <Col span={6}>手机号：{det.address && det.address.mobPhone}</Col>
              </Row>
              <Row className="detial_info">
                <Col span={6}>固定电话：{det.address && det.address.telPhone}</Col>
                <Col span={6}>邮政编码：{det.address && det.address.zipCode}</Col>
              </Row>
               <div>
                {det.shippingName&&det.shippingName!=''?
                  <div>
                     <p className="line"></p>
                     <p className="detial_info"><b>配送信息：</b></p>
                     <Row className="detial_info">
                      <Col span={6}>{det.shippingName}</Col>
                     </Row>
                  </div>
                  :                               null
                }
                <p className="line"></p>
                <p className="detial_info"><b>支付信息：</b></p>
                {det.member && det.member.memberType == '0' ?
                  <Row className="detial_info">
                   <Col span={6}>支付方式：{det.paymentName}</Col>
                   {det.paymentCode != "3"?
                    < Col span={6}>支付状态：<span className="em">{det.paymentStateStr}</span></Col>
                    :                                                  null
                   }
                   {det.paymentCode == "1"?
                    < Col span={6}>支付途径：<span className="em">{det.paymentBranch}</span></Col>
                    :                                                  null
                   }
                  </Row>
                  :null}
                {
                 det.member&&det.member.memberType == '0'
                  && det.paymentCode == "2"?
                 ( getBankAccountData &&getBankAccountData .length>0 ?
                      <div>
                        <div style={{width:'50%',display:'inline-block'}}>
                            <Row>
                             <Col span={12}>开户名：国药集团化学试剂有限公司</Col>
                            </Row>
                            <Row>
                             <Col span={12}>开户银行：{getBankAccountData[0].bankName}</Col>
                            </Row>
                            <Row>
                             <Col span={12}>账号：{getBankAccountData[0].bankAccount}</Col>
                            </Row>
                        </div>
                        <div style={{width:'50%',display:'inline-block'}}>
                            <Row>
                             <Col span={12}>开户名：国药集团化学试剂有限公司</Col>
                            </Row>
                            <Row>
                             <Col span={12}>开户银行：{getBankAccountData[1].bankName}</Col>
                            </Row>
                            <Row>
                             <Col span={12}>账号：{getBankAccountData[1].bankAccount}</Col>
                            </Row>
                        </div>
                        <p style={{color: 'red'}}>注：请在备注栏中写明订单号或中国试剂网，并在汇款之后将汇款凭提供给客服人员，以便我们查收。</p>
                        <p style={{color: 'red'}}>请在下单后按订单总金额汇款，7天后仍未收到货款，客服人员将电话予以确认，15天仍未收到货款，订单将自动关闭</p>
                    </div>
                    :  null
                     )
                  :
                    <div className='paymentCodeTwo'>
                     {
                      det.accountList&&det.accountList[0]?
                        <div>
                          <p>汇款账户：</p>
                          <p>开户名：国药集团化学试剂有限公司</p>
                          <p>开户银行：{det.accountList[0].bankName}</p>
                          <p>账号：{det.accountList[0].bankAccount}</p>
                          <p>银行行号：{det.accountList[0].bankCode}</p>
                        </div>
                      :                                            null
                     }
                     </div>
                 }

                <p className="line"></p>
                <p className="detial_info" style={  det.member && det.member.memberType != '0' ?{display:'none'}:{}}><b>发票信息：</b></p>
                <Row className="detial_info" style={  det.member && det.member.memberType != '0' ?{display:'none'}:{}}>
                 <Col span={6}>发票类型：{det.invoiceEntity && (det.invoiceEntity.invState==0 ? '个人发票' : det.invoiceEntity.invState==1 ? '增值税普通发票' : det.invoiceEntity.invState==2 ? '增值税专用发票' : '') }</Col>
                 {det.invoiceEntity && (det.invoiceEntity.invTitle && (det.invoiceEntity.invState!=0)) ? <Col span={6}>机构名称：{det.invoiceEntity && det.invoiceEntity.invTitle}</Col> : null}
                 {det.invoiceEntity && (det.invoiceEntity.invCode && (det.invoiceEntity.invState!=0)) ? <Col span={12}>纳税人识别号/统一社会信用代码：{det.invoiceEntity && det.invoiceEntity.invCode}</Col> : null}
                </Row>
                <Row className="detial_info">
                 {det.invoiceEntity && (det.invoiceEntity.invRegAddr && (det.invoiceEntity.invState == 2)) ? <Col span={6}>开票地址：{det.invoiceEntity && det.invoiceEntity.invRegAddr}</Col> : null}
                 {det.invoiceEntity && (det.invoiceEntity.invRecMobphone && (det.invoiceEntity.invState == 2)) ? <Col span={6}>开票电话：{det.invoiceEntity && det.invoiceEntity.invRecMobphone}</Col> : null}
                 {det.invoiceEntity && (det.invoiceEntity.invRegBname && (det.invoiceEntity.invState == 2)) ? <Col span={6}>开户银行：{det.invoiceEntity && det.invoiceEntity.invRegBname}</Col> : null}
                </Row>
                <Row className="detial_info">
                 {det.invoiceEntity && (det.invoiceEntity.invRegBaccount && (det.invoiceEntity.invState == 2)) ? <Col span={6}>银行账号：{det.invoiceEntity && det.invoiceEntity.invRegBaccount}</Col> : null}
                </Row>
               </div>

              <p className="line"></p>
              <p className="detial_info"><b>购物清单：</b></p>
              <div className="orderList_content">
                <Row className="orderList_content_head">
                  <Col span={6}>基本信息</Col>
                  <Col span={4}>商品属性</Col>
                  <Col span={2}>成交单价(元)</Col>
                  <Col span={2}>订购数量</Col>
                  <Col span={2}>发货数量</Col>
                  <Col span={2}>小计</Col>
                  <Col span={2}>到货时间</Col>
                  <Col span={2}>商品状态</Col>
                  <Col span={2}>操作</Col>
                </Row>
              </div>
              {det.sale ?
              <div className="saleInfo">
                <Icon type="flag" />
                {det.sale}
              </div>:
              ''
              }
              <div>
                <div>
                  <OrderDetailFloor
                    dosageFormGoodsNum = {dosageFormGoodsNum}
                    data               = {(det.orderItemsList) || []}
                    orderId            = {det.orderId}
                    member             = {(det.member)||{}}

                    orderState     = {det.orderState}
                    orderMessage   = {det.orderMessage} addCart = {this.addCart}
                    handleAddCarts = {this.handleAddCarts}>
                  </OrderDetailFloor>
                </div>

                {/*<p className="line"></p>*/}
                {/*<p className="detial_info"><b>满额赠礼：</b></p>*/}
                {/*<Row className="detial_info">*/}
                  {/*<Col span={6}>SCRC护目镜</Col>*/}
                {/*</Row>*/}

               {
                det.goodsShippingTransLists || det.invoiceShippingTransLists || det.orderServiceMessage ?
                 <div>
                  <p className="line"></p>
                  <p className="detial_info"><b>订单信息跟踪：</b></p>
                  {det.orderServiceMessage ? <p>客服备注：{det.orderServiceMessage}</p> : null}
                  <Row className="detial_info detail_padding">
                   {
                    det.goodsShippingTransLists ?
                     <div>
                      <Col span={6}>商品物流明细（<Link to="/customservice?parentId=6&articleId=cbf2ce88bcea4ac0a2819dce806240e7" target='_black' style={{textDecoration: 'underline'}}>查看公路托运自提网点</Link>）</Col>
                      <table>
                       <tbody>
                       <tr>
                        <th>发货时间</th>
                        <th>运输公司</th>
                        <th>发运信息</th>
                       </tr>
                       {
                        det.goodsShippingTransLists && det.goodsShippingTransLists.map(item => {
                         return (
                          <tr>
                           <td>{item.createTime}</td>
                           <td>{item.shippingName}</td>
                           <td>{item.shippingInformation}</td>
                          </tr>
                         )
                        })
                       }
                       </tbody>
                      </table>
                     </div>: null
                   }
                   {
                    det.invoiceShippingTransLists ?
                     <div>
                      <Col span={6}>发票物流明细</Col>
                      <table>
                       <tbody>
                       <tr>
                        <th>发票寄出时间</th>
                        <th>运输公司</th>
                        <th>发运信息</th>
                       </tr>
                       {
                        det.invoiceShippingTransLists && det.invoiceShippingTransLists.map(item => {
                         return (
                          <tr>
                           <td>{item.createTime}</td>
                           <td>{item.shippingName}</td>
                           <td>{item.shippingInformation}</td>
                          </tr>
                         )
                        })
                       }
                       </tbody>
                      </table>
                     </div>: null
                   }
                  </Row>
                 </div>: null
               }
                {det.member && det.member.memberType != '3'&&det.orderState == 7 ?
                  <div>
                    <p className="line"></p>
                    <p className="detial_info"><b>订单取消信息：</b></p>
                    <Row className="detial_info">
                      <Col span={24}>取消者：{det.cancelOperator}</Col>
                      <Col span={24}>取消原因：{det.cancelCause}</Col>
                    </Row>
                  </div>: ''
                }
                <div>
                {det.projectName || det.projectId ?
                      <p style={{fontSize:'14px',fontWeight:'bold'}}>{det.member && det.member.isMaterial == 1?'团队负责人':'项目信息'}</p>
                       :                                              null
                      }
                      {det.projectName ?
                         <p style={{margin:'5px 0'}}>{det.member && det.member.isMaterial == 1?null:'项目名称：'}{det.projectName}</p>
                       :                                             null
                 }
                </div>
               <div>
                {det.fundsName || det.fundsId ?
                      <p style={{fontSize:'14px',fontWeight:'bold'}}>{det.member && det.member.isMaterial == 1?'课题号':'经费信息'}</p>
                       :                                              null
                      }
                      {det.fundsName ?
                         <p style={{margin:'5px 0'}}>{det.member && det.member.isMaterial == 1?null:'经费名称：'}{det.fundsName}</p>
                       :                                             null
                 }
               </div>

                {det.member && det.member.memberType == '3' && det.checkStatus == '1' && isButton=='1'?
                   <div>
                       <b onClick={()=> {this.approvalNo(det.checkStatus )}} style={{background:'red',padding:'5px',color:'#fff',marginLeft:'30%',marginRight:'5%',cursor:'pointer'}}>审批不通过</b>
                       <b onClick={()=> {this.approvalYes( det.checkStatus)}}  style={{background:'#108ee9',padding:'5px',color:'#fff',cursor:'pointer'}}>审批通过</b>
                   </div>
                   :
                   <div>
                    {det.approvalName?
                     <div>
                      <p style={{fontSize:'14px',fontWeight:'bold'}}>审批信息</p>
                      <p style={{margin:'5px 0px 0px 0px'}}>审批流名称：{det.approvalName}</p>
                     </div>
                      :      null
                    }
                       <div>
                        {det.approvalLogs && det.approvalLogs.length?
                         det.approvalLogs.map((item, index) => {
                          return (
                           <div key={index}>
                            {item.approvalUserName ?
                             <p style={{margin:'5px 0px 0px 0px'}}>审批人：{item.approvalUserName}</p>
                             :      null
                            }
                            {item.checkStatus ?
                             <p>审批结果：{item.checkStatus}</p>
                             :      null
                            }
                            {item.createTimeStr ?
                             <p>审批时间：{item.createTimeStr}</p>
                             :      null
                            }
                            {item.approvalRemark ?
                             <p>审批意见：{item.approvalRemark}</p>
                             :      null
                            }
                           </div>
                          )
                         })
                         :      null
                        }
                       </div>
                   </div>
                }
              </div>
            </div>
           <Modal
            title    = "取消订单"
            visible  = {this.state.visible}
            onOk     = {this.handleOk}
            onCancel = {this.handleCancel}
            width    = {400}
            footer   = {
             <Row type="flex" justify="space-around">
              <Col> <Button type="primary" onClick={this.handleOk}>确定</Button></Col>
              <Col> <Button  onClick={this.handleCancel}>取消</Button></Col>
             </Row>
            }
           >
            <FormItem
             { ...formItemLayout }
             label = { <span style={{ fontSize:'16px', fontWeight:'bold' }}>取消原因</span>}
            >
             {getFieldDecorator('remark', {
             })(
              <Input type="textarea" rows={4} />
             )}
            </FormItem>
           </Modal>
           <Modal
            title    = '审批意见'
            visible  = {this.state.visibleApproval}
            width    = {400}
            closable = {false}
            onOk     = {this.handleOkApproval}
            onCancel = {this.handleCancelApproval}
            footer   = {
             <Row type="flex" justify="space-around">
              <Col> <Button  onClick={this.handleCancelApproval}>取消</Button></Col>
              <Col> <Button key="submit"  htmlType="submit"  type="primary" onClick={this.handleOkApproval}>提交</Button></Col>
             </Row>
            }
           >
           <Form onSubmit={this.handleOkApproval}  layout="inline">
               <FormItem { ...formItemLayout }  style={{width:'80%'}}>
                 {getFieldDecorator('remarkApproval', {
                 })(
                  <Input/>
                 )}
               </FormItem>
              {/* <FormItem style={{textAlign: 'center'}}>
                <Button  htmlType="submit"  type="primary" onClick={this.handleCancelApproval}>取消</Button>
                 <Button  key="submit" htmlType="submit"  type="primary" onClick={this.handleOkApproval}>提交</Button>
              </FormItem> */}
           </Form>

           </Modal>
          </div>
        </Navigation>
      </div>
    )
  }
}

export default connect(({ orderDetail }) => ({ orderDetail }), (dispatch) => { return { dispatch } })(Form.create()(OrderDetail))
