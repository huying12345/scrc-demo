import React, { Component } from 'react';
import { connect } from 'dva';
import { routerRedux,Link} from 'dva/router';
import { Row,Col,Menu, Dropdown,Icon,Breadcrumb,Input,Button,Pagination} from 'antd';
import Img from '../../components/Img/Img';

class RefundListFloor extends Component {
  constructor(props) {
    super(props)
    this.state = {
      // onOff: true
    }
  }
  render() {
    const {data, lotno, goodsNum} = this.props;
    let newdata = data || {}
    let status_deleted = newdata.orderStatus == 1
    return (
     <table className="border_bottom">
      <tbody>
      {/*<tr className={!status_deleted ? 'hasDeleted' : ''}>*/}
      <tr>
       <td style={{width:'36%'}} >
        <div className="goods_div1">
         <Img style={{width:'105px',height:'105px',margin:'2px 5px 2px 0'}} src={newdata.goodsImage} />
         <div style={{margin:'18px 0 18px 15px',textAlign:'left'}}>
          <p style={{fontSize:'16px',color:'#333',lineHeight:'22px',marginBottom:'16px'}}>{newdata.goodsName}</p>
          {(newdata.brandName && newdata.goodsSerial) ?
           <p>品牌/原厂货号：<span>{newdata.brandName}/{newdata.goodsSerial}</span></p> :
           (newdata.brandName) ? <p>品牌：<span>{newdata.brandName}</span></p> :
            (newdata.goodsSerial) ? <p>原厂货号：<span>{newdata.goodsSerial}</span></p> : null
          }
          {(newdata.goodsErpCode) ? <p>国药编码：<span>{newdata.goodsErpCode}</span></p> : null}
          {(newdata.specName) ? <p>规格：<span>{newdata.specName}</span></p> : null}
          {(newdata.goodsSpec) ? <p>包装：<span>{newdata.goodsSpec}</span></p> : null}
          {(newdata.storageCondition && newdata.shippingCondition) ?
           <p>储存/运输条件：<span>{newdata.storageCondition}/{newdata.shippingCondition}</span></p> :
           (newdata.storageCondition) ? <p>储存条件：<span>{newdata.storageCondition}</span></p> :
            (newdata.shippingCondition) ? <p>运输条件：<span>{newdata.shippingCondition}</span></p> : null
          }
         </div>
        </div>
       </td>
       <td style={{width:'16%'}} >
        <div style={{padding: '0 10px',textAlign:'left'}}>
         { newdata.isReagent == '1' ?
          <div>
           {(newdata.casNo) ? <p>CAS号：<span>{newdata.casNo}</span></p> : null}

           {(newdata.dangerousNature) ? <p>危险性质：<span dangerouslySetInnerHTML={{ __html: newdata.dangerousNature }}></span></p> : null}
           {(newdata.controlInfo) ? <p>管制信息：<span style={{color: 'red'}} dangerouslySetInnerHTML={{ __html: newdata.controlInfo }}></span></p> : null}
          </div>
          : newdata.isReagent == '0' && newdata.goodsDescription ? <p className='describe'>描述：<span dangerouslySetInnerHTML={{ __html: newdata.goodsDescription.length > 80 ? newdata.goodsDescription.substr(0,80) + "..." : newdata.goodsDescription}}></span></p> : null
         }
        </div>
       </td>
       <td style={{width:'32%'}}>{lotno}</td>
       <td style={{width:'16%'}}>{goodsNum}</td>
      </tr>
      </tbody>
     </table>
    )
  }
}

export default connect(({order,refundList})=>({order,refundList}),(dispatch,own)=>{return {dispatch,own}})(RefundListFloor);
