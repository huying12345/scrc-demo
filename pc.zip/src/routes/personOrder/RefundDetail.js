import React, { Component } from 'react'
import { BodyHeadImg } from '../../components/Advertising/Advertising'
import { Breadcrumb, Button, Table, Row, Col, Upload, message, Form, Input, Icon, Modal } from 'antd'
import { Link } from 'dva/router'
import { connect } from 'dva'
import { refund_detail } from './RefundDetail.less'
import Img from "../../components/Img/Img"
import Search from '../../components/Search/Search'
import Navigation from '../../components/Navigation/Navigation'
import RefundDetailFloor from './RefundDetailFloor'
import {IMAGE_DOMAIN} from "../../utils/common"

const { TextArea } = Input;

const FormItem = Form.Item;

const formItemLayout = {
 labelCol: { span: 24 }
};

class RefundDetail extends Component {
  constructor(props) {
    super(props)
    this.state = {
      fileList: [],
      uploading: false,
     previewVisible: false,
     previewImage: '',
     addRemark: ''
    }
  }
 handleUpload = ({file,fileList}) => {
  if(file.status == 'done'){
   if(file.response.result == 0){
    message.error(file.response.msg);
    fileList.splice(0,1)
    this.setState({
     fileList
    })
    return
   }else{
    message.success(file.response.msg);
   }
  }else if(file.status === "error"){
   message.error("上传失败")
  }
  this.setState({ fileList })
 }
 handlePreview = (file) => {
  let suffix = file.name.split('.')
  suffix = suffix[suffix.length-1]
  if(suffix.indexOf('doc') > -1 || suffix.indexOf('pdf') > -1){
   window.open(`${IMAGE_DOMAIN}${file.response.data[0].filePath}`)
  }else{
   this.setState({
    previewImage: file.url || file.thumbUrl,
    previewVisible: true,
   });
  }
 }
 handleCancel = () => this.setState({ previewVisible: false })
 onChange = (e) => {
   this.setState({
    addRemark: e.target.value
   })
 }
 handleSubmit = () => {
  let files = []
  this.state.fileList.forEach(item=> {
   if(item.response && item.response.result==1){
    item.response.data[0] && item.response.data[0].filePath ? files.push(item.response.data[0].filePath) : null
   }
  })
  let val = {
   picInfo: files.join(','),
   addRemark: this.state.addRemark,
   refundId: this.props.refundDetail.refundDetailData.refundId
  }
  if(files.length || this.state.addRemark.trim()){
   this.props.dispatch({type: 'refundDetail/getReturnDetailEFF', val})
  }
 }
 handleSubmit1 = (e) => {
  e.preventDefault();
  this.props.form.validateFields((err, values) => {
   if (!err) {
    this.props.dispatch({type: 'refundDetail/getReturnDetailEFF', val:{...values,refundId: this.props.refundDetail.refundDetailData.refundId}})
   }
  });
 }
 cancelRefund = (refundId) => {
  this.props.dispatch({ type: 'refundDetail/cancelRefundEEF', refundId})
 }

  render() {
   const { getFieldDecorator } = this.props.form;
    let { refundDetailData } = this.props.refundDetail
   console.log(refundDetailData)
    const { uploading, previewVisible, previewImage, fileList } = this.state;
   const uploadButton = (
    <div>
     <Icon type="plus" />
     <div className="ant-upload-text">Upload</div>
    </div>
   );
   const formItemLayout = {
    labelCol: { span: 5 },
    wrapperCol: { span: 10 },
   };
    return (
      <div>
        <Search></Search>
        <Navigation preson={true}>
          <div className={refund_detail}>
            <div className="my_account_dynamic_Topimg"></div>
            <Breadcrumb separator=">" className='security_nav_bar'>
              <Breadcrumb.Item  href="/presonAccunt/myAccount">我的账户</Breadcrumb.Item>
              <Breadcrumb.Item href="/personOrder/returnApply">售后申请</Breadcrumb.Item>
              <Breadcrumb.Item href="/personOrder/refundList">售后申请记录</Breadcrumb.Item>
              <Breadcrumb.Item >售后申请详情</Breadcrumb.Item>
            </Breadcrumb>
            <div className="list_area">
              <p className="content_title">退货单信息：</p>
              { refundDetailData.refundState == '1' ? <div className="cancel_btn" onClick={()=>this.cancelRefund(refundDetailData.refundId)}>取消退货申请</div> : '' }
              <div className="list_detail">
                <Col span={8}>退货单编号：{refundDetailData.refundSn}</Col>
                <Col span={8}>单据状态：{refundDetailData.refundStateStr}</Col>
                <Col span={8}>提交时间：{refundDetailData.createTimeStr}</Col>
              </div>
              <div className="line"></div>
              <p className="content_title">退货申请详情：</p>
              <div className="list_detail">
                <Col span={8}>订单编号：{refundDetailData.orderSn}</Col>
                <Col span={8}>联系人：{refundDetailData.buyerName}</Col>
                <Col span={8}>联系电话：{refundDetailData.buyerTel}</Col>
              </div>
              <p className="content_title">所退商品：</p>
              <div className="orderList_content">
                <Row className="orderList_content_head">
                  <Col span={8}>基本信息</Col>
                  <Col span={4}>商品属性</Col>
                  <Col span={8}>批号</Col>
                  <Col span={4}>退货数量</Col>
                </Row>
              </div>
              <div>
                <RefundDetailFloor data={refundDetailData.goodsBean || {}} lotno={refundDetailData.lotno} goodsNum={refundDetailData.goodsNum}></RefundDetailFloor>
              </div>
              <div className="refund_reason">
               {
                refundDetailData.reasonInfo ?
                 <Row>
                  <Col span={3}>退货原因：</Col>
                  <Col span={20}>{refundDetailData.reasonInfo}</Col>
                 </Row> : null
               }
               {
                refundDetailData.buyerMessage ?
                 <Row>
                  <Col span={3}>退货退款说明：</Col>
                  <Col span={20}>{refundDetailData.buyerMessage}</Col>
                 </Row> : null
               }
                <Row>
                 {
                  refundDetailData.picInfo && refundDetailData.picInfo.split(',').length ?
                   <Col span={3}>附件上传：</Col> : null
                 }
                  <Col span={20}>
                   {
                    refundDetailData.picInfo && refundDetailData.picInfo.split(',').map((item,index) => {
                     return (
                      <Row key={index}>
                       <Col>附件{index+1} <a target="_black" href={`${IMAGE_DOMAIN}${item}`}>点击查看附件>></a></Col>
                      </Row>
                     )
                    })
                   }
                   { refundDetailData.refundState == '2'?
                    <Row>
                     {refundDetailData.isAddRemark == '0' ?
                      <Col span={3}>上传补充附件：</Col>
                      : null
                     }
                     <Col span={21}>
                      <div>
                       {refundDetailData.isAddRemark == '0' ?
                        <Upload
                         action="/reagent-front/orderApi/returnFilesUpload"
                         listType="picture-card"
                         onPreview={this.handlePreview}
                         onChange={this.handleUpload}
                         fileList={fileList}
                         multiple={true}
                        >
                         {uploadButton}
                        </Upload>
                        : null
                       }
                       <Modal visible={previewVisible} footer={null} onCancel={this.handleCancel}>
                        <img alt="example" style={{width: '100%'}} src={previewImage}/>
                       </Modal>
                      </div>
                     </Col>
                    </Row>
                    : '' }
                  </Col>
                </Row>
                { refundDetailData.refundState == '2'?
                  <Row style={{marginTop: '10px'}}>
                   {((refundDetailData.isAddRemark == '0' && !refundDetailData.addRemark) || (refundDetailData.isAddRemark == '1' && refundDetailData.addRemark))?
                    <Col span={3}>补充说明：</Col>
                    : null
                    }
                   {!refundDetailData.addRemark && refundDetailData.isAddRemark == '0'?
                   <Col span={20}>
                     <TextArea name="" id="" rows="6" value={this.state.addRemark} onChange={(e) => this.onChange(e)}></TextArea>
                     <Row>
                      <Col>
                       <Button className="submit_btn" onClick={()=>this.handleSubmit()}>提交</Button>
                      </Col>
                     </Row>
                    </Col>:
                    <Col>
                     {refundDetailData.addRemark}
                    </Col>
                    }
                  </Row>
                : '' }
              </div>
              {refundDetailData.refundState != '1' ?
                <div>
                  <div className="line"></div>
                  <p className="content_title">售后处理意见：{refundDetailData.returnLogList && refundDetailData.returnLogList[0] ? <span className="advise_time">处理时间：{refundDetailData.returnLogList && refundDetailData.returnLogList[0].createTimeStr }</span> : ''}</p>
                  <div className="content_text">
                    <p>客服已受理该售后申请，请您耐心等待。</p>
                    <p>如提交售后申请时信息填写不完整或客服要求提交其他信息，可在上述“补充说明”中填写完整。</p>
                  </div>
                </div>
              : ''}
              {refundDetailData.refundState != '1' && refundDetailData.refundState != '2' ?
                <div>
                  <div className="line"></div>
                  <p className="content_title">售后后续处理：{refundDetailData.returnLogList && refundDetailData.returnLogList[1] ? <span className="advise_time">处理时间：{refundDetailData.returnLogList && refundDetailData.returnLogList[1].createTimeStr }</span> : ''}</p>
                  <div className="content_text">
                   <Row style={{marginTop: '10px'}}>
                    <Col span={2} style={{textAlign:'right'}}>处理结果：</Col>
                    <Col span={22}>{refundDetailData.sellerStateStr}</Col>
                   </Row>
                   {refundDetailData.returnTypeStr ?
                   <Row style={{marginTop: '10px'}}>
                    <Col span={2} style={{textAlign:'right'}}>处理情况：</Col>
                    <Col span={22}>{refundDetailData.returnTypeStr}</Col>
                   </Row>
                    :null
                   }
                   {refundDetailData.sellerMessage ?
                    <Row style={{marginTop: '10px'}}>
                     <Col span={2} style={{textAlign: 'right'}}>客服备注：</Col>
                     <Col span={22}>{refundDetailData.sellerMessage}</Col>
                    </Row>
                    :null
                   }
                   {(refundDetailData.sellerState == '1' && refundDetailData.returnType == '1')?
                    <div>
                     <Row style={{marginTop: '10px'}}>
                      <Col>如您需要退货，请将商品包装完好，以快递或物流的形式寄回，不支持任何到付的寄送方式，退货/退发票信息具体请与客服联系。</Col>
                     </Row>
                     {/*<Row style={{marginTop: '10px'}}>*/}
                      {/*<Col>退货信息：</Col>*/}
                     {/*</Row>*/}
                     {/*<Row style={{marginTop: '10px'}}>*/}
                      {/*<Col span={2} style={{textAlign:'right'}}>收件人：</Col>*/}
                      {/*<Col span={22}>中国试剂网  唐欢凤 联系方式：021-37287115</Col>*/}
                     {/*</Row>*/}
                     {/*<Row style={{marginTop: '10px'}}>*/}
                      {/*<Col span={2} style={{textAlign:'right'}}>退货地址：</Col>*/}
                      {/*/!*<Col span={22}>上海市金山区合展路99号国药试剂</Col>*!/*/}
                      {/*<Col span={22}>具体与客服联系</Col>*/}
                     {/*</Row>*/}
                     {/*<Row style={{marginTop: '10px'}}>*/}
                      {/*<Col>退发票信息：</Col>*/}
                     {/*</Row>*/}
                     {/*<Row style={{marginTop: '10px'}}>*/}
                      {/*<Col span={2} style={{textAlign:'right'}}>收件人：</Col>*/}
                      {/*<Col span={22}>中国试剂网 联系方式：021-63210123</Col>*/}
                     {/*</Row>*/}
                     {/*<Row style={{marginTop: '10px'}}>*/}
                      {/*<Col span={2} style={{textAlign:'right'}}>退货地址：</Col>*/}
                      {/*<Col span={22}>上海市黄浦区宁波路52号国药试剂营销中心客服部</Col>*/}
                     {/*</Row>*/}
                    </div> : null
                   }
                  </div>
                </div>
              : ''}
              {refundDetailData.refundState != '1' && refundDetailData.refundState != '2' && refundDetailData.sellerState == '1' && refundDetailData.returnType == '1' ?
                <div>
                  <div className="line"></div>
                  <p className="content_title">用户退货物流信息：{refundDetailData.returnLogList && refundDetailData.returnLogList[2] ? <span className="advise_time">处理时间：{refundDetailData.returnLogList && refundDetailData.returnLogList[2].createTimeStr }</span> : ''}</p>
                 {((refundDetailData.expressName || refundDetailData.invoiceNo || refundDetailData.refundRemark) && (refundDetailData.refundState != '1' || refundDetailData.refundState != '2')) ?
                   <div className="content_input">
                    <Row style={{marginTop: '10px'}}>
                     <Col span={4}>退货快递或物流公司：</Col>
                     <Col span={20}>{refundDetailData.expressName}</Col>
                    </Row>
                    <Row style={{marginTop: '10px'}}>
                     <Col span={4}>快递或物流单号：</Col>
                     <Col span={20}>{refundDetailData.invoiceNo}</Col>
                    </Row>
                    <Row style={{marginTop: '10px'}}>
                     <Col span={4}>退货备注：</Col>
                     <Col span={20}>{refundDetailData.refundRemark}</Col>
                    </Row>
                   </div> :
                   <div className="content_input">
                    <Form onSubmit={this.handleSubmit1} layout="inline">
                     <FormItem
                      {...formItemLayout} label={<span style={{color:'rgba(0,0,0,0.65)'}}>退货快递或物流公司</span>} style={{width: '640px'}}>
                      {getFieldDecorator('expressName',{
                       rules: [{ required: true, message: '退货快递或物流公司不能为空' }]
                      })(
                       <Input/>
                      )}
                     </FormItem>
                     <FormItem
                      {...formItemLayout} label={<span style={{color:'rgba(0,0,0,0.65)'}}>快递或物流单号</span>} style={{width: '640px'}}>
                      {getFieldDecorator('invoiceNo',{
                       rules: [{ required: true, message: '快递或物流单号不能为空' }]
                      })(
                       <Input/>
                      )}
                     </FormItem>
                     <FormItem
                      {...formItemLayout} label={<span style={{color:'rgba(0,0,0,0.65)'}}>退货备注</span>} style={{width: '640px'}}>
                      {getFieldDecorator('refundRemark',{
                       rules: [{ required: true, message: '退货备注不能为空' }]
                      })(
                       <Input/>
                      )}
                     </FormItem>
                     <Button htmlType="submit" type='primary' style={{display:'block',marginLeft:'220px'}}>提交</Button>
                    </Form>
                    {/*<Row><Col span={4}>退货快递或物流公司：</Col><Col span={8}><Input/></Col><Col span={1}><span>*</span></Col></Row>*/}
                    {/*<Row><Col span={4}>快递或物流单号：</Col><Col span={8}><Input/></Col><Col span={1}><span>*</span></Col></Row>*/}
                    {/*<Row><Col span={4}>退货备注：</Col><Col span={8}><Input/></Col><Col span={1}><span>*</span></Col></Row>*/}
                   </div>
                 }
                  {/*<span className="submit">提交</span>*/}
                </div>
              : ''}
              {refundDetailData.sellerState == '1' && refundDetailData.refundState == '5' && refundDetailData.refundMessage ?
                <div>
                  <div className="line"></div>
                  <p className="content_title">退款情况：
                   {refundDetailData.returnLogList && refundDetailData.returnLogList[3] ? <span className="advise_time">处理时间：{refundDetailData.returnLogList && refundDetailData.returnLogList[3].createTimeStr }</span> : ''}</p>
                  <div className="content_text">
                    <p>{refundDetailData.refundMessageStr}</p>
                  </div>
                </div>: null}
            </div>
          </div>
        </Navigation>
      </div>
    )
  }
}

export default connect(({ refundDetail }) => ({ refundDetail }), (dispatch) => { return { dispatch } })(Form.create()(RefundDetail))
