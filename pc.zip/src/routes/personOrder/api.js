import { get ,post} from '../../utils/request';

// 打印pdf文件
export function printCartPDF(cartId){
    return post('/tradeApi/printCartPDF',cartId)
}
export function printOrderPDF(orderId){
    return get('/orderApi/printOrderDetailPDF',orderId)
}
// 导出Excel
export function exportOrderAPI(val){
    return get('/orderApi/exportOrderListExcel',val)
   }

// 导出验收直拨单
export function exportOrderDirectDialAPI(val){
    return get('orderApi/printOrderDetailPDF',val)
   }

  
