import React, { Component } from 'react';
import { connect } from 'dva';
import { routerRedux,Link} from 'dva/router';
import { Row,Col,Menu, Dropdown,Icon,Breadcrumb,Input,Button,Pagination} from 'antd';
import Img from '../../components/Img/Img';

class RefundDetailFloor extends Component {
  constructor(props) {
    super(props)
    this.state = {
      data: props.data,
      goodsData: props.data.orderItemsList,
      isGivePrice: props.isGivePrice
      // onOff: true
    }
  }
  render() {
    const {data,lotno,goodsNum} = this.props;
    return (
      <div>
       <table className="border_bottom">
        <tbody>
        <tr>
         <td style={{width:'38%'}} >
          <div className="goods_div1">
           <Img style={{width:'105px',height:'105px',margin:'2px 5px 2px 0'}} src={data.goodsImage} />
           <div style={{margin:'18px 0 18px 15px',textAlign:'left'}}>
            <p style={{fontSize:'16px',color:'#333',lineHeight:'22px',marginBottom:'16px'}}>{data.goodsName}</p>
            {(data.brandName && data.goodsSerial) ?
             <p>品牌/原厂货号：<span>{data.brandName}/{data.goodsSerial}</span></p> :
             (data.brandName) ? <p>品牌：<span>{data.brandName}</span></p> :
              (data.goodsSerial) ? <p>原厂货号：<span>{data.goodsSerial}</span></p> : null
            }
            {(data.goodsErpCode) ? <p>国药编码：<span>{data.goodsErpCode}</span></p> : null}
            {(data.specName) ? <p>规格：<span>{data.specName}</span></p> : null}
            {(data.goodsSpec) ? <p>包装：<span>{data.goodsSpec}</span></p> : null}
            {(data.storageCondition && data.shippingCondition) ?
             <p>储存/运输条件：<span>{data.storageCondition}/{data.shippingCondition}</span></p> :
             (data.storageCondition) ? <p>储存条件：<span>{data.storageCondition}</span></p> :
              (data.shippingCondition) ? <p>运输条件：<span>{data.shippingCondition}</span></p> : null
            }
           </div>
          </div>
         </td>
         <td style={{width:'14%'}} >
          <div style={{padding: '0 10px',textAlign:'left'}}>
           { data.isReagent == '1' ?
            <div>
             {(data.casNo) ? <p>CAS号：<span>{data.casNo}</span></p> : null}

             {(data.dangerousNature) ? <p>危险性质：<span dangerouslySetInnerHTML={{ __html: data.dangerousNature }}></span></p> : null}
             {(data.controlInfo) ? <p>管制信息：<span style={{color: 'red'}} dangerouslySetInnerHTML={{ __html: data.controlInfo }}></span></p> : null}
            </div>
            : data.isReagent == '0' && data.goodsDescription ? <p className='describe'>描述：<span dangerouslySetInnerHTML={{ __html: data.goodsDescription.length > 80 ? data.goodsDescription.substr(0,80) + "..." : data.goodsDescription}}></span></p> : null
           }
          </div>
         </td>
         <td style={{width:'32%'}}>{lotno}</td>
         <td style={{width:'16%'}}>{goodsNum}</td>
        </tr>
        </tbody>
       </table>
      </div>
    )
  }
}

export default connect(({order,refundDetail})=>({order,refundDetail}),(dispatch,own)=>{return {dispatch,own}})(RefundDetailFloor);
