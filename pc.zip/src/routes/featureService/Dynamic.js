import React, { Component } from 'react'
// import { brand_dynamic } from './Brand.less'
import { BodyHeadImg } from '../../components/Advertising/Advertising'
import { connect } from 'dva'
import { Icon } from 'antd'
import Img from "../../components/Img/Img";
import { featureService_dynamic } from './FeatureService.less'

class Dynamic extends Component{

  constructor(props){
    super(props)   
    this.state = {
      headImage:'',
    }
  }
  onClickJump=(type,parentId,path,inputPath,articleId,navId)=>{

    if(parentId=='1'){
       parentId='';
    }
    if(type=='-1'){
 
      if(path=='/'){this.props.dispatch(routerRedux.push(`/`));}
     
       if(!!path&&path!=''){
             let values = "parentId=" + parentId+"";
            this.props.dispatch(routerRedux.push(`${path}?${values}`));
       }else{
         console.log('不跳转')
       }
    }else if(type=='0'){
       let outlinkPath=window.open('about:blank');
       console.log('跳转url');
        if(!!inputPath&&inputPath!=''){
          console.log(inputPath);
          outlinkPath.location.href=inputPath
        }
      
    }else if(type=='1'){
     console.log('跳转图片');
    }else if(type=='2'){
       if(articleId==''||articleId=='undefined'){
         console.log('文章没有articleId')
       }else{
           let values =''
           if(navId!=1){
            values = "parentId=" + parentId +"&articleId=" + articleId+"&navType="+navId+""; 
           }else{
             values = "parentId=" + parentId +"&articleId=" + articleId+"";
           }
           this.props.dispatch(routerRedux.push(`${path}?${values}`));
           
       }
    }
 
   }

   componentWillReceiveProps(nextProps) {  
    // console.log(nextProps.location)
    if (this.props.location !== nextProps.location) {
      // console.log('路由切换')
      this.props.dispatch({type: 'technology/clearSixData',});
    }
   }



  render () {
    const { data ,navlistSixData} = this.props.featureService;
    let { articleContentData} =this.props.app;
    return (
      <div className={featureService_dynamic}>
       {/* <BodyHeadImg headImg={data[0].headImg}/>*/}
        {/* <div className="featureService_dynamic_Topimg"></div>*/}
         {/*<Img src= {this.state.headImage}  style={{width:'960px',height:'70px'}}/>*/}
        {articleContentData&&  articleContentData[0] && articleContentData[0].headImage?
          <Img src= {articleContentData[0].headImage }  style={{width:'960px',height:'70px'}}/>:<div></div>
         }
           <div>
            {
              navlistSixData&&navlistSixData.length>0&&navlistSixData.map((item,indx)=>{
                let parentId=7;
                let path = item.navUrl;
                let inputPath = item.url;
                let type = item.type;
                let articleId=item.articleId;
                
                let navId='1'
                return(
                  <i className='sixNav' key={indx}
                     onClick={()=>this.onClickJump(type,parentId,path,inputPath,articleId,navId)}
                  >{item.navTitle}</i>
                )
              })
            }  
         </div>
        <div style={{minHeight:'400px'}}>           
              {
                articleContentData &&  articleContentData[0] && articleContentData[0].articleContent?
                     <div dangerouslySetInnerHTML={{ __html:articleContentData[0].articleContent }}></div>
                     :'无内容'
              }
        </div>
      </div>
    )
  }
}
export default connect(({featureService,app})=>({featureService,app}),(dispatch,own)=>{return {dispatch,own}})(Dynamic)
