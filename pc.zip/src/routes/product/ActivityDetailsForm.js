import React, {Component} from 'react'
import {connect} from 'dva'
import Img from "../../components/Img/Img";
import {advanced_search_form_row} from './Product.less'
import {Form, Row, Col, Button, Icon, Radio, Input, DatePicker, Checkbox} from 'antd';
import {activity_details_explain} from './ActivityDetailsForm.less';
import moment from 'moment';
import {IMAGE_DOMAIN} from '../../utils/common'

const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const {RangePicker} = DatePicker;
const { TextArea } = Input;
const nowDate = new Date()

// function getNowFormatDate() {
//  var date = new Date();
//  var seperator1 = "-";
//  var year = date.getFullYear();
//  var month = date.getMonth() + 1;
//  var strDate = date.getDate();
//  if (month >= 1 && month <= 9) {
//   month = "0" + month;
//  }
//  if (strDate >= 0 && strDate <= 9) {
//   strDate = "0" + strDate;
//  }
//  var currentdate = year + seperator1 + month + seperator1 + strDate;
//  return currentdate;
// }
// nowDate = getNowFormatDate(nowDate)
console.log(nowDate)

const formItemLayout = {
 labelCol: {
  xs: {span: 10},
  sm: {span: 10},
 },
 wrapperCol: {
  xs: {span: 13},
  sm: {span: 13},
 },
};
const tailFormItemLayout = {
 labelCol: {
  xs: {span: 5},
  sm: {span: 5},
 },
 wrapperCol: {
  xs: {span: 18},
  sm: {span: 18},
 },
};


function displayRender(label) {
 return label[label.length - 1];
}


class ActivityDetailsForm extends Component {
 constructor(props) {
  super(props);
  this.state = {
   value: 1,
   companyType: 1,
   companyproduct:1,
   uspStandard:0
  }
 }

 onChangeCompanyType = (type) => {
  this.setState({companyType: type})
 }
 onChangeCompanyproductType= (type) => {
  this.setState({companyproduct: type})
 }
 onuspStandardChange = (e) => {
  this.setState({uspStandard: e.target.value})
 }

 handleSubmit = (e) => {
  const data = this.props.data;
  e.preventDefault();
  this.props.form.validateFieldsAndScroll((err, values) => {
   if(!err){
    values.signTime = values.signTime.format('YYYY-MM-DD')
    values.activityId = data.id
    values.activityName = data.activityName
    console.log(values);
    this.props.handleSubmit(values)
   }
  });
 }

 render() {
  const {getFieldDecorator} = this.props.form;
  const data = this.props.data;
  const radioStyle = {
   display: 'block',
   height: '30px',
   lineHeight: '30px',
  };
//   console.log(data)
  return (
   <Form
    onSubmit={this.handleSubmit}
   >
    <Row>
     <Col span={12}>
      <FormItem
       label="报名日期Date"
       {...formItemLayout}>
       {getFieldDecorator('signTime',{initialValue: moment(nowDate)},
        {
         rules: [{
          required: true,
          message: '报名日期Date！',
         }],
        })(
        <DatePicker
         showTime
         format="YYYY-MM-DD"
         placeholder="报名日期Date"
        />
       )}
      </FormItem>
     </Col>
    </Row>
    <p style={{margin: '10px auto', textAlign: 'center'}}>报名人信息</p>
    <p style={{margin: '10px auto 20px',textAlign: 'center'}}>Applicants Information</p>
    <Row>
     <Col span={12}>
      <FormItem
       {...formItemLayout}
       label="客户姓名 Name of Contac">
       {getFieldDecorator('contactName', {
        rules: [{
         required: true,
         message: '请输入客户姓名！',
        }],
       })(
        <Input/>
       )}
      </FormItem>
     </Col>
     <Col span={12}>
      <FormItem
       {...formItemLayout}
       label="部门/职务Dept./Position">
       {getFieldDecorator('deptPosition', {
        rules: [{
         required: true,
         message: '请输入职务！',
        }],
       })(
        <Input type="text"/>
       )}
      </FormItem>
     </Col>
    </Row>

    <Row>
     <Col span={12}>
      <FormItem
       {...formItemLayout}
       label="公司电话Company Telephone">
       {getFieldDecorator('companyTel', {
        rules: [{
         required: true,
         message: '请输入电话！',
        }],
       })(
        <Input/>
       )}
      </FormItem>
     </Col>
     <Col span={12}>
      <FormItem
       {...formItemLayout}
       label="手机Mobile phone">
       {getFieldDecorator('mobile', {
        rules: [{
         len: 11,
         pattern: /^1[0-9]{10}$/,
         required: true,
         message: '请输入正确的手机号！',
        }],
       })(
        <Input/>
       )}
      </FormItem>

     </Col>
    </Row>
    <Row>
     <Col span={12}>
      <FormItem
       {...formItemLayout}
       label="传真Fax">
       {getFieldDecorator('fax', {
        rules: [{
         required: true,
         message: '请输入传真！',
        }],
       })(
        <Input/>
       )}
      </FormItem>
     </Col>
     <Col span={12}>
      <FormItem
       {...formItemLayout}
       label="电子邮箱">
       {getFieldDecorator('email', {
        rules: [{
         type: 'email',
         required: true,
         message: '请输入电子邮箱！',
        }],
       })(
        <Input/>
       )}
      </FormItem>
     </Col>
    </Row>
    <Row>
     <Col span={12}>
      <FormItem
       {...formItemLayout}
       label="公司名称Company Name">
       {getFieldDecorator('companyName', {
        rules: [{
         required: true,
         message: '请输入公司名称！',
        }],
       })(
        <Input/>
       )}
      </FormItem>
     </Col>
     <Col span={12}>

      <FormItem
       {...formItemLayout}
       label="公司网址Web">
       {getFieldDecorator('website', {
        rules: [{
         // required: true,
         message: '请输入公司网址！',
        }],
       })(
        <Input/>
       )}
      </FormItem>
     </Col>
    </Row>
    <FormItem
     {...tailFormItemLayout}
     label="公司地址Company Address">
     {getFieldDecorator('companyAddr', {
      rules: [{
       required: true,
       message: '请输入公司地址！',
      }],
     })(
      <Input/>
     )}
    </FormItem>
    <FormItem
     {...tailFormItemLayout}
     label="公司性质Company Category">
     {getFieldDecorator('companyType', {initialValue: this.state.companyType}, {
      rules: [{
       required: true,
       message: '请选择公司性质！',
      }],
     })(
      <RadioGroup name="CompanyCategory">
       <Radio value={this.state.companyType < 4 ? this.state.companyType : 1}
              onClick={() => this.onChangeCompanyType(1)} style={{width: '100%'}}>生产类企业Manufacturer
        (
        <RadioGroup value={this.state.companyType < 4 ? this.state.companyType : ""}>
         <Radio disabled={this.state.companyType < 4 ? false : true} value={1}
                onClick={() => this.onChangeCompanyType(1)}>原材料</Radio>
         <Radio disabled={this.state.companyType < 4 ? false : true} value={2}
                onClick={() => this.onChangeCompanyType(2)}>制剂</Radio>
         <Radio disabled={this.state.companyType < 4 ? false : true} value={3}
                onClick={() => this.onChangeCompanyType(3)}>其他</Radio>
        </RadioGroup>
        )
       </Radio>
       <Radio onClick={() => this.onChangeCompanyType(4)} value={4}>贸易类企Ttader</Radio>
       <Radio onClick={() => this.onChangeCompanyType(5)} value={5}>咨询类企业Consultlting Company</Radio>
       <Radio onClick={() => this.onChangeCompanyType(6)} value={6}>政府机构Government labs</Radio>
       <Radio onClick={() => this.onChangeCompanyType(7)} value={7}>研发类企业R&D Company</Radio>
       <Radio onClick={() => this.onChangeCompanyType(8)} value={8}>
        其他，请注明：Others,please specify:
        {this.state.companyType === 8 ?
         <FormItem>
         {getFieldDecorator('companyTypeRemark', {
          rules: [{
          required: true,
          message: '请对公司类型说明！',
         }],})(
          <Input style={{width: '300px', marginLeft: 10}}/>
         )}
        </FormItem> : null}
       </Radio>
      </RadioGroup>
     )}
    </FormItem>
    {/*<FormItem*/}
     {/*{...tailFormItemLayout}*/}
     {/*label="公司产品Company product">*/}
     {/*{getFieldDecorator('companyproduct', {initialValue: 1}, {*/}
      {/*rules: [{*/}
       {/*required: true,*/}
       {/*message: '请选择公司产品！',*/}
      {/*}],*/}
     {/*})(*/}
      {/*<RadioGroup>*/}
       {/*<Radio style={radioStyle} value={1} onClick={() => this.onChangeCompanyproductType(1)}>化药</Radio>*/}
       {/*<Radio style={radioStyle} onClick={() => this.onChangeCompanyproductType(11)} value={11}>生化药*/}
        {/*(*/}
        {/*<RadioGroup value={this.state.companyproduct > 10 ? this.state.companyproduct : ""}>*/}
         {/*<Radio disabled={this.state.companyproduct > 10 ? false : true} onClick={() => this.onChangeCompanyproductType(11)} value={11}>多肽</Radio>*/}
         {/*<Radio disabled={this.state.companyproduct > 10 ? false : true} onClick={() => this.onChangeCompanyproductType(12)} value={12}>蛋白</Radio>*/}
         {/*<Radio disabled={this.state.companyproduct > 10 ? false : true} onClick={() => this.onChangeCompanyproductType(13)} value={13}>单抗</Radio>*/}
         {/*<Radio disabled={this.state.companyproduct > 10 ? false : true} onClick={() => this.onChangeCompanyproductType(14)} value={14}>多糖</Radio>*/}
         {/*<Radio disabled={this.state.companyproduct > 10 ? false : true} onClick={() => this.onChangeCompanyproductType(15)} value={15}>血液制品</Radio>*/}
         {/*<Radio disabled={this.state.companyproduct > 10 ? false : true} onClick={() => this.onChangeCompanyproductType(16)} value={16}>其他</Radio>*/}
        {/*</RadioGroup>*/}
        {/*)*/}
       {/*</Radio>*/}
      {/*</RadioGroup>*/}
     {/*)}*/}
    {/*</FormItem>*/}
    <FormItem
     {...tailFormItemLayout}
     label="USP标准的用途 Use of USP Standards">
     {getFieldDecorator('uspStandard', {initialValue: "1"}, {
      rules: [{
       required: true,
      }],
     })(
      <RadioGroup onChange={this.onuspStandardChange}>
       <Radio style={radioStyle} value={1}>用于出口产品Export Products</Radio>
       <Radio style={radioStyle} value={2}>用于国内销售产品Domestic Products</Radio>
       <Radio style={radioStyle} value={3}>
        其他，请注明：Others,please specify:
        {this.state.uspStandard === 3 ?
         <FormItem>
         {getFieldDecorator('uspStandardRemak', {
          rules: [{
           required: true,
           message: '请对USP标准用途说明！',
          }],})(
          <Input style={{width: '300px', marginLeft: 10}}/>
         )}
        </FormItem> : null}
       </Radio>
      </RadioGroup>
     )}
    </FormItem>
    <FormItem
     label="请简要说明您参加此次活动的目的或者期望"
    >
     {getFieldDecorator('remark', {})(
      <TextArea type="text" style={{width: '80%', height: '150px'}}/>
     )}
    </FormItem>
    <div className={activity_details_explain}>
     <p>备注:</p>
     <p>
      <span>1、一人一表，请勿混合填写</span>
      <i>Remarks:One from for one applocant only.</i>
     </p>
     <p>
      <span>2、请将信息填写完整，不完整得报名表可能被视做无效而导致收不到确认函。</span>
      <i>Remarks:Please fill in the form completely,incomplete from may be considered invalid.</i>
     </p>
     <p>
      <span>3、本次活动日程表中提及的活动与用餐均为免费，其余费用自理。</span>
      <i>Remarks:The participation to the activities and lunch mentioned in the agenda is free of charge.</i>
     </p>
     <p style={{marginTop: '24px'}}>
          {data.remark}
          {/* 若您希望报名参加此次活动，请于2010年11月7日去登录:http://vip.reagent.com.cn/yhlt/yhltsh.jsp进行网上报名或者填写所附报名表发至以下邮箱。因名额所限，同一公司参会名额上限位3人，超过截至日期或者满员将不再接受报名，请予谅解。 */}
      </p>
     <p>请点击此处<a style={{color: 'red'}} target="_blank" href={IMAGE_DOMAIN + data.activityFile}>下载</a>报名表，用于传真或EMAIL报名</p>
     <p>邮箱 Email: {data.activityEmail}</p>
     <p>报名联系人: {data.activityContact}</p>
     <p>电话Tel: {data.activityTel}</p>
     <p style={{marginTop: '24px'}}>注：本次活动由USP标准品授权代理商国药集团化学试剂有限公司协办</p>
     <p>Remarks:This event is sponsored by SCRC,Usp Authorized Distributor for Reference Standards.</p>
    </div>

    <Row style={{margin: '24px 0'}}>
     <Col span={13} style={{textAlign: 'right'}}>
      <Button type="primary" htmlType="submit" style={{width: '110px', borderRadius: 0}}>确定</Button>
     </Col>
    </Row>
   </Form>
  );
 }
}

const AllActivityDetailsForm = Form.create()(ActivityDetailsForm)

export default (AllActivityDetailsForm)
