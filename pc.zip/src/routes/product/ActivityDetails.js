import React, { Component } from 'react'
import { connect } from 'dva'
import {activity_details,activity_details_title,activity_details_from,USP_dynamic_Toping} from './ActivityDetails.less';
import { routerRedux, Link } from 'dva/router';
import ActivityDetailsForm from './ActivityDetailsForm'
import {Pagination, Icon,Button,message} from 'antd'


class ActivityDetails extends Component {
 constructor(props) {
  super(props);
  this.state = {}
 }
 handleSubmit=(values) => {
  this.props.dispatch({ type: 'product/saveActivityInfo', values:values })
 }
   componentDidMount(){

        let status = this.props.product.dataStatue && this.props.product.dataStatue.data && this.props.product.dataStatue.data[0] && this.props.product.dataStatue.data[0].status? this.props.product.dataStatue.data[0].status:'3'
        console.log(status)
        if(status==0){
            console.log(status)
            var iTem= setInterval(
              ()=>{
                 this.props.dispatch(routerRedux.push(`/`));
              }
              ,500)
            setInterval(()=>{
                  clearInterval(iTem);
            },1000)
        }
   }

  render() {
   const {data} = this.props.product;
   let newdata = !!data.data && data.data[0] || {}
    return (
      <div>
         {newdata.status==0?
           null:
          <div className={activity_details}>
            <div className={USP_dynamic_Toping}></div>
            <div className={activity_details_title}>

              <p>USP User Forum</p>
              <p>USP用户论坛</p>
              <p>{newdata.activityDateStr + "," + newdata.activityEnCity + "," + newdata.activityEnCountry}</p>
              <p>{newdata.activityCountry + ","+ newdata.activityCity + "," + newdata.activityDateStrC}</p>
              <p style={{fontSize:'16px',color:'#3497ce',marginBottom:'20px'}}>Registration From 报名表</p>
            </div>
            <div className={activity_details_from}>
                <ActivityDetailsForm data={newdata}  handleSubmit={this.handleSubmit}/>
            </div>
          </div>
        }
      </div>
    );
  }
}
export default connect(({product}) => ({product}), (dispatch,own) => {return {dispatch,own}})(ActivityDetails)
