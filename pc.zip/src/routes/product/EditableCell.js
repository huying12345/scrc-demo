import React, {Component} from 'react';
import {IMAGE_DOMAIN} from '../../utils/common';
import Stepper from '../../components/Stepper/Stepper'
import {
 Form,
 Icon,
 Input,
 Button,
 message,
 Select,
 Radio,
 Menu,
 Pagination,
 Tree,
 Checkbox,
 Modal,
 Tabs,
 Table,
 Popconfirm
} from 'antd';

import {goodsbatchlist} from './quickOrderAPI';
import {editable_cell} from './EditableCell.less'

const FormItem = Form.Item;
const Option = Select.Option;
const TreeNode = Tree.TreeNode;
const TabPane = Tabs.TabPane;

class EditableCell extends Component {
 constructor(props) {
  super(props);
  this.timerl = null;
  this.state = {
   value: '',
   visible: false,
   goodsbatchlist: [],
   storeId: '',
   index: 0
  }
 }


 handleChange = (e) => {
  const value = e.target.value;
  if (this.state.value == false) {
   this.setState({value, visible: true});
   this.props.visibleIndexCalBack(this.props.index);
  } else if (this.state.value != '' && e.target.value == '' && this.state.visible == true) {
   this.setState({value, visible: false, index: 0});
   this.props.visibleIndexCalBack('');
  } else {
   this.setState({value});
   this.props.visibleIndexCalBack(this.props.index);
  }

 }

 handleTime = () => {
  if(this.state.value!=''){

  
  goodsbatchlist({keyword: this.state.value, pageNo: 1}).then((r) => {
   if (r.result == 1) {
    this.setState({
     goodsbatchlist: r.data,
    });
    if (r.data.length > 0) {
     //判断是否加入采购订单
     r.data.map((adv, index) => {
    //  console.log(adv)
      let {dataSource} = this.props;
      this.state.goodsbatchlist
      let hasItem = dataSource.findIndex((v, i, a) => (v.goodsId == adv.goodsId));
      if (hasItem == -1) {
       //没加入过，加入列表
       // this.setState({  visible:false, index:0 });
       this.props.hanldAddList(adv, this.props.index);
      } else {
       message.error('已经加入采购订单了', 1.5);
      }
     })
    }else{
     message.error('请输入正确的国药编码', 1.5);
    }
   } else {
    message.error('请输入正确的国药编码', 1.5);
   }
  })
 }
}

 componentDidUpdate(pp, ps) {
  if (pp.selectStore != this.props.selectStore && this.state.visible && this.props.index == this.props.visibleIndex) {
   goodsbatchlist({keyword: this.state.value, pageNo: 1}).then((r) => {
    //console.log(r);
    if (r.result == 1) {
     this.setState({
      goodsbatchlist: r.data
     });
    }
   })
  } else if (this.state.value != '' && this.props.index != this.props.visibleIndex) {
   this.setState({
    value: ''
   });
  }
 }

 componentWillUnmount() {
  document.body.removeEventListener('keydown', this.handleKeyDown);
  clearTimeout(this.timerl)
 }

 componentDidMount() {
  document.body.addEventListener('keydown', this.handleKeyDown)
 }

 handleKeyDown = (e) => {
  let ev = e || window.event;
  switch (ev.keyCode) {
   case 13:
    ev.preventDefault();
    this.handleTime()
    break;
  }
 }





 render() {
  const {value} = this.state;
  return (
   <div id="quickordertable" className={editable_cell}>
    <div className="editable-cell-input-wrapper">
     <Input
      value={value}
      onChange={this.handleChange}
      onBlur={this.handleTime}
     />
    </div>
   </div>
  );
 }
}

export default EditableCell;
