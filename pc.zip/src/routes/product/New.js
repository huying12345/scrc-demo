import React, { Component } from 'react'
import { connect } from 'dva'
import { Link } from 'dva/router'
import { Pagination } from 'antd'
import { product_new } from './Product.less'
import Img from "../../components/Img/Img";
import { BodyHeadImg } from '../../components/Advertising/Advertising'

class New extends Component{
  onChange = (pageNumber) => {
    console.log('Page: ', pageNumber);
    this.props.dispatch({type:'product/getNewProductsEFF',page:{pageSize:12, pageNo:pageNumber}})
  }
  clickNumCount=(advId)=>{
   this.props.dispatch({type: 'product/clickNumEFF', advId:advId})
 }

  render () {
    let {pageinfo, data} = this.props.product
    return (
      <div className={product_new}>
       {/* <BodyHeadImg headImg={data[0].headImg}/>*/}
        <div className="new_Topimg">
         <Img src="/static/head/新品上市.jpg"/>
        </div>
        {/* <div className={`${pageinfo.classname}`}>{pageinfo.title}</div> */}
        <div className='product_new_body'>
          {
           !!data.data && !!data.data[0]  && data.data[0].advList.length ? data.data[0].advList.map((item,index) => {
              return <div key={index}>
                <Link to={item.advUrl} target="_blank">
                  <Img src={item.resUrl}   onClick = {() => this.clickNumCount(item.advId)}/>
                  <p   onClick = {() => this.clickNumCount(item.advId)}>{item.advTitle}</p>
                </Link>
              </div>
            }) : null
          }
        </div>
        <Pagination showQuickJumper defaultCurrent={1} total={data.count} onChange={this.onChange} />
      </div>
    )
  }
}
export default connect(({product})=>({product}))(New)
