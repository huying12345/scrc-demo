
import React , { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'dva';
import { routerRedux, Link } from 'dva/router';
import { Breadcrumb,Collapse ,Button,Select,Form,Input,Icon,Table,Modal, Row, Col, message ,Popconfirm } from 'antd';
import Img from '../../components/Img/Img';
const FormItem = Form.Item;
const Option = Select.Option;
const Panel = Collapse.Panel;
const confirm = Modal.confirm;

import moment from 'moment';

import { getPurTemplateItemAPI, deletePurTemplateAPI, deletePurTemplateItemAPI } from './api';
import Stepper from '../../components/Stepper/Stepper'
import { panel } from './purchaseTempletPanel.less';

const formItemLayout = {
  labelCol: { span: 4 },
  wrapperCol: { span: 16 },
};

class  PurchaseTempletPanel extends Component{
  constructor(props){
    super(props);
    this.state= {
      id: '',
      data: [],
      pageNo:1,
      totalRows:'',
      pageSize:10,
      selectedRowKeys:[],
      selectedRows:[],
      visible:false,
      templateId:this.props.Item.templateId,
    }
  }

  columns = [
    {
      title: '序号',
      dataIndex: 'index',
      key:'index',
      width: '5%',
      render:(text, record, index) => (
        <div>{ index+1 }</div>
      )
    },{
    title: '商品信息',
    dataIndex: 'goodsName',
    key:'goodsName',
    width: '30%',
    render: (text, record,index) => {
      return <div style={{textAlign:"left"}}>
        <div className='clearfix'>
          <Row style={{textAlign:'left'}}>
            <Col span={24}>品名：<span style={{color:'#3c8abb',fontWeight:'bold'}}>{record.goodsName}</span></Col>
          </Row>
          <Row style={{textAlign:'left'}}>
            <Col span={24}>国药编码：<span style={{color:'#3c8abb',fontWeight:'bold'}}>{record.goodsCode}</span></Col>
          </Row>
          <Row style={{textAlign:'left'}}>
            <Col span={24}>CAS号：<span style={{color:'#3c8abb',fontWeight:'bold'}}>{record.casNo}</span></Col>
          </Row>
        </div>         
      </div>
    },
  }, {
    title: '订购信息',
    dataIndex: 'goodsSpec',
    key:'goodsSpec',
    width: '35%',
    render:(text,record, index)=>{
      return (
        <div style={{fontSize:'.8rem'}}>
          <Row style={{textAlign:'left'}}>
            <Col span={12}>品牌：<span style={{color:'#3c8abb',fontWeight:'bold'}}>{record.brandName}</span></Col>
            <Col span={12}>原厂货号：<span style={{color:'#3c8abb',fontWeight:'bold'}}>{record.goodsSerial}</span></Col>
          </Row>
          <Row style={{textAlign:'left'}}>
            <Col span={12}>规格：<span style={{color:"#3c8abb", fontWeight:'bold'}}>{record.specName}</span></Col>
            <Col span={12}>包装：<span style={{color:'#3c8abb',fontWeight:'bold'}}>{record.goodsSpec}</span></Col>
          </Row>
        </div>
      )
    }
  },{
      title: '订购数量',
      dataIndex: 'purchasing',
      key:'purchasing',
      width: '10%',
      render:(text,record, index)=>{
          return (
            <Stepper
              nowNum={100000000000000000}
              btnClassName='btnClass'
              inputClassName='inputClass'
              num={record.buyNum}
              min={1}
              max={100000000000000000}
              step={1}
              onUpdate={(val)=>this.updateCart(record.goodsId,val)} 
              disabled={false}
              />
          )

      }
    },{
      title: '操作',
      dataIndex: 'operation',
      key:'operation',
      width: '10%',
      render: (text, record, index) => {
        // console.log(record)
        return (
          record.goodsId!='' ?
            (   
              <Button style={{ marginRight:'10px' }}
                      onClick={  () => this.onDelete2(record.itemId) }  
              >删除产品</Button>
              // <Popconfirm title="确定要删除吗？" onConfirm={() => this.onDelete2(record.itemId)}>
              //   <a href="#"><Icon type="delete" style={{color:'#3497ce'}} /></a>
              // </Popconfirm>
            ) : null
        );
      },
    }
    
  ];  
  onDelete2=(itemId)=>{
    const _this=this;
    // const itemId=_this.state.templateId
    confirm({
      content: '确定要删除吗？',
      onOk() { 
        deletePurTemplateItemAPI(itemId).then(r=>{
          if(r.result==1){
            message.success(r.msg,1.5);
            getPurTemplateItemAPI({
              templateId:_this.state.templateId,
              pageNo:_this.state.pageNo,
              pageSize:_this.state.pageSize,
            }).then(r=>{
              if(r.result==1){
                _this.setState({
                  data:r.data,
                  totalRows:r.totalRows||10,
                  pageNo:r.pageNo,
                  pageSize:r.pageNo
                })
              }else {
                message.error(r.msg,1.5);
              }
            })
          }else {
            message.error(r.msg,1.5);
          }
        });
      },
      onCancel() {
        console.log('Cancel');
      },
    });
  }
  //列表里面的单个的删除
  onDelete = (itemId) => {
    // console.log(itemId)
    
    this.setState({
      selectedRowKeys:[]
    });

    this.props.dispatch({ type:'purchase/deleteSelectEEF', itemId: itemId})
    this.props.dispatch({ type:'purchase/addTemplateId', templateId: this.props.Item.templateId})


  }
  /*改变购买数量*/
  updateCart = (goodsId, num) => {
    //console.log(num);
    let { data, selectedRows } = this.state;
    let newData= data.map((v,i)=>{
      if(v.goodsId==goodsId){
        v.buyNum=num
      }
      return v
    })

    let newselectedRows= selectedRows.map((v,i)=>{
      if(v.goodsId==goodsId){
        v.buyNum=num
      }
      return v
    })

    this.setState({
      data:newData,
      selectedRows:newselectedRows
    })
  }

  handelchange=(pageNo,pageSize)=>{
    // console.log(pageNo);
    // templateId:this.props.Item.templateId,
      let val={
        templateId:this.props.Item.templateId,
        // pageNo:this.state.pageNo,
        pageNo:pageNo,
        pageSize:10,
      }
    this.props.dispatch({ type:'purchase/getPurTemplateItemEFF', obj:val });
  }
  

  componentWillReceiveProps(nextProps){
    // console.log(nextProps.PurTemplateItem.data)
    // console.log(nextProps.PurTemplateItem.pageNo)
    // console.log(nextProps.PurTemplateItem.templateId)
    // if(integralMall.length && this.state.default){
     
    // }
    this.setState({
      data:nextProps.PurTemplateItem.data,
      totalRows:nextProps.PurTemplateItem.totalRows,
      pageNo:nextProps.PurTemplateItem.pageNo,
      pageSize:nextProps.PurTemplateItem.pageSize||10,
    })
  }


  handlePanel=()=>{
    getPurTemplateItemAPI({
      templateId:this.props.Item.templateId,
      pageNo:this.state.pageNo,
      pageSize:this.state.pageSize,
    }).then(r=>{
      if(r.result==1){
        // console.log(r.data)
        r.data.forEach((goods)=>{      
        })
        this.setState({
          data:r.data,
          totalRows:r.totalRows||10,
          pageNo:r.pageNo||1,
          pageSize:r.pageSize||10
        })
      }else {
        message.error(r.msg,1.5);
      }
      //console.log(r)
    })
  
  }
  // handlePanel=()=>{
    // let val={
    //   templateId:this.props.Item.templateId,
    //   pageNo:this.state.pageNo,
    //   pageSize:10,
    // }
    // console.log(val)
    // this.props.dispatch({ type:'purchase/getPurTemplateItemEFF', obj:val });
  // }


  handleActiveKey=(key)=>{
    if(this.state.id==''){
      this.handlePanel()
    }

    this.setState({
      id:this.state.id=='' ? key :''
    })
  }

  onSelectChange = (selectedRowKeys, selectedRows) => {
    this.setState({ selectedRowKeys:selectedRowKeys, selectedRows:selectedRows });
  }

  showModal = () => {
    this.setState({
      visible: true,
    });
  }
  handleOk = () => {
    this.setState({  visible: false });
  }
  handleCancel = () => {
    this.setState({ visible: false });
  }

  handleMakeTem = (templateId)=>{
    const values=this.props.form.getFieldsValue(['templateName','remark']);
  

    this.props.dispatch({
      type:'purchase/savePurTemplateEFF',
      obj:{ ...values,
        templateId
      }
    })
    this.setState({  visible: false });
  }

  handleAddCarts = ()=>{
    let purTemplateItems=[];
    this.state.selectedRows.forEach(function(v, index, array) {
      if(v.goodsId!=''){
        //  goodsId,goodsNum,newGoodsPrice
        purTemplateItems.push({  goodsId:v.goodsId, newGoodsPrice:v.goodsStorePrice, goodsNum:v.buyNum,goodsSource:0 })
      }
    });
    //console.log(purTemplateItems);
    this.props.dispatch({
      type:'purchase/getAddCartBachEFF',
      arr: purTemplateItems
    })

    if(this.props.initState){
      this.setState({
        dataSource:[]
      })
    }
  }

 
  render (){
    const { Item, dispatch,PurTemplateItem } = this.props;
    const { buyerId, templateId, templateName, createTime  } =Item;
    const { id, data, totalRows, pageNo:current, pageSize, visible } =this.state;
    // console.log( totalRows)
      console.log( PurTemplateItem.data)
     console.log( data )
  
    const {  selectedRowKeys, selectedRows } = this.state;
    const rowSelection = {
      selectedRowKeys,
      onChange: this.onSelectChange,
    };

    const { getFieldDecorator } = this.props.form;

    return (
       <div className={ panel } style={{ marginBottom:'15px' }}>
         <Collapse activeKey={id} bordered={true}>
           <Panel
             //onChange={this.handlePanel}
             style={{ backgroundColor:'#fff' }}
             key={templateId}
             header={
             <Row style={{ height:'28px', lineHeight:'28px' }} type="flex" justify="space-between">
               <Col span={4}>
                 <Row type="flex" justify="space-between">
                   <div style={{ color:'#333', position:'relative' }} onClick={()=>{ this.handleActiveKey(templateId) }}>
                     {templateName}
                     <div style={{ position:'absolute',  left:'-20px', top:'0px',  }}>
                       { this.state.id=='' ? <Icon style={{ border:'1px solid #999' }} type="plus" /> : <Icon style={{ border:'1px solid #999' }} type="minus" /> }
                     </div>
                   </div>
                   <div style={{ color:'#0066cc' }} onClick={this.showModal}>修改</div>
                 </Row>
               </Col>
               <Col span={4}>{moment(createTime.time).format("YYYY-MM-DD HH:mm:ss")}</Col>
               <Col span={8}>
                 <Button type="primary" disabled={ selectedRowKeys.length > 0 ? false : true } onClick={this.handleAddCarts} style={{ marginRight:'10px' }}>加入购物车</Button>
                 <Button disabled={ selectedRowKeys.length > 0 ? false : true } style={{ marginRight:'10px' }}
                         onClick={()=>{
                          //  console.log(selectedRowKeys);
                           const _this=this;
                           confirm({
                             title: '',
                             content: '您确定要删除选中项吗?',
                             onOk() {
                              // console.log('OK');
                              // console.log(_this);
                               deletePurTemplateItemAPI(selectedRowKeys.join(',')).then(r=>{
                                 if(r.result==1){
                                   message.success(r.msg,1.5);
                                  // console.log(_this);
                                   getPurTemplateItemAPI({
                                     templateId:templateId,
                                     pageNo:_this.state.pageNo,
                                     pageSize:_this.state.pageSize,
                                   }).then(r=>{
                                     if(r.result==1){
                                       _this.setState({
                                         data:r.data,
                                         totalRows:r.totalRows||10,
                                         pageNo:r.pageNo,
                                         pageSize:r.pageNo
                                       })
                                     }else {
                                       message.error(r.msg,1.5);
                                     }
                                     //console.log(r)
                                   })
                                 }else {
                                   message.error(r.msg,1.5);
                                 }
                               });
                             },
                             onCancel() {
                               console.log('Cancel');
                             },
                           });}
                         }
                 >删除产品</Button>
                 <Button style={{ marginRight:'10px' }}
                   onClick={()=>{
                     confirm({
                       title: '',
                       content: '您确定要删除此模板吗?',
                       onOk() {
                        // console.log('OK');
                         deletePurTemplateAPI(templateId).then(r=>{
                           if(r.result==1){
                             message.success(r.msg,1.5);
                             dispatch({ type:'purchase/getPurTemplateListEFF' })
                           }else {
                             message.error(r.msg,1.5);
                             //dispatch({ type:'purchase/getPurTemplateListEFF' })
                           }
                         })
                       },
                       onCancel() {
                         //console.log('Cancel');
                       },
                     });}
                   }
                 >删除模板</Button>
               </Col>
             </Row>
           } >
             <Table
               rowSelection={rowSelection} 
               bordered
               rowKey={ (record,i) => record.itemId }
               dataSource={ data }
               columns={this.columns}
               pagination={{
                showQuickJumper:true,
                defaultCurrent:1,
                defaultPageSize:10,
                total:parseInt(totalRows),
                // current:parseInt(current),
                // pageSize:parseInt(pageSize),
                 onChange:this.handelchange
               }}
               className="table_order"/>
           </Panel>
         </Collapse>

         <Modal
           visible={visible}
           title="修改采购模板名称"
           onOk={this.handleOk}
           onCancel={this.handleCancel}
           footer={null}
         >
           <FormItem
             { ...formItemLayout }
             label="模板名称">
             {getFieldDecorator('templateName', {
               rules: [{
                 required: true,
                 message: '请输入模板名称！',
               }],
             })(
               <Input  />
             )}
           </FormItem>
           <FormItem
             { ...formItemLayout }
             label="模板说明">
             {getFieldDecorator('remark')(
               <Input  />
             )}
           </FormItem>
           <Button style={{ marginLeft:'80px' }} key="back" size="large" onClick={()=>{ this.handleMakeTem(templateId) }}>修改</Button>
         </Modal>
       </div>
    );
  }
}


export default Form.create()(PurchaseTempletPanel);

