import React, {Component} from 'react';
import PropTypes from 'prop-types';
import {connect} from 'dva';
import {  Link } from 'dva/router';
import {Button, Table, Icon, Modal, Tabs , message,Breadcrumb, Row} from 'antd';
import Search from '../../components/Search/Search';
import Navigation from '../../components/Navigation/Navigation'
import Img from '../../components/Img/Img';
import LeftNav from '../../components/LeftNav/LeftNav';
import { GoodsRecommed ,bottemDetail} from './api';
import {tableList} from "../presonAccount/point.less";
import {pointAPI} from './api'

const { Column, ColumnGroup } = Table;

const TabPane = Tabs.TabPane;

class Point extends Component {
 constructor(props) {
  super(props);
  this.state = {

  }
 }

 columns = [
  {
   title: '时间',
   dataIndex: 'createTimeStr',
   key: 'createTimeStr',
  },
   {
    title: '变化原因',
    dataIndex: 'desc',
    key: 'desc',
   },
   {
    title: '积分',
    dataIndex: 'points',
    key: 'points',
   }
 ];

 handelchange = (pageNo,pageSize) => {
  console.log(pageNo)
  let val ={
   pageNo:pageNo,
   pageSize:10
  }
  this.props.dispatch({type:'point/pointEFF',val})
 }
 render() {
  let datas= this.props.point.data
  let spc=datas && datas.data[0] ? datas : {}
  let {total,pageNo,pageSize} = this.props.point;

  return <div>
   <div><Search></Search></div>
   <div>
    <Navigation preson={true}>

     <div className={tableList}>
      <div className="my_account_dynamic_Topimg"></div>
      <Breadcrumb separator=">" className='security_nav_bar'>
       <Breadcrumb.Item href="/presonAccunt/myAccount" style={{fontSize:'12px', fontWeight:'normal' }}>我的账户</Breadcrumb.Item>
       <Breadcrumb.Item href="/presonAccount/personalInformation"  style={{fontSize:'12px', fontWeight:'normal' }}>我的信息</Breadcrumb.Item>
       <Breadcrumb.Item href="/presonAccount/point" style={{fontSize:'16px', fontWeight:'bold' }}>积分历史记录</Breadcrumb.Item>
      </Breadcrumb>
      <div className='mychanges'>我的可用积分：<span>{datas && datas.memberAvailabelPoint}</span>分</div>
      <div className="changes">积分变化明细</div>
       <Table bordered pagination={{
        total:total,
        current:pageNo,
        pageSize:pageSize,
        showQuickJumper:true,
        onChange:this.handelchange
       }} className="intelligentUp_Detail" dataSource={spc.data} rowKey={record => record.lgId} columns={this.columns}/>
     </div>
    </Navigation>
   </div>
  </div>;
 }
}
export default connect(({point})=>({point}),(dispatch,own)=>{return {dispatch,own}})(Point);
