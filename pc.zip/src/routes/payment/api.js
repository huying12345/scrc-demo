import { post, get } from '../../utils/request';
//支付宝
export function zfbPayAPI(obj){
 return get('paymentApi/alipay',obj);
}
//交通银行网关支付
export function jtyhAPI(obj){
 return get('/paymentApi/bocomm',obj)
}

//轮询支付状态
export  function getPayStatus(obj) {
return get('paymentApi/verifyPayReulst',obj)
}
