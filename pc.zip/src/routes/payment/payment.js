/**
 * Created by 10400 on 2017/8/9.
 * 支付界面页面
 */
import React, {Component} from 'react';
import PropTypes from 'prop-types';
import {connect} from 'dva';
import Search from '../../components/Search/Search';
import Navigation from '../../components/Navigation/Navigation';
import Img from '../../components/Img/Img';
import {routerRedux, Link} from 'dva/router';
import {
 Form,
 Button,
 Radio,
 message
} from 'antd';
import {payment_body, payment_more} from './payment.less'
import {IMAGE_DOMAIN} from '../../utils/common';
import {zfbPayAPI,jtyhAPI} from './api'

const RadioGroup = Radio.Group;

class Payment extends Component {
 constructor(props) {
  super(props);
  this.state = {
   selectPayType  : '',
   orderSn        : this.props.params.orderSn,
   payType        : this.props.params.payType,
   orderTotalPrice: this.props.params.orderTotalPrice,
   isControlInfo  : this.props.params.isControlInfo,
   zfbRes         : {},
   jtyhRes        : {},
  }
 }

// 支付宝支付
 zfbPay = () => {
  zfbPayAPI({
   orderSn    : this.props.params.orderSn,
   orderAmount: Number(this.props.params.orderAmount).toFixed(2)
  }).then(res => {
   console.log(res)
   if (res.result == '1') {
    this.setState({
      zfbRes : res.data[0],
      jtyhRes: {}
     },
     () => {
      document.zfbRes.submit()
     }
    )
   }else{
    message.error(res.msg)
   }
  })
 }

 //交通银行网关支付
 jtPay = () => {
  jtyhAPI({
   orderSn    : this.props.params.orderSn,
   orderAmount: Number(this.props.params.orderAmount).toFixed(2),
   bankCode   : this.state.selectPayType
  }).then(res => {
   console.log(res)
   if(res.result = "1"){
    this.setState({
      jtyhRes: res.data[0],
      zfbRes : {}
     },
     () => {
      document.yl.submit()
     }
    )
   }else{
    message.error(res.msg)
   }
  })
 }

 gopay = () => {
  let selectPayType = this.state.selectPayType
  if (selectPayType == "") {
   message.info("请选择支付方式")
   return
  }
  if (selectPayType == "zfb") {
   // 支付宝支付
   this.zfbPay()
  }else{
   //交通银行网关支付
   this.jtPay()
  }
 }

 onChange = (e) => {
  this.setState({
   selectPayType: e.target.value,
  });
 }


 render() {
  const {saveOrderDate}  = this.props.payment;
  let   {zfbRes,jtyhRes} = this.state
  const memberType       = localStorage.getItem("memberType") ;
  return <div>
   <div><Search></Search></div>
   <Navigation preson={true}>
    {
     zfbRes ?
      <form id="zfbRes" action={zfbRes.request_url} method="get" name="zfbRes">
       <input type="hidden" name="seller_email" value={zfbRes.seller_email}/>
       <input type="hidden" name="_input_charset" value={zfbRes._input_charset}/>
       <input type="hidden" name="defaultbank" value={zfbRes.defaultbank}/>
       <input type="hidden" name="notify_url" value={zfbRes.notify_url}/>
       <input type="hidden" name="payment_type" value={zfbRes.payment_type}/>
       <input type="hidden" name="out_trade_no" value={zfbRes.out_trade_no}/>
       <input type="hidden" name="paymethod" value={zfbRes.paymethod}/>
       <input type="hidden" name="subject" value={zfbRes.subject}/>
       <input type="hidden" name="partner" value={zfbRes.partner}/>
       <input type="hidden" name="service" value={zfbRes.service}/>
       <input type="hidden" name="sign" value={zfbRes.sign}/>
       <input type="hidden" name="sign_type" value={zfbRes.sign_type}/>
       <input type="hidden" name="total_fee" value={zfbRes.total_fee}/>
       <input type="hidden" name="return_url" value={zfbRes.return_url}/>
       <input type="hidden" name="exter_invoke_ip" value={zfbRes.exter_invoke_ip}/>
       <input type="hidden" name="show_url" value={zfbRes.show_url}/>
      </form> : ""}
    {
     jtyhRes ?
      <form id="yl" name="yl" method="post" action={jtyhRes.reqUrl}>
       <input type="hidden" name="interfaceVersion" value={jtyhRes.interfaceVersion}/>
       <input type="hidden" name="merID" value={jtyhRes.merID}/>
       <input type="hidden" name="orderid" value={jtyhRes.orderid}/>
       <input type="hidden" name="orderDate" value={jtyhRes.orderDate}/>
       <input type="hidden" name="orderTime" value={jtyhRes.orderTime}/>
       <input type="hidden" name="tranType" value={jtyhRes.tranType}/>
       <input type="hidden" name="amount" value={jtyhRes.amount}/>
       <input type="hidden" name="curType" value={jtyhRes.curType}/>
       <input type="hidden" name="orderContent" value={jtyhRes.orderContent}/>
       <input type="hidden" name="orderMono" value={jtyhRes.orderMono}/>
       <input type="hidden" name="phdFlag" value={jtyhRes.phdFlag}/>
       <input type="hidden" name="notifyType" value={jtyhRes.notifyType}/>
       <input type="hidden" name="merURL" value={jtyhRes.merURL}/>
       <input type="hidden" name="goodsURL" value={jtyhRes.goodsURL}/>
       <input type="hidden" name="jumpSeconds" value={jtyhRes.jumpSeconds}/>
       <input type="hidden" name="payBatchNo" value={jtyhRes.payBatchNo}/>
       <input type="hidden" name="proxyMerName" value={jtyhRes.proxyMerName}/>
       <input type="hidden" name="proxyMerType" value={jtyhRes.proxyMerType}/>
       <input type="hidden" name="proxyMerCredentials" value={jtyhRes.proxyMerCredentials}/>
       <input type="hidden" name="netType" value={jtyhRes.netType}/>
       <input type="hidden" name="merSignMsg" value={jtyhRes.merSignMsg}/>
       <input type="hidden" name="issBankNo" value={jtyhRes.issBankNo}/>
      </form>: ""
    }
    {saveOrderDate.length > 0 ? <div>
     <div className="alls_guanggao_img"><Img style={{width: '100%', height: "100%"}}
                                             src="/static/head/my_account_dynamic_Topimg.jpg"/></div>
     <div className={payment_body}>
      <div className="paymentstate">订单提交成功！</div>
      <div className="order_detail">
       <div>您的订单号：<span>{this.props.params.orderSn}</span></div>
       <div>订单总金额：<span>{Number(this.props.params.orderTotalPrice).toFixed(2)}</span>元</div>

       {memberType=='0'?
           <div>应支付金额：<span>{Number(this.props.params.orderAmount).toFixed(2)}</span>元</div>
          : null
       }
       {this.props.params.payType == 1 ? <div>支付方式：在线支付</div> : (this.props.params.payType == 2 ? <div>支付方式：银行汇款</div> :
        <div>支付方式：货到付款</div>)}
      </div>
      {saveOrderDate.length > 0 && saveOrderDate[0].isControlInfo ?
       <div style={{width: '960px'}}>
        <p style={{color: 'red', padding: '8px 0', fontSize: '14px'}}>
         订单包含管制类产品（一般危险化学品/易制爆化学品/一类易制毒化学品/二、三类易制毒化学品/剧毒化学品），要按照国家规定提供相关证件备案后方可购买。</p>
        <div className="payment_link"><a href="/customservice?parentId=6&articleId=513ace30b988496b835227c55a17a473"
                                         target="_blank">点击查看管制类产品所需相关购买材料>></a></div>
       </div>
       : ''}
      <div className={payment_more}>
       <div className="payment_look">
        <p>现在您还可以</p>
        <div className="btnlists">
         <span><Link to={`/personOrder/orderDetail/${saveOrderDate[0].orderId}`}>查看订单状态</Link></span>
         <span><Link to='/'>继续购物</Link></span>
         <span><Link target="_blank" to="/reagent-front/points/index">积分换礼</Link></span>
         <span><Link to='/presonAccount/intelligentUp'>资质上传</Link></span>
        </div>
       </div>
       {this.props.params.payType == 1 && this.props.params.orderAmount > 0 ?
        <div>
         <div className="paymentMethod">
          <p>平台支付</p>
          <div className="paylists">
           <RadioGroup onChange={this.onChange} value={this.state.selectPayType}>
            <Radio value={"zfb"}><img src={require("../../assets/pay/zfbzf.jpg")} alt=""/></Radio>
           </RadioGroup>
          </div>
         </div>
         <div className="paymentMethod">
          <p>网银支付</p>
          <div className="paylists">
           <RadioGroup onChange={this.onChange} value={this.state.selectPayType}>
            <Radio value={"BOCOM"}><img src={require("../../assets/pay/jt.jpg")} alt=""/></Radio>

            <Radio value={"Others"}><img src={require("../../assets/pay/yl.jpg")} alt=""/></Radio>
           </RadioGroup>
          </div>
          <div className="paylists">
           <RadioGroup onChange={this.onChange} value={this.state.selectPayType}>
            <Radio value={"CEB"}><img src={require('../../assets/pay/gd.jpg')}/></Radio>
            <Radio value={"GDB"}><img src={require("../../assets/pay/gf.jpg")}/></Radio>
            <Radio value={"ICBC"}><img src={require("../../assets/pay/gh.jpg")}/></Radio>
            <Radio value={"HXB"}><img src={require("../../assets/pay/hx.jpg")}/></Radio>
            <Radio value={"CCB"}><img src={require("../../assets/pay/js.jpg")}/></Radio>
            <Radio value={"CMBC"}><img src={require("../../assets/pay/ms.jpg")}/></Radio>
            <Radio value={"ABC"}><img src={require("../../assets/pay/nh.jpg")}/></Radio>
            <Radio value={"SPDB"}><img src={require("../../assets/pay/pf.jpg")}/></Radio>
            <Radio value={"UPOP"}><img src={require("../../assets/pay/rzzf.jpg")}/></Radio>
            <Radio value={"CIB"}><img src={require("../../assets/pay/xy.jpg")}/></Radio>
            <Radio value={"PSBC"}><img src={require("../../assets/pay/yzcx.jpg")}/></Radio>
            <Radio value={"BOCSH"}><img src={require("../../assets/pay/zh.jpg")}/></Radio>
            <Radio value={"CMB"}><img src={require("../../assets/pay/zs.jpg")}/></Radio>
            <Radio value={"CNCB"}><img src={require("../../assets/pay/zx.jpg")}/></Radio>
            <Radio value={"BOC"}><img src={require("../../assets/pay/zyde.jpg")}/></Radio>
           </RadioGroup>
          </div>
          <div style={{padding: '30px 0', display: 'flex', justifyContent: 'space-around'}}>
           <Button type="primary" style={{
            backgroundColor: '#ff0000',
            borderColor    : '#ff0000',
            width          : '120px',
            height         : '40px',    fontSize: '18px'
           }} onClick={() => this.gopay()}>立即支付</Button>
          </div>
         </div>
        </div>
        :     " "
       }
      </div>
     </div>
    </div> : <p style={{margin: '20px auto', textAlign: 'center'}}>请到订单列表查看订单相关信息</p>}

   </Navigation>
  </div>
  // (
  {/*<div className={payment_body}>*/
  }
  {/*<div className="payment_box">*/
  }
  {/*<div className="payment_head">*/
  }
  {/*<div className="payment_head_l">*/
  }
  {/*<Link className="logo"  to="/home"></Link>*/
  }
  {/*</div>*/
  }
  {/*<div className="payment_head_r">*/
  }
  {/*<Steps current={current}>*/
  }
  {/*<Step description={<span>确认购物清单</span>} />*/
  }
  {/*<Step description={<span>填写核对购物信息</span>} />*/
  }
  {/*<Step description={<span>选择支付方式</span>}/>*/
  }
  {/*<Step description={<span>购买完成</span>} />*/
  }
  {/*</Steps>*/
  }
  {/*</div>*/
  }
  {/*</div>*/
  }
  {/*<div className="payment_content">*/
  }
  {/*<div className="payment_content_orderdetall">*/
  }
  {/*<div className="orderdetall_title">*/
  }
  {/*<span>订单编号:{paySn},支付编号:{payId}</span>*/
  }
  {/*<a href="#">订单详情</a>*/
  }
  {/*<span style={{color:'#fd0303',float:'right'}}><b style={{fontSize:'14px',fontWeight:'400'}}>￥</b>{orderTotalPrice}</span>*/
  }
  {/*</div>*/
  }
  {/*</div>*/
  }
  {/*支付链接*/
  }
  {/*/!*<PaymentMethod></PaymentMethod>*!/*/
  }
  {/*<div className="payment_content_paymentMethod">*/
  }
  {/*<p>在线支付</p>*/
  }
  {/*<RadioGroup onChange={this.onChange} value={value}>*/
  }
  {/*<Radio value={1}><img src="http://bbcimage.leimingtech.com/upload/img/paymentlogo/1489494994460.png" style={{width:'150px',height:'50px'}}/></Radio>*/
  }
  {/*<Radio value={2}><img src="http://bbcimage.leimingtech.com/upload/img/paymentlogo/1489495005682.jpg" style={{width:'150px',height:'50px'}}/></Radio>*/
  }
  {/*<Radio value={3}><img src="http://bbcimage.leimingtech.com/upload/img/paymentlogo/1489495015503.png" style={{width:'150px',height:'50px'}}/></Radio>*/
  }
  {/*</RadioGroup>*/
  }

  {/*</div>*/
  }
  {/*</div>*/
  }

  {/*</div>*/
  }
  // </div>
  // );
 }
}

Payment.propTypes = {
 form    : PropTypes.object,
 Payment : PropTypes.object,
 dispatch: PropTypes.func,
}
export default connect(({payment, personOrder}) => ({payment, personOrder}), (dispatch, own) => {
 return {dispatch, own}
})(Form.create()(Payment));
