/**
 * Created by 10400 on 2017/8/9.
 * 支付界面页面
 */
import React, {Component} from 'react';
import PropTypes from 'prop-types';
import {connect} from 'dva';
import {routerRedux, Link} from 'dva/router';
import Search from '../../components/Search/Search';
import Navigation from '../../components/Navigation/Navigation';
import {Col, Icon, Row,message} from 'antd';
import {paymentSuccess_body} from './paymentSuccess.less'
import {getPayStatus} from './api';

let num = 0;
let timer = null;
class PaymentSuccess extends Component {
 constructor(props) {
  super(props);
  this.state = {
   value: '',
   current: 1,
   status:2,
   total_fee:0,
   orderSn:""
  }
 }

 componentWillUnmount() {

 }

 componentDidMount() {
  message.loading('',0);
  let orderSn = this.props.params.orderSn;
  let paySn = this.props.params.paySn;
  let total_fee = this.props.params.totalFee;
  this.setState({
   total_fee,orderSn
  })
  let _this = this;
  this.getStatus(orderSn,paySn);
  timer =  setInterval(function () {
   if (num >= 15 || _this.state.status != 2){
    _this.setState({
     status:0
    })
    message.error("失败了");
    message.destroy();
    clearInterval(timer);
    return
   }
   _this.getStatus(orderSn,paySn)
  },2000)
 }

 getStatus = (orderSn,paySn) => {
  num++
  getPayStatus({orderSn, paySn}).then(res => {
   if (res.result == 1) {
    message.success("支付成功")
    message.destroy();
    this.setState({
     status:1
    })
    clearInterval(timer);
   } else if(res.result == 2) {
    this.setState({
     status:2
    })
   }else{
    message.error(res.msg);
    message.destroy();
    this.setState({
     status:0
    })
    clearInterval(timer);
   }
  })
 }

 onChange = (e) => {
  // console.log('radio checked', e.target.value);
  this.setState({
   value: e.target.value,
   current: 2
  });
 }

 render() {
  console.log(this.state)
  return (
   <div>
    <div><Search></Search></div>
    <Navigation preson={true}>
     <div className={paymentSuccess_body}>
      {this.state.status == 2 ?
       <div className="payment_s">正在支付  请稍后......</div>
       :
       this.state.status == 0 ?
       <div className="payment_s">支付失败</div>
       :
        <div className="payment_s paymentSuccess">
         <div style={{fontSize: '26px', color: '#725AF1', letterSpacing: '3px'}}>订单提交成功</div>
         <div style={{color: '#ddd'}}>我们会尽快为您发货</div>
        </div>
       }

      <Row style={{margin: '50px', textAlign: 'center'}}>
       <Col span={7}>您的订单号：<span style={{color: 'red'}}>{this.state.orderSn}</span></Col>
       <Col span={7}>订单金额：<span style={{color: 'red'}}>{this.state.total_fee}</span>元</Col>
       <Col span={7}>支付方式:在线支付</Col>
      </Row>
     </div>
    </Navigation>
   </div>
  );
 }
}


export default connect(({payment}) => ({payment}), (dispatch, own) => {
 return {dispatch, own}
})(PaymentSuccess);
