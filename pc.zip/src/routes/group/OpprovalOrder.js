import React, { Component } from 'react'
import { BodyHeadImg } from '../../components/Advertising/Advertising'
import { Breadcrumb, Checkbox,Table, Row, Col, Pagination, Input, Button, Form, Modal, Select, Switch, DatePicker ,message} from 'antd'
import { routerRedux,Link } from 'dva/router'
import { connect } from 'dva'
import { opprovalOrder ,my_account_dynamic_Topimg} from './OpprovalOrder.less'
import Img from "../../components/Img/Img"
import Search from '../../components/Search/Search'
import Navigation from '../../components/Navigation/Navigation'
import {exportOrderListAPI,exportOrderDetailAPI} from './api'
import {IMAGE_DOMAIN} from "../../utils/common"
import moment  from 'moment'
const FormItem = Form.Item;
const Option   = Select.Option;

const formItemLayout = {
  labelCol: { span: 8 }
};

class OpprovalOrder extends Component {
  state = {
    startValue : null,
    endValue   : null,
    selectTime : '0',
    startTime  : '',
    endTime    : '',
    selectState: '9',
    filterMin  : '',
    filterMax  : '',
    orderFilter: '',
    endOpen    : false,
    data       : [],
    value      : 0,
    checkAll   : false,
    loading    : true,
  }

  //表单提交
  handleSubmit = (e) => {
    e.preventDefault();
        let val={
          timeState     : this.state.selectTime,    // 筛选时间类型
          startTime     : this.state.startTime,     //  起始时间
          endTime       : this.state.endTime,       // 截止时间
          orderStatus   : this.state.selectState,   //订单状态
          mixOrderAmount: this.state.filterMin,     // 订单金额
          maxOrderAmount: this.state.filterMax,     // 订单金额
          filter        : this.state.orderFilter,   // 筛选条件
        }
        console.log(val)
        this.props.dispatch({type: 'opprovalOrder/groupOrderCheckListEFF',val })

  }
  //审批状态改变
  handleChangeState = (value) => {
    this.setState({selectState: value})
  }
  //时间状态改变（审批/下单）
  handleChangeTime = (value) => {
    this.setState({selectTime: value})
  }
  //时间选择
  disabledStartDate = (startValue) => {
    const endValue = this.state.endValue;
    if (!startValue || !endValue) {
      return false;
    }
    return startValue.valueOf() > endValue.valueOf();
  }
  disabledEndDate = (endValue) => {
    const startValue = this.state.startValue;
    if (!endValue || !startValue) {
      return false;
    }
    return endValue.valueOf() <= startValue.valueOf();
  }
  onStartOk = () => {
    if(this.state.startValue == null){
     let formatTime  = moment(Date.now()).format('YYYY-MM-DD');
     let formatValue = moment(Date.now());                       //参数换成毫秒
     if(this.state.endValue == null || formatValue <= this.state.endValue){
        this.setState({ startTime : formatTime, startValue : formatValue });
        //设置DatePicker的value
        this.props.form.setFieldsValue({
           startTime : formatTime,
           startValue: formatValue
        })
     }
    }
  }
  onEndOk = () => {
    if(this.state.endValue == null){
     let formatTime  = moment(Date.now()).format('YYYY-MM-DD');
     let formatValue = moment(Date.now());                       //参数换成毫秒
     if(this.state.startValue == null || formatValue >= this.state.startValue){
      this.setState({ endTime:formatTime, endValue:formatValue });
      //设置DatePicker的value
      this.props.form.setFieldsValue({
         endTime : formatTime,
         endValue: formatValue
      })
     }
    }
   }
   onStartChange = (value, dateString) => {
    this.setState({startTime:dateString,startValue:value })
   }
   onEndChange = (value, dateString) => {
    this.setState({endTime:dateString,endValue:value })
   }
   handleStartOpenChange = (open) => {
     if (!open) {
       this.setState({ endOpen: true });
     }
   }
   handleEndOpenChange = (open) => {
     this.setState({ endOpen: open });
   }
//分页
onChangePage = (pageNo) => {
   let val = {
    timeState     : this.state.selectTime,    // 筛选时间类型
    startTime     : this.state.startTime,     //  起始时间
    endTime       : this.state.endTime,       // 截止时间
    orderStatus   : this.state.selectState,   //审批状态
    mixOrderAmount: this.state.filterMin,     // 订单金额
    maxOrderAmount: this.state.filterMax,     // 订单金额
    filter        : this.state.orderFilter,   // 筛选条件
    pageNo        : pageNo,
   }
  this.props.dispatch({type: 'opprovalOrder/groupOrderCheckListEFF', val });

  window.scrollTo(0, 0)
}
goPage = () => {
  let maxPage = Math.ceil(this.props.opprovalOrder.count / 10);
  let pageNo  = this.refs.page.getElementsByTagName("input")[0].value;
      pageNo  = pageNo > maxPage ? maxPage : pageNo
  if (!!pageNo) {
    let val = {
      timeState     : this.state.selectTime,    // 筛选时间类型
      startTime     : this.state.startTime,     //  起始时间
      endTime       : this.state.endTime,       // 截止时间
      orderStatus   : this.state.selectState,   //审批状态
      mixOrderAmount: this.state.filterMin,     // 订单金额
      maxOrderAmount: this.state.filterMax,     // 订单金额
      filter        : this.state.orderFilter,   // 筛选条件
      pageNo        : pageNo,
    }
    this.props.dispatch({ type: 'opprovalOrder/groupOrderCheckListEFF', val });

   window.scrollTo(0, 0)
   this.refs.page.getElementsByTagName("input")[0].value = ""
  }
 }
 //
 //导出订单列表
 exportOrderList = () => {
  let orderIds = this.props.opprovalOrder.orderIds?this.props.opprovalOrder.orderIds:''
  exportOrderListAPI({
     orderIds: orderIds,
   }).then(r=>{
     if(r.result==1){
       console.log(r.filePath)
       let url                  = `${IMAGE_DOMAIN}${r.filePath}`;
           window.location.href = url
     }else {
       message.error(r.msg,1.5);
     }

   })
 }
 //导出订单明细
 exportOrder = () => {
  let orderIds = this.props.opprovalOrder.orderIds?this.props.opprovalOrder.orderIds:''
   exportOrderDetailAPI({
       orderIds: orderIds,
    }).then(r=>{
       if(r.result==1){
         console.log(r.filePath)
         let url                  = `${IMAGE_DOMAIN}${r.filePath}`;
             window.location.href = url
       }else {
         message.error(r.msg,1.5);
       }

    })
 }


  render() {
    const { getFieldDecorator }                            = this.props.form
    const { startValue, endValue, endOpen }                = this.state;
    const { groupOrderCheckListData,checkAll,count,pageNo} = this.props.opprovalOrder
    console.log(groupOrderCheckListData)
    const formItemLayout = {
      labelCol  : { span: 2 },
      wrapperCol: { span: 2 },
     };
    return (
      <div>
        <Search></Search>
        <Navigation preson={true}>
          <div className={opprovalOrder}>
            <div className={my_account_dynamic_Topimg}></div>
            {/* <BodyHeadImg headImg={{url:'/upload/img/lmadv/1508217294561.png',id:'234'}}/> */}
            <Breadcrumb separator=">" className='security_nav_bar'>
              <Breadcrumb.Item href="">我的账户</Breadcrumb.Item>
              <Breadcrumb.Item href="/group/mianManage">我的群组</Breadcrumb.Item>
              <Breadcrumb.Item href="/group/opproval-order" style={{fontSize:'16px', fontWeight:'bold' }}>群组订单管理</Breadcrumb.Item>
            </Breadcrumb>
            <div className="filter_bar">
              <div className="clear">
                <div>
                <Form onSubmit={this.handleSubmit} layout="inline">
                  <Row>
                    <Col span={2} style={{ marginRight: '10px'}}>
                      {getFieldDecorator('selectTime',{initialValue:'0'})(
                        <Select onChange={this.handleChangeTime}>
                          <Option value="0">下单时间</Option>
                          <Option value="1">审批时间</Option>
                        </Select>
                      )}
                    </Col>
                    <Col span={4}>
                      <FormItem
                        {...formItemLayout}>
                        {getFieldDecorator('startValue',{setFieldsValue:startValue})(
                          <DatePicker
                            disabledDate = {this.disabledStartDate}
                            showTime
                            format       = "YYYY-MM-DD"
                            placeholder  = "开始日期"
                            onOk         = {this.onStartOk}
                            onChange     = {this.onStartChange}
                            onOpenChange = {this.handleStartOpenChange}
                          />
                        )}
                      </FormItem>
                    </Col>
                    <Col span={1} style={{width:'10px',paddingTop:'8px',margin: '0 5px'}}>-</Col>
                    <Col span={4}>
                      <FormItem>
                        {getFieldDecorator('endValue',{setFieldsValue:endValue})(
                          <DatePicker
                            disabledDate = {this.disabledEndDate}
                            showTime
                            format       = "YYYY-MM-DD"
                            placeholder  = "结束日期"
                            onOk         = {this.onEndOk}
                            onChange     = {this.onEndChange}
                            open         = {endOpen}
                            onOpenChange = {this.handleEndOpenChange}
                          />
                        )}
                      </FormItem>
                    </Col>
                    <Col span={5} style={{marginLeft:'30px'}}>
                      <FormItem label="订单状态">
                        {getFieldDecorator('selectState',{initialValue:'9'})(
                          <Select onChange={this.handleChangeState} style={{ width:120}}>
                            <Option value="9">全部</Option>
                            <Option value="1">订单已提交</Option>
                            <Option value="2">订单已审核</Option>
                            <Option value="3">订单已确认</Option>
                            <Option value="4">正在备货</Option>
                            <Option value="5">货已发出</Option>
                            <Option value="6">谢谢您的订购</Option>
                            <Option value="7">订单已取消</Option>
                            <Option value="8">订单已关闭</Option>
                            {/* <Option value="10">已完成</Option> */}

                          </Select>
                        )}
                      </FormItem>
                    </Col>
                    <div className="r">
                      <span onClick={()=>this.exportOrderList()} className="btn" style={{ background: '#3a98cc',cursor:'pointer'}}>导出订单列表</span>
                    </div>
                  </Row>
                  <Row style={{marginTop: '10px'}}>
                    <Col span={5} style={{width:'18.4%',display:'inline'}} >
                      <FormItem label="订单金额：">
                        {getFieldDecorator('filterMin')(
                            <Input style={{width: '100px'}}  onChange={(e)=>this.setState({filterMin:e.target.value})} />
                        )}
                      </FormItem>
                    </Col>
                    <Col span={1} style={{marginTop:'5px',width:'2%'}} >-</Col>
                    <Col span={4}>
                      <FormItem>
                        {getFieldDecorator('filterMax')(
                          <Input style={{width: '100px'}}  onChange={(e)=>this.setState({filterMax:e.target.value})} />
                        )}
                      </FormItem>
                    </Col>
                    <Col span={5} style={{marginLeft:'-8px'}}>
                      <FormItem>
                        {getFieldDecorator('orderNumber')(
                          <Input style={{width: '170px'}} placeholder="订单号/发起人/审批流名称" onChange={(e)=>this.setState({orderFilter:e.target.value})} />
                        )}
                      </FormItem>
                    </Col>
                    <Col span={2}>
                      <FormItem {...formItemLayout}>
                        <Button type="primary" htmlType="submit" ghost>搜索</Button>
                      </FormItem>
                    </Col>
                    <div className="r">
                      <span onClick={()=>this.exportOrder()} className="btn" style={{ background: '#3a98cc',cursor:'pointer'}}>导出订单明细</span>
                    </div>
                  </Row>
                </Form>
                </div>
              </div>
            </div>
            <div className="orderList_content">
              <table className="table">
                <tbody>
                  <tr>
                    <th >订单号</th>
                    <th>下单时间</th>
                    <th>发起人</th>
                    <th>订单金额</th>
                    <th>订单状态</th>
                    <th>审批流名称</th>
                    <th>审批人</th>
                    <th>操作</th>
                  </tr>
									{
									  	groupOrderCheckListData && groupOrderCheckListData.length>0?
									   groupOrderCheckListData.map((val,index)=>{
											  return(
                        <tr key={index}>
                          <td>
                           {
                            val.dangerousRemarkList.map((item,i)=>{
                             return <Img key={i} style={{width: '23px', marginRight: '10px',verticalAlign:'middle'}} src={item}/>
                            })
                           }
                           {val.orderSn}</td>
                          <td>{val.createTimeStr}</td>
                          <td>{val.buyerName}</td>
                          <td>{val.orderAmount}</td>
                          <td>{val.orderStateStr}</td>
                          <td>{val.approvalName}</td>
                          <td>{val.checkBy}</td>
                          <td>
                             <Link title="点击查看" to={`/personOrder/orderDetail/${val.orderId}`} style={{ color: '#3599BB',cursor: 'pointer' }}>查看详情</Link>
                          </td>
                        </tr>
												  )
										})
										:             <tr><td></td></tr>
									}
                </tbody>
              </table>
            </div>
            <div className="cantent_paging" style={{width: '94%'}}   ref="page" key={pageNo}>
                <Pagination
                showQuickJumper
                defaultCurrent  = {1}
                defaultPageSize = {10}
                current         = {pageNo}
                total           = {groupOrderCheckListData&&groupOrderCheckListData.length>0? count: 1}
                onChange        = {this.onChangePage} />
                <Button onClick={this.goPage} style={{position:'absolute',right:'0'}}>确定</Button>
           </div>





          </div>
        </Navigation>
      </div>
    )
  }
}

export default connect(({ opprovalOrder }) => ({ opprovalOrder }), (dispatch,own) => { return { dispatch,own} })(Form.create()(OpprovalOrder))
