import React, { Component } from 'react';
import { connect } from 'dva';
import { routerRedux,Link} from 'dva/router';
import { Row,Col,Menu, Dropdown,Icon,Breadcrumb,Input,Button,Checkbox,Modal} from 'antd';
import Price from '../../components/Price/price';
import LoginBtnPrice from '../../components/Price/priceTwo'
import Img from '../../components/Img/Img';


class ManageFavOperaFloor extends Component {
  constructor(props) {
   super(props)
  }
 // 删除商品
 delGoods = (goodsId) => {
  Modal.confirm({
   title     : '提示',
   content   : '确定删除吗',
   okText    : '确定',
   cancelText: '取消',
   onOk      : () => {
    this.props.delGoods(goodsId);
   },
   maskClosable: true
  });
 }
 // 选中商品
 checkGoods = (goods, e) => {
  this.props.checkGoods(goods, e.target.checked);
 }
 addCart = (goodsId,goodsPrice,goodsMaterial) => {
  this.props.addCart(goodsId,goodsPrice,goodsMaterial);
 }


  render() {
    const data                = this.props.data;
    const memberType          = localStorage.getItem("memberType") ;
    let   storeNameList       = [];                                   //库列表
    let   storeNameListString = '';                                   //库存字符串
     if(data.stroreList&&data.stroreList.length&&data.stroreList.length>0){
      data.stroreList.map((item,val)=>{
         let storeName = (item.storeName)+':'+(item.storeStorage)
         storeNameList.push(storeName)
       })
       if(storeNameList.length&&storeNameList.length>0){
            storeNameListString = storeNameList.join(',');
       }
     }

    return (
      <div>
              <table className="border_bottom">
                <tbody>
                  <tr>
                    <td style={{width: '4%'}}>
                      <Checkbox
                        className = { (data.goodsStorePrice<=0||data.goodsStorePrice=='') ? 'yincang' :'' }
                        onChange  = {e => this.checkGoods(data,e)} checked = {data.checked }>
                      </Checkbox>
                    </td>
                    <td style={{width:'36%'}} >
                      <div className="goods_div1">
                        <Img style={{width:'105px',height:'105px',margin:'2px 16px'}} src={data.goodsImage} />
                        <div style={{margin:'18px 15px',textAlign:'left',position:'relative'}}>
                          <p style={{fontSize:'16px',color:'#333',lineHeight:'22px',marginBottom:'16px',position:'absolute',top:'-25px',width:'700px',whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis',height:'22px'}}>
                             <Link  style={{fontSize:'16px',color:'#333',lineHeight:'22px'}} to={`/goodsDetail/${data.goodsId}`}> {data.goodsName}</Link>
                             {data.goodsMaterial&&data.goodsMaterial!='' ?  <span>（{data.goodsMaterial}）</span>:null}
                          </p>
                          {(data.brandName && data.goodsSerial) ?
                            <p>                品牌/原厂货号：{data.brandName}/{data.goodsSerial}</p>: 
                            (data.brandName)   ? <p>品牌：{data.brandName}</p>                   : 
                            (data.goodsSerial) ? <p>原厂货号：{data.goodsSerial}</p>               : null
                           }
                          {(data.goodsErpCode) ? <p>国药编码：{data.goodsErpCode}</p> : null}
                          {(data.specName) ? <p>规格：{data.specName}</p> : null}
                          {(data.goodsSpec) ? <p>包装：{data.goodsSpec}</p> : null}
                        </div>
                      </div>
                    </td>
                    <td style={{width:'32%',verticalAlign:'top'}} >
                      {data.isReagent=='1'?
                          <div style={{padding: '20px 10px 0px',textAlign:'left'}}>
                            {(data.casNo) ? <p>CAS号：{data.casNo}</p> : null}

                            {(data.dangerousNature) ? <p>危险性质:<span dangerouslySetInnerHTML={{ __html: data.dangerousNature }}></span></p> : null}
                            {(data.controlInfo) ? <p>管制信息： <span style={{color: 'red'}} dangerouslySetInnerHTML={{ __html: data.controlInfo }}></span></p> : null}
                          </div>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          : 
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          data.isReagent == '0' && data.goodsDescription ? <p className='describe' style={{paddingTop:'17px',paddingLeft:'6px'}}><span dangerouslySetInnerHTML={{ __html: data.goodsDescription.length > 100 ? data.goodsDescription.substr(0,100) + "...": data.goodsDescription }}></span></p>: null
                      }
                    </td>
                    <td style={{width:'15%',verticalAlign:'top',paddingTop:'27px'}}>
                        <LoginBtnPrice   pj={data.goodsCostPrice} bz={data.SCurrency} bj={data.SCurrencyPrice} scj={false}/>
                        <LoginBtnPrice   pj={data.goodsStorePrice} bz={data.SCurrency} bj={data.SCurrencyPrice} scj={true}/>
                      {/* <p>成交价：<Price  pj={data.goodsStorePrice} bz={data.SCurrency} bj={data.SCurrencyPrice} scj={false}/></p> */}
                      {/* <p>市场价：<Price  pj={data.goodsStorePrice} bz={data.SCurrency} bj={data.SCurrencyPrice} scj={true}/></p> */}
                      {
                           Number(data.goodsStorePrice)>0?
                              memberType =='0'&&storeNameList&&storeNameList.length&&storeNameList.length>0?
                                 <p style={{marginLeft:'24px',textAlign:'left'}}>
                                  库<i style={{display:'inline-block',color:'#fff'}}>存</i>
                                  存：<span  style={{color:'#108ee9', fontWeight:'bold'}}>
                                    {data.goodsShowStorage}  （{storeNameListString}）</span>
                                    </p>
                              :           <p style={{marginLeft:'28px',textAlign:'left',}}>
                                 库<i style={{display:'inline-block',color:'#fff'}}>存</i>
                                 存：<span  style={{color:'#108ee9', fontWeight:'bold'}} >{data.goodsShowStorage}</span></p>

                              :                        null
                         }
                      {/* <p style={{textAlign:'left',paddingLeft:'30px'}}>库存：<span  style={{color:'#108ee9', fontWeight:'bold'}} >{data.goodsShowStorage}</span></p> */}
                    </td>
                    <td style={{width:'13%'}} >
                      <div>
                      <a className="icon-view-detail" title="查看详情" to={`/goodsDetail/${data.goodsId}`}  target="_blank"></a>
                      {/* {(data.goodsStorePrice>0||!!(data.goodsStorePrice)) && data.isControlInfo == 1 ?
                         <Link className="icon-cart" title="加入购物车" onClick={()=>this.addCart(data.goodsId,data.goodsStorePrice,data.goodsMaterial)} ><Icon type="shopping-cart" /></Link>: null
                      } */}
                      {(data.goodsStorePrice>0||!!(data.goodsStorePrice)) && data.isControlInfo == 1 ?
                         memberType =='0'?//网销客户部显示，其他客户显示
                         <Link className="icon-cart" title="加入购物车"
                         onClick={()=>this.addCart(data.goodsId,data.goodsStorePrice)} >
                         <Icon type="shopping-cart" /></Link>
                         : 
                          <Link className="icon-cart" title="加入购物车"
                         onClick={()=>this.addCart(data.goodsId,data.goodsCostPrice)} >
                         <Icon type="shopping-cart" /></Link>
                         :                    null
                      }
                      {<Icon type="delete" className="icon-delete" title="删除" onClick={()=>this.delGoods(data.goodsId)}/>}
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
      </div>
    )
  }
}
export default ManageFavOperaFloor;
