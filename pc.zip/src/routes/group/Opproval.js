import React, { Component } from 'react'
import { BodyHeadImg } from '../../components/Advertising/Advertising'
import { Breadcrumb, Checkbox, Row, Col, Pagination, Input, Button, Form, Modal, Select, Switch ,message} from 'antd'
import { Link } from 'dva/router'
import { connect } from 'dva'
import { opproval, my_account_dynamic_Topimg} from './Opproval.less'
import Img from "../../components/Img/Img"
import Search from '../../components/Search/Search'
import Navigation from '../../components/Navigation/Navigation'

const FormItem        = Form.Item;
const Option          = Select.Option;
const formItemLayout2 = {
 labelCol  : {sm: {span: 12},},
 wrapperCol: {sm: {span:12},},
}
const formItemLayout3 = {
 labelCol  : { sm: {span: 1},},
 wrapperCol: { sm: {span: 20}, },
}
class Opproval extends Component {
  state = {
    value       : 0,
    checkAll    : false,
    visible     : false,
    visible1    : false,
    visible2    : false,   //直接展示
    lookVal     : {},
    opprovalName: '',
    amountMoney : '',
    approvalId  : '',

    CheckedMoneyArr: [{checkedMoney:false,}],
    changeRiquire  : false,
    isChoiceBtn    : true,                      //控制金额
    isRepeat       : false,
    load           : false,

  }
    searchName = (e) => {
         e.preventDefault();
         this.props.form.validateFields(['searchName'],(err, values) => {
           if (!err) {
              if(values.searchName==''||values.searchName==undefined){
              // message.error('请输入搜索内容',1.5);
              this.props.dispatch({type:'opproval/groupApprovalsListEFF',})
        }else{
           let val = {approvalName:values.searchName,	}
           // console.log(val)
           this.props.dispatch({type:'opproval/groupApprovalsListEFF',val})
        }
        }
      });
    }
 		 //弃用
    disuseState=(id)=>{
     let val = {	isUse:'0',approvalId:id }
     this.props.dispatch({type:'opproval/defaultApprovalEFF',val})
     this.setState({
      load: !this.state.load
     })
   }
    //启用
    // 传参：approvalId  审批流ID
// isUse   1启用，0禁用
   enAble=(id)=>{
     let val = {	isUse:'1',approvalId:id }
     this.props.dispatch({type:'opproval/defaultApprovalEFF',val})
     this.setState({
      load: !this.state.load
     })
   }
    		 //删除审批流
   deleteList=(id)=>{
        let val = {	approvalId:id }
        this.props.dispatch({type:'opproval/deleteGroupApprovalsEFF',val})
        this.setState({load: !this.state.load })
  }
	//分页
   onChangePage = (pageNo) => {
    // console.log(pageNo)
    this.props.dispatch({type: 'opproval/groupApprovalsListEFF', val: {pageNo: pageNo}});
    this.setState({
     update: true,
    })
    window.scrollTo(0, 0)
   }
  goPage = () => {
    let maxPage = Math.ceil(this.props.opproval.count / 10)
    let pageNo  = this.refs.page.getElementsByTagName("input")[0].value;
        pageNo  = pageNo > maxPage ? maxPage : pageNo
    if (!!pageNo) {
     this.setState({
     update: true
     }, () => this.props.dispatch({
     type: 'opproval/groupApprovalsListEFF',
     val : {pageNo: pageNo,}
     }))
     window.scrollTo(0, 0)
     this.refs.page.getElementsByTagName("input")[0].value = ""
    }
  }
    showModal1 = () => {
     this.setState({visible1: true});
    }
    showModal2 = (val) => {
     let info = val || {};
     console.log(info)
     this.setState({
      visible2: true,
      lookVal : info,
     });
    }
   //金额按钮
   switchChange = () => {
    this.setState({ isChoiceBtn: !this.state.isChoiceBtn})
   }

   //查看审批流取消
   opprovalCancel = (e) => {
    this.setState({visible2: false});
   }
   //新建审批流取消
 ProjectHandleCancel = (e) => {
  this.setState({visible1: false});
 }
   //新建审批流提交
   opprovalHandleOk = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
     // console.log(values)
     if (!err) {
      let arr = [];
      for (let i = 0; i < this.state.CheckedMoneyArr.length; i++) {
          let opprovalName      = 'opprovalName' + `${i}`       //审批人1序号
          let opprovalNameValue = values[opprovalName]+',';
          let opprovalNameArr   = opprovalNameValue.split(',')  //字符串转成数组
          let firstUserId       = opprovalNameArr[0]            //第一审批人id
          let firstUserName     = opprovalNameArr[1]            //审批人1名称

          let opprovalNameTwo      = 'opprovalNameTwo' + `${i}`       //审批人2序号
          let opprovalNameTwoValue = values[opprovalNameTwo]+',';
          let opprovalNameTwoArr   = opprovalNameTwoValue.split(',')  //字符串转成数组
          let secondUserId         = opprovalNameTwoArr[0]            // 第2审批人id
          let secondUserName       = opprovalNameTwoArr[1]            //审批人2名称

          let opprovalMoneyName      = 'opprovalMoney' + `${i}`    //审批金额
          let opprovalMoneyNameValue = values[opprovalMoneyName];

          let val               = {
           "firstUserId"   : firstUserId,                                                      // 第一审批人id
           "firstUserName" : firstUserName,                                                    //审批人1名称
           "secondUserId"  : secondUserId!='undefined'?secondUserId                    : '',   //审批人2id
           "secondUserName": secondUserName!='undefined'?secondUserName                : '',   //审批人2名称
           "funds"         : opprovalMoneyNameValue!='undefined'?opprovalMoneyNameValue: '',   //金额
          }
          arr.push(val);
      }
      // console.log(arr)

         // arr.map((list1,ind1)=>{
         //      if(list1.firstUserId==list1.secondUserId){
         //          isRepeatMember = true
         //          console.log('1和2进行比较true'+isRepeatMember)
         //      }else if(arr.length>1){
         //         arr.map((list2,ind2)=>{
         //          console.log(list2)
         //            if(list1.firstUserId==list2.firstUserId||list1.firstUserId==list2.secondUserId||
         //               list1.secondUserId==list2.firstUserId||list1.secondUserId==list2.secondUserId)
         //              {
         //               isRepeatMember = true
         //               console.log('1和所有进行比较true'+isRepeatMember)
         //              }else{
         //               isRepeatMember = false
         //               console.log('1和所有进行比较的false'+isRepeatMember)
         //              }
         //         })
         //      }else{
         //         isRepeatMember = false
         //         console.log('1和2进行比较false'+isRepeatMember)
         //      }
         // })
           let isRepeatMember = false
           console.log('最外面'+isRepeatMember)
           console.log(arr)
         　for(var i=0;i<arr.length;i++){
               if(arr[i].firstUserId==arr[i].secondUserId){
                         isRepeatMember = true
               }else if(arr.length>1){
                       for(var j=i+1;j<arr.length;j++){
                         if(arr[i].secondUserId !=''){
                                if(arr[i].firstUserId == arr[j].firstUserId||
                                    arr[i].firstUserId == arr[j].secondUserId||
                                    arr[i].secondUserId == arr[j].firstUserId||
                                    arr[i].secondUserId == arr[j].secondUserId
                                   ){
                                      isRepeatMember = true
                                 }else{
                                     isRepeatMember = false
                                 }
                         }else{
                                if(arr[i].firstUserId == arr[j].firstUserId||arr[i].firstUserId == arr[j].secondUserId)
                                {
                                   isRepeatMember = true
                                }else{
                                    isRepeatMember = false
                                }
                         }
                       }
               }else{
                   isRepeatMember = false
                   console.log('1和2进行比较false'+isRepeatMember)
               }

          　　
           }
        if(isRepeatMember==false){
            let approvalFlowListArr = JSON.stringify(arr)
            let objOppoval          = {
             approvalFlowList: approvalFlowListArr,
             approvalName    : values.opprovalProcess,             //审批流名称
             approvalId      : this.state.approvalId,
             isAmount        : this.state.isChoiceBtn==true? 1: 0  //金额是否启用
            }
            this.props.dispatch({type: 'opproval/groupApprovalsEFF',objOppoval:objOppoval });
            this.setState({visible1: false,});
            this.props.form.resetFields()
        }else if(isRepeatMember==true){
            message.error('审批人重复',1.5,()=>{})
            this.props.form.resetFields()
        }

     }
    });
 }
 //改变输入框的内容
  onChange = (e) => {
   if (e.target.value.trim() != "") {
    this.setState({
     changeRiquire: true
    })
   }else{
    this.setState({
     changeRiquire: false
    })
   }
  }
 //单选 选中商品
 onChangeBox = ( e,index) => {
  this.state.CheckedMoneyArr.splice(index,1,{checkedMoney:e.target.checked})
  this.setState({
   CheckedMoneyArr: this.state.CheckedMoneyArr
  })
  // console.log(this.state.CheckedMoneyArr)
 }
 addRow = () => {
  this.setState({
   CheckedMoneyArr: [...this.state.CheckedMoneyArr,{checkedMoney:false}]
  })
}
deleteRow =(index)=>{
   console.log(index)
   this.state.CheckedMoneyArr.splice(index,1)
   console.log(this.state.CheckedMoneyArr)
   this.setState({
    CheckedMoneyArr: this.state.CheckedMoneyArr
   })
 }

 rendRow = (getFieldDecorator, list, require,index,getGroupMemberListData) => {
  return (
   <div  key={index} >
   <Row className='nodeOpproval'>
     <Col span={10}>
        <FormItem
        style = {{display:'inline-block'}}
         {...formItemLayout2}
         label = {`审批节点${index+1}：`}
        >
         {getFieldDecorator(`opprovalName${index}`, {
          rules: [{required: require, message: "请输入审批人"}],
         })(
             <Select
              style        = {{width:'120px'}}>
              {  getGroupMemberListData&&getGroupMemberListData.length
                 &&getGroupMemberListData.length > 0 ?
                 getGroupMemberListData.map((list, index) => {
                    let val = list.memberId+','+list.memberName
                   Object.defineProperty(list,'newKey',{
                               value       : true,
                               writable    : true,
                               enumerable  : true,
                               configurable: true
                   })
                   return (
                     <Option value={val} key={index}>{list.memberName}</Option>
                   ) }) : <Option value='1'>无数据</Option>
                 }
             </Select>
         )}
        </FormItem>
     </Col>
     <Col span={4}>
      <Checkbox key={index}
            onChange={(e) => this.onChangeBox( e ,index)}>
            合批
      </Checkbox>
     </Col>
     {
        list.checkedMoney?
        <Col span={5}>
           <FormItem
           style = {{display:'inline-block',}}
           {...formItemLayout3}
           >
            {getFieldDecorator(`opprovalNameTwo${index}`, {
             rules: [{required: require, message: "请输入审批人"}],
            })(
              <Select
                style        = {{width:'120px'}}>
               {  getGroupMemberListData&&getGroupMemberListData.length
                  &&getGroupMemberListData.length > 0 ?
                  getGroupMemberListData.map((list, index) => {
                    let val = list.memberId+','+list.memberName

                   return (
                     <Option value={val} key={index}>{list.memberName}</Option>
                   ) }) : <Option value='1'>无数据</Option>
                 }
             </Select>
            )}
           </FormItem>
        </Col>
        :                                                                                                                                                                                                                                                                                                                                                                                                                                           null
     }
     <Col  span={2}>
         <Button onClick={()=> {this.deleteRow(index)}}>删除</Button>
     </Col>


   </Row>
   <Row>
      <Col >
      {
       this.state.isChoiceBtn?
      <FormItem
       style = {{display:'inline-block'}}
       {...formItemLayout2}
       label = '金额'
       >
        {getFieldDecorator(`opprovalMoney${index}`, {
         rules: [{required: require, message: "请输入金额"}],
        })(
         <Input  placeholder="请输入金额" onChange={(v) => { this.onChange(v) }}/>
        )}
       </FormItem>
       :                                                                                                                                                                                                                                                                                                                                                                                                                                    null
      }
     </Col>

   </Row>
   </div>
  )
 }

  render() {
    const { getFieldDecorator }                                             = this.props.form
    const {checkAll,count,pageNo,approvalsListData,getGroupMemberListData } = this.props.opproval
          require                                                           = true
    const formItemLayout                                                    = {
     labelCol: {
      sm: {span: 8},
     },
     wrapperCol: {
      sm: {span: 12},
     },
    }
    return (
      <div>
        <Search></Search>
        <Navigation preson={true}>
          <div className={opproval}>
            <div className={my_account_dynamic_Topimg}></div>
            {/* <BodyHeadImg headImg={{url:'/upload/img/lmadv/1508217294561.png',id:'234'}}/> */}
            <Breadcrumb separator=">" className='security_nav_bar'>
              <Breadcrumb.Item href="/presonAccunt/myAccount">我的账户</Breadcrumb.Item>
              <Breadcrumb.Item href="/group/mianManage">我的群组</Breadcrumb.Item>
              <Breadcrumb.Item href="/group/opproval" style={{fontSize:'16px', fontWeight:'bold' }}>审批流管理</Breadcrumb.Item>
            </Breadcrumb>
            <div className="filter_bar">
               <Form onSubmit={this.searchName}  layout="inline">
                <FormItem labelCol={{ span: 14 }}>
                 {getFieldDecorator('searchName')(
                  <Input placeholder="审批流程名称" />
                 )}
                </FormItem>
                <FormItem labelCol={{ span: 4 }}>
                 <Button type="primary" htmlType="submit" ghost>搜索</Button>
                </FormItem>
                <FormItem labelCol={{ span: 4 }}>
                 <span style={{backgroundColor: '#37b5aa',}} className="top-btn" onClick={()=>this.showModal1()}>新建审批流</span>
                </FormItem>
               </Form>
            </div>
            <div className="orderList_content">
              <table className="table">
                <tbody>
                  <tr>
                    {/* <th>审批流程类型</th> */}
                    <th>审批流程名称</th>
                    <th>创建时间</th>
                    <th>操作</th>
                  </tr>
                  {
                     approvalsListData && approvalsListData.length>0?
                     approvalsListData.map((val,index)=>{
                       return(
                       <tr key={index}>
                        {/* <td>{val.approvalType}</td> */}
                        <td  style={val.isUse=='1'? {}:{background:'#eee',opacity:'0.4'}}>{val.approvalName}</td>
                        <td  style={val.isUse=='1'? {}:{background:'#eee',opacity:'0.4'}}>{val.createTimeStr}</td>
                       {val.isUse=='1'?
                          <td>
                          <span style={{color: '#3a98cc',cursor: 'pointer'}}  onClick={()=>this.showModal2(val)} >查看</span>
                          <span style={{color: 'orange', marginLeft: '5px',cursor: 'pointer'}} onClick={()=>this.disuseState(val.id)}>弃用</span>
                          <span style={{color: 'red', marginLeft: '5px',cursor: 'pointer'}} onClick={()=>this.deleteList(val.id)}>删除</span>
                         </td>
                         : 
                         <td>
                          <span style={{color: '#3a98cc',cursor: 'pointer'}}  onClick={()=>this.showModal2(val)} >查看</span>
                          <span style={{color: 'orange', marginLeft: '5px',cursor: 'pointer'}} onClick={()=>this.enAble(val.id)}>启用</span>
                          <span style={{color: 'red', marginLeft: '5px',cursor: 'pointer'}} onClick={()=>this.deleteList(val.id)}>删除</span>
                         </td>

                       }
                      </tr>
                       )
                     })
                     :                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         <tr><td></td></tr>
                    }
                </tbody>
              </table>
            </div>
            <div className="cantent_paging" style={{width: '94%'}}   ref="page" key={pageNo}>
                <Pagination
                showQuickJumper
                defaultCurrent  = {1}
                defaultPageSize = {10}
                current         = {pageNo}
                total           = {approvalsListData&&approvalsListData.length>0? count: 1}
                onChange        = {this.onChangePage} />
                <Button onClick={this.goPage} style={{position:'absolute',right:'0'}}>确定</Button>
            </div>
            <Modal
             visible   = {this.state.visible1}
             title     = "新建审批流程"
             closable  = {false}
             footer    = {null}
             className = 'fund_modal'
             width     = {640}
            >
             <Form onSubmit={this.opprovalHandleOk}>
              <FormItem
               {...formItemLayout}
               label = "审批流程名称："
              >
               {getFieldDecorator('opprovalProcess', {
                rules: [{
                 required: true, message: '请输入审批流程名称',
                }],

               })(
                <Input/>
               )}
              </FormItem>
              <FormItem
               {...formItemLayout}
               label = "金额："
              >
               {getFieldDecorator('amountMoney', {
               })(
                	<Row>
                   <Switch checkedChildren="是" unCheckedChildren="否" defaultChecked  onChange={this.switchChange} />
                   <span style={{marginLeft: '15px', display: 'inline-block'}}>（可设置审批人的金额权限）</span>
                 </Row>
               )}
              </FormItem>
              <p><i style={{color:'red'}}>*</i>审批环节</p>
              {this.state.CheckedMoneyArr.map((list, index) => {
                return this.rendRow(getFieldDecorator, list, require,index,getGroupMemberListData)
               })}
                <p style={{textAlign: 'center',  marginBottom: '10px'}}>
                   <Button onClick={this.addRow}>点击新增节点</Button>
                </p>
              <FormItem style={{textAlign: 'center'}}>
               <Button key="submit" htmlType="submit" type="primary"
                       style={{marginRight: '50px'}}>提交</Button>
               <Button key="back" onClick={this.ProjectHandleCancel} className='cancel'>关闭</Button>
              </FormItem>
             </Form>
            </Modal>
            <Modal
             visible  = {this.state.visible2}
             title    = "查看审批流程"
             closable = {false}
             width    = {640}
             footer   = { <Button key="back" onClick={this.opprovalCancel}>关闭</Button> }
            >
            {
              this.state.lookVal?
               <div >
                    <p style={{margin:'10px 0',fontWeight:'bold'}}>审批流程名称：{this.state.lookVal.approvalName}</p>
                    <p style={{margin:'10px 0',fontSize:'14px',fontWeight:'bold'}}>审批环节</p>
                    {this.state.lookVal.flowList&&this.state.lookVal.flowList.length?
                     this.state.lookVal.flowList.map((list,index)=>{
                      console.log(list)
                      return(
                       <div key={list.id}>
                        <Row>
                         <Col span={12}> <b>审批节点{index+1}：</b><span>审批人: {list.firstApprovalUserName}</span></Col>
                         {list.secondApprovalUserName!='' ? <Col span={12}>合批人：{list.secondApprovalUserName}</Col>:''}
                        </Row>
                         {list.approvalAmount!='' ? <p style={{margin:'10px 0 10px 68px'}}>金额：{list.approvalAmount}</p>:''}
                       </div>
                      )
                     })
                     :                                                                                                 null

                    }

                </div>
                :                                                                                                  null

            }

            </Modal>
          </div>
        </Navigation>
      </div>
    )
  }
}

export default connect(({ opproval }) => ({ opproval }), (dispatch) => { return { dispatch } })(Form.create()(Opproval))
