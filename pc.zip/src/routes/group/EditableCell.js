import React, {Component} from 'react';
import {IMAGE_DOMAIN} from '../../utils/common';
import Stepper from '../../components/Stepper/Stepper'
import {Form,Icon,Input,Button,message,Select,Radio,Menu,Pagination,Tree,Checkbox,Modal,Tabs,Table,Popconfirm} from 'antd';
import {editable_cell} from './EditableCell.less'
import {connect} from 'dva';

const FormItem = Form.Item;


class EditableCell extends Component {
 constructor(props) {
  super(props);
  this.timerl = null;
  this.state = {
   value: '',
  
  
  }
 }


 render() {
    const {getFieldDecorator} = this.props.form;
//   const {value} = this.state;
    const dataSource=this.props.dataSource
    // console.log(dataIndex.key)
    const dataIndex=dataSource.key;
    const initialVal=dataSource.goodsName3;

  return (
   <div  className={editable_cell}>
    <div className="editable-cell-input-wrapper">
     {/* <Input
      value={value}
      onChange={this.handleChange}
      onBlur={this.handleTime}
     /> */}
       <FormItem>
            {getFieldDecorator(dataIndex, {initialValue: initialVal},)(
            <Input size="large"  />
            )}
        </FormItem>
    </div>
   </div>
  );
 }
}
export default connect(({mianManage}) => ({mianManage}), (dispatch, own) => {return {dispatch, own}})(Form.create()(EditableCell));


// export default EditableCell;
