import React, {Component} from 'react'
import {BodyHeadImg} from '../../components/Advertising/Advertising'
import {Breadcrumb, Button, Form, Table, Modal, Input, Pagination, message, Checkbox} from 'antd'
import {Link} from 'dva/router'
import {connect} from 'dva'
import {fund_list,my_account_dynamic_Topimg} from './Fund.less'
import Search from '../../components/Search/Search'
import Navigation from '../../components/Navigation/Navigation'

const FormItem      = Form.Item;
const {TextArea}    = Input;
const CheckboxGroup = Checkbox.Group;

class Fund extends Component {
 constructor(props) {
  super();
  this.state = {
   searchProject      : '',
   load               : false,
   loading            : false,
   visible            : false,
   visible1           : false,
   visible2           : false,
   activeId           : '',
   update             : false,
   fundId             : '',
   projectName        : '',
   projectCode        : '',
   projectInstructions: '',
   num                : Math.random()
  }
 }


 onChange = (e) => {
  this.setState({
   [e.target.name]: e.target.value
  })
 }
 showModal = () => {
  this.setState({
   visible: true,
  });
 }
 handleOk = (e) => {
  e.preventDefault();
  this.props.form.validateFields((err, values) => {
   console.log(err, values)
   if (!err) {
    this.setState({loading: true});
    setTimeout(() => {
     this.setState({loading: false, visible: false});
    }, 3000);
   }
  });
 }
 handleCancel = () => {
  this.setState({visible: false});
 }
 //经费搜索
 searchName = (e) => {
  e.preventDefault();

  this.props.form.validateFields(['searchName'], (err, values) => {
   if (!err) {
    if (values.searchName == '' || values.searchName == undefined) {
     // message.error('请输入搜索内容', 1.5);
     this.props.dispatch({type: 'fund/objectListListEFF', })
    } else {
     let val = {filter: values.searchName, type: 2}
     this.props.dispatch({type: 'fund/objectListListEFF', val})

    }
   }

  });
 }
 //使用人范围搜索
 handleUserRange = (e) => {
  e.preventDefault();
  // console.log(document.getElementsByClassName('searchKey')[0].value);
  this.props.form.validateFields(['userRange'], (err, values) => {
   // console.log(values)
   if (!err) {
    if (values.userRange == '' || values.userRange == undefined) {
     // message.error('请输入搜索内容', 1.5);
     this.props.dispatch({type: 'fund/getGroupMemberListEFF', })
    } else {
     let val = {userTrueName: values.userRange, type: 2}
     this.props.dispatch({type: 'fund/getGroupMemberListEFF', val})
    }
   }
   this.setState({
    num: this.state.num + 1
   })
   this.props.form.resetFields()
  });
 }
 //新建项目下一步提交
 ProjectHandleOk = (e) => {
  e.preventDefault();
  this.props.form.validateFields((err, values) => {
   console.log(values)
   if (!err) {
    let val = {
     fundsName  : values.projectName,
     fundsSn    : values.projectCode,
     fundsRemark: values.projectInstructions,
     fundId     : this.state.fundId,
    }
    console.log(val)
    this.props.dispatch({type: 'fund/groupFundsEFF', val})
    this.setState({
     visible1: false,
     visible2: true,
    });
    this.props.form.resetFields()
   }
  });
 }
 //新建项目取消
 ProjectHandleCancel = (e) => {
  this.setState({visible1: false});
  this.props.form.resetFields()
 }

 //新建经费显示
 showModal1 = (val) => {
  let info = val || {};
  this.setState({
   visible1           : true,
   activeId           : info.id,
   fundId             : info.id || "",
   projectName        : info.fundsName || "",
   projectCode        : info.fundsSn || "",
   projectInstructions: info.fundsRemark || "",
  });
 }
 //弃用
 disuseState = (id) => {
  let val = {isUse: '0', fundId: id}
  this.props.dispatch({type: 'fund/groupFundsEFF', val})
  this.setState({
   load: !this.state.load
  })
 }
 //启用
 enAble = (id) => {
  let val = {isUse: '1', fundId: id}
  this.props.dispatch({type: 'fund/groupFundsEFF', val})
  this.setState({
   load: !this.state.load
  })
 }
 //分页

 onChangePage = (pageNo) => {
  console.log(pageNo)
  this.props.dispatch({type: 'fund/objectListListEFF', val: {pageNo: pageNo, type: 2}});
  this.setState({
   update: true,
  })
  window.scrollTo(0, 0)
 }
 goPage = () => {
  let maxPage = Math.ceil(this.props.fund.count / 10)
  console.log(this.refs.page)
  let pageNo = this.refs.page.getElementsByTagName("input")[0].value;
      pageNo = pageNo > maxPage ? maxPage : pageNo
  if (!!pageNo) {
   this.setState({
    update: true
   }, () => this.props.dispatch({
    type: 'fund/objectListListEFF',
    val : {pageNo: pageNo, type: 2}
   }))
   window.scrollTo(0, 0)
   this.refs.page.getElementsByTagName("input")[0].value = ""
  }
 }
 //   //搜索名字
 // handleSubmitSearch = (e) => {
 //       e.preventDefault();
 //       console.log(e)
 //        let val = e.target.firstChild.value;
 //        console.log(val)
 //        if(val==''){
 //       message.warning('请键入关键字进行搜索！');
 //      return
 //    }

 // }
 //项目使用人范围
 handleUserOk = (getGroupMemberListData) => {
  console.log(getGroupMemberListData)
  let arrMember = []
  getGroupMemberListData.map((val, index) => {
   if (val.checked) {
    arrMember.push(val.memberId)
   }
  })
  if(this.state.fundId ==''){//新建

   this.props.dispatch({type: 'fund/groupFundsEFF', val : {userIds: arrMember.join(','), type: 2, prevId:'prevId',}})
  }else{//编辑的时候
   this.props.dispatch({type: 'fund/groupFundsEFF', val : {userIds: arrMember.join(','), type: 2, fundId: this.state.fundId,}})
  }

  this.setState({
   visible2: false,
  });
 }
 handleUserCancel = () => {
  this.setState({visible2: false, load: !this.state.load,});
  this.props.dispatch({type: 'fund/getGroupMemberListEFF', val: {type: 2}})
 }

 //全选
 onCheckAllChange = (e) => {
  this.props.dispatch({type: 'fund/checkAll', preload: e.target.checked})
 }
 //单选 选中商品
 onChangeBox = (data, val, e) => {
  let value = {
   getGroupMemberListData: data,
   checkedGoods          : val,
   checked               : e.target.checked
  }
  this.props.dispatch({type: 'fund/checkGoods', value})

 }

 render() {
  const {getFieldDecorator}                                                   = this.props.form;
  let   {num}                                                                 = this.state;
  const {objectListListData, getGroupMemberListData, checkAll, count, pageNo} = this.props.fund
  const formItemLayout                                                        = {
   labelCol: {
    sm: {span: 8},
   },
   wrapperCol: {
    sm: {span: 12},
   },
  }

  return (
   <div>
    <Search></Search>
    <Navigation preson={true}>
     <div className={fund_list}>
       <div className={my_account_dynamic_Topimg}></div>
      {/* <BodyHeadImg headImg={{url: '/upload/img/lmadv/1508217294561.png', id: '234'}}/> */}
      <Breadcrumb separator=">" className='security_nav_bar'>
       <Breadcrumb.Item href="/presonAccunt/myAccount">我的账户</Breadcrumb.Item>
       <Breadcrumb.Item href="/group/mianManage">我的群组</Breadcrumb.Item>
       <Breadcrumb.Item href="/group/fund" style={{fontSize:'16px', fontWeight:'bold' }}>群组经费管理</Breadcrumb.Item>
      </Breadcrumb>
      <div className="filter_bar">
       <Form onSubmit={this.searchName} layout="inline">
        <FormItem labelCol={{span: 14}}>
         {getFieldDecorator('searchName')(
          <Input placeholder="名称"/>
         )}
        </FormItem>
        <FormItem labelCol={{span: 4}}>
         <Button type="primary" htmlType="submit" ghost>搜索</Button>
        </FormItem>
        <FormItem labelCol={{span: 4}}>
         <span style={{backgroundColor: '#37b5aa',}} className="top-btn" onClick={() => this.showModal1()}>新建经费</span>
        </FormItem>
       </Form>
      </div>
      <div className="orderList_content">
       <table className="table">
        <tbody>
        <tr>
         <th>经费名称</th>
         <th>经费代号</th>
         <th>经费说明</th>
         <th>创建时间</th>
         <th>操作</th>
        </tr>
        {
         objectListListData && objectListListData.length > 0 ?
          objectListListData.map((val, index) => {
           return (
            <tr key={index}>
             <td>{val.fundsName}</td>
             <td>{val.fundsSn}</td>
             <td>{val.fundsRemark}</td>
             <td>{val.createTimeStr}</td>
             {val.isUse == '1' ?
              <td>
               <span style={{color: '#3a98cc', cursor: 'pointer'}} onClick={() => this.showModal1(val)}>编辑</span>
               <span style={{color: 'orange', marginLeft: '5px', cursor: 'pointer'}}
                     onClick={() => this.disuseState(val.id)}>弃用</span>
              </td>
              : 
              <td>
               <span style={{color: '#3a98cc', cursor: 'pointer'}} onClick={() => this.showModal1(val)}>编辑</span>
               <span style={{color: 'orange', marginLeft: '5px', cursor: 'pointer'}}
                     onClick={() => this.enAble(val.id)}>启用</span>
              </td>

             }
            </tr>
           )
          })
          :              <tr></tr>
        }
        </tbody>
       </table>
      </div>
      <div className="cantent_paging" style={{width: '94%'}} ref="page" key={pageNo}>
       <Pagination
        showQuickJumper
        defaultCurrent  = {1}
        defaultPageSize = {10}
        current         = {pageNo}
        total           = {getGroupMemberListData && getGroupMemberListData.length > 0 ? count : 1}
        onChange        = {this.onChangePage}/>
       <Button onClick={this.goPage} style={{position: 'absolute', right: '0'}}>确定</Button>
      </div>
      <Modal
       visible   = {this.state.visible1}
       title     = "新建经费"
       closable  = {false}
       footer    = {null}
       className = 'fund_modal'
      >
       <Form onSubmit={this.ProjectHandleOk}>
        <FormItem
         {...formItemLayout}
         label = "经费名称："
        >
         {getFieldDecorator('projectName', {
          rules: [{
           required: true, message: '请输入1-16个字符', min: 1, max: 16,
          }],
          initialValue: this.state.projectName
         })(
          <Input/>
         )}
        </FormItem>
        <FormItem
         {...formItemLayout}
         label = "经费代号："
        >
         {getFieldDecorator('projectCode', {
          rules: [{
           required: true, message: '请输入1-16个字符', min: 1, max: 16,
          }],
          initialValue: this.state.projectCode
         })(
          <Input/>
         )}
        </FormItem>

        <FormItem
         {...formItemLayout}
         label = "经费说明："
        >
         {getFieldDecorator('projectInstructions', {
          initialValue: this.state.projectInstructions
         })(
          <TextArea rows={4}/>
         )}
        </FormItem>
        <FormItem style={{textAlign: 'center'}}>
         <Button key="submit" htmlType="submit" type="primary" loading={this.state.loading}
                 style={{marginRight: '50px'}}>下一步</Button>
         <Button key="back" onClick={this.ProjectHandleCancel} className='cancel'>关闭</Button>
        </FormItem>
       </Form>
      </Modal>
      <Modal
       visible  = {this.state.visible2}
       closable = {false}
       width    = {640}
       okText   = "完成"
       onOk     = {() => this.handleUserOk(getGroupMemberListData)}
       onCancel = {this.handleUserCancel}
       footer   = {<div style={{textAlign: 'center'}}>
        <Button key="submit2" onClick={() => this.handleUserOk(getGroupMemberListData)}>提交</Button>
        <Button key="back" onClick={this.handleUserCancel}>关闭</Button>,
       </div>}
      >
       <div style={{
        textAlign    : 'center',
        fontSize     : '16px',
        paddingBottom: '20px',
        borderBottom : '1px solid #e4e4e4',
        marginBottom : '20px'
       }}>
        设置使用人范围
       </div>
       <div style={{textAlign: 'center', marginBottom: '15px'}}>
         <span>
          <Checkbox onChange={this.onCheckAllChange}
                    checked={checkAll}>全选</Checkbox>
         </span>
        <Form onSubmit={(e) => this.handleUserRange(e)} style={{display: 'inline-block'}}>
         <FormItem labelCol={{span: 10}} style={{display: 'inline-block'}}>
          {getFieldDecorator('userRange', {
           // initialValue: this.state.projectCode
          })(
            <Input key={num} style={{width: '200px', marginRight: '10px'}} />
          )}
         </FormItem>
         {/* <Input style={{ width:'270px',marginRight:'10px' }}></Input> */}
         <Button htmlType="submit" style={{
          color       : '#fff',
          borderRadius: '4px',
          textAlign   : 'center',
          padding     : '8px 12px',
          background  : '#3a98cc',
         }}>搜索</Button>
        </Form>
       </div>
       {
        getGroupMemberListData && getGroupMemberListData.map((val, index) => {
         return (
          <Checkbox key={index} checked={val.checked}
                    onChange={(e) => this.onChangeBox(getGroupMemberListData, val, e)}>{val.memberName}</Checkbox>
         )
        })
       }
      </Modal>

     </div>
    </Navigation>
   </div>
  )
 }
}

export default connect(({fund}) => ({fund}), (dispatch, own) => {
 return {dispatch, own}
})(Form.create()(Fund))
