import React, {Component} from 'react'
import {BodyHeadImg} from '../../components/Advertising/Advertising'
import {Breadcrumb, Checkbox, Row, Col, Pagination, Input, Button, Form, Modal, message} from 'antd'
import {Link} from 'dva/router'
import {connect} from 'dva'
import {fav_list} from './ManageFav.less'
import Img from "../../components/Img/Img"
import Search from '../../components/Search/Search'
import Navigation from '../../components/Navigation/Navigation'
import ManageFavFloor from './ManageFavFloor'

const FormItem = Form.Item;

class groupFav extends Component {
 state = {
  value    : 0,
  checkAll : false,
  moveToTop: false
 }


  //经费搜索
  searchName = (e) => {
   e.preventDefault();

   this.props.form.validateFields(['searchName'], (err, values) => {
    if (!err) {
     if (values.searchName == '' || values.searchName == undefined) {
      // message.error('请输入搜索内容', 1.5);
      let val = {type:'0'}
      this.props.dispatch({type: 'groupFav/searchFavGoods',val})
     } else {
      let val = {goodsName: values.searchName,type:'0'}
      console.log(val)
      this.props.dispatch({type: 'groupFav/searchFavGoods', val})

     }
    }

   });
  }
 // 选择商品
 checkGoods = (checkedGoods, checked) => {
  let value = {
   checkedGoods,
   checked
  }
  this.props.dispatch({type: 'groupFav/checkGoodsEFF', payload: value})
 }
 delGoods = (goodsId) => {
  const value = {
   goodsId: goodsId
  }
  console.log(value)
  Modal.confirm({
   title  : '您确定要删除吗?',
   content: '',
   onOk   : () => {
    console.log(value)
    this.props.dispatch({type: 'groupFav/deleteGoodsFavoritesEFF', payload: value});
   },
   onCancel() {
    console.log('取消');
   },
  });
 }
 //删除选中的商品
 delSelGoods = () => {
  let goodsId = [];
  this.props.groupFav.goodsFavoritesList.forEach(goods => {
   if (goods.checked) {
    goodsId.push(goods.goodsId);
   }
  })
  if (goodsId.length == 0) {
   message.info('请先选择商品', 1)
   return;
  }
  Modal.confirm({
   title     : '提示',
   content   : '确定删除吗',
   okText    : '确定',
   cancelText: '取消',
   onOk      : () => {
    let value = {
     goodsId: goodsId.join(',')
    }
    this.props.dispatch({type: 'groupFav/deleteGoodsFavoritesEFF', payload: value});
   },
   maskClosable: true
  });

 }
 //全选
 checkAll = (checked) => {
  this.props.dispatch({type: 'groupFav/checkAllEFF', payload: checked});
 }
 addCart = (goodsId, goodsPrice,goodsMaterial) => {
  let val = {
   goodsId      : goodsId,
   count        : 1,
   goodsPrice   : goodsPrice,
   saveType     : 0,
   goodsMaterial: goodsMaterial,
  }
  console.log(val)
  this.props.dispatch({type: 'groupFav/addCart', val});
 }
 handleAddCarts = () => {
  let purTemplateItems = [];
  this.props.groupFav.goodsFavoritesList.forEach(function (v, index, array) {
   if (v.checked) {
    if(v.goodsStorePrice > 0 && v.isControlInfo == 1){
     purTemplateItems.push({goodsId: v.goodsId, newGoodsPrice: v.goodsStorePrice, goodsNum: 1, goodsSource: 0,goodsMaterial: v.goodsMaterial})
    }
   }
  });
  if (purTemplateItems.length == 0) {
   message.info('请先选择商品', 1)
   return;
  }
  this.props.dispatch({
   type: 'groupFav/getAddCartBachEFF',
   arr : purTemplateItems
  })

  if (this.props.initState) {
   this.setState({
    dataSource: []
   })
  }
 }

 getScroollHieght = () => {
  let winH = document.documentElement.clientHeight || document.body.clientHeight;
  // let documentH = document.documentElement.scrollHeight || document.body.scrollHeight;
  let dataTableH   = this.refs.favListTab.offsetHeight;
  let ElescrollTop = document.body.scrollTop || document.documentElement.scrollTop;
  if (dataTableH > winH && ElescrollTop > 485) {
   this.setState({
    moveToTop: true
   })
  } else {
   this.setState({
    moveToTop: false
   })
  }
 }
 componentDidMount = () => {
  document.addEventListener("scroll", this.getScroollHieght, false);
 }
 componentWillUnmount = () => {
  document.removeEventListener("scroll", this.getScroollHieght, false)
 }

 render() {
  const {goodsFavoritesList, checkAll,role,getMyGroupInfoDate} = this.props.groupFav
  const {getFieldDecorator}                                    = this.props.form;
  // console.log(getMyGroupInfoDate[0])
  return (
   <div>
    <Search></Search>
    <Navigation preson={true}>
     <div className={fav_list}>
     <div className="my_account_dynamic_Topimg"></div>
      <Breadcrumb separator=">" className='security_nav_bar'>
       <Breadcrumb.Item href="/presonAccunt/myAccount">我的账户</Breadcrumb.Item>
       <Breadcrumb.Item href="/group/mianManage" >我的群组</Breadcrumb.Item>
       <Breadcrumb.Item href="/group/manageFav" style={{fontSize:'16px', fontWeight:'bold' }}>群组收藏夹</Breadcrumb.Item>
      </Breadcrumb>
      {role=='1'?
          <div>
           <a
            style = {{display:'block',padding:'5px',background:'#108ee9',width:'105px',color:'#fff',borderRadius:'5px',marginTop:'20px',cursor:'pointer' }}
            href  = '/group/groupFavOpear'
            >群组收藏夹管理</a>

             <p>群组名称：{getMyGroupInfoDate&&getMyGroupInfoDate[0]&&getMyGroupInfoDate[0].sinoOrgName?
               getMyGroupInfoDate[0].sinoOrgName:''}
             </p>
             {
              getMyGroupInfoDate&&getMyGroupInfoDate[0]&&getMyGroupInfoDate[0].orgContactList&&
              getMyGroupInfoDate[0].orgContactList.length?
              getMyGroupInfoDate[0].orgContactList.map((item,index)=>{
                    return(
                     <div key={index} className="group_detail">
                       <i style={{fontStyle:'normal',marginLeft:'12px'}}> 管理员： </i>
                       {item.orgContacts}(联系方式：{item.orgTel})
                     </div>
                    )
                  })
                  : 
                   <div>
                         <i style={{fontSize:'14px',fontStyle:'normal'}}> 管理员：</i>
                         联系方式：
                   </div>
                }
            </div>
           :                    null
         }
      <div className="filter_bar">
       <Form onSubmit={this.searchName} layout="inline">
        <FormItem labelCol={{span: 24}}>
         {getFieldDecorator('searchName')(
          <Input placeholder="商品编号/名称"/>
         )}
        </FormItem>
        <FormItem>
         <Button type="primary" htmlType="submit" ghost>搜索</Button>
        </FormItem>
       </Form>
      </div>
      <div className="orderList_content">
       <Row className="orderList_content_head">
        <Col span={2}>
         <Checkbox
          onChange = {(e) => this.checkAll(e.target.checked)}
          checked  = {checkAll}
         >
          全选
         </Checkbox></Col>
        <Col span={8}>基本信息</Col>
        <Col span={7}>商品属性</Col>
        <Col span={4}>交易信息</Col>
        <Col span={3}>操作</Col>
       </Row>
      </div>
      {goodsFavoritesList && goodsFavoritesList.length > 0 ?
       <div>
       <div ref='favListTab'>
        {goodsFavoritesList.map((list, index) => {
         return (<ManageFavFloor data={list || []} key={index} delGoods={this.delGoods} checkGoods={this.checkGoods}
                               addCart={this.addCart}></ManageFavFloor>)
        })}
       </div>
        {goodsFavoritesList && goodsFavoritesList.length > 0 ? <div className={this.state.moveToTop ? "gift_cart_settlement moveToTop" : "gift_cart_settlement"}>
       <Checkbox
       onChange = {(e) => this.checkAll(e.target.checked)}
       checked  = {checkAll}
       >
       全选
       </Checkbox>
       {/* <a onClick={() => this.delSelGoods()}>删除选中商品</a> */}

       <button onClick={() => this.handleAddCarts()}>加入购物车</button>
       </div> : <p style={{textAlign: "center", margin: '10px'}}>无数据</p>}
       </div>
       :                          <p style={{textAlign: "center", margin: '10px'}}>无数据</p>
      }
     </div>
    </Navigation>
   </div>
  )
 }
}

export default connect(({groupFav}) => ({groupFav}), (dispatch) => {
 return {dispatch}
})(Form.create()(groupFav))
