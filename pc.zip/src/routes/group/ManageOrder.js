import React, { Component } from 'react'
import { BodyHeadImg } from '../../components/Advertising/Advertising'
import { Breadcrumb, Checkbox,Table, Row, Col, Pagination, Input, Button, Form, Modal, Select, Switch, DatePicker,message } from 'antd'
import { routerRedux,Link } from 'dva/router'
import { connect } from 'dva'
import { manageOrder ,my_account_dynamic_Topimg} from './ManageOrder.less'
import Img from "../../components/Img/Img"
import Search from '../../components/Search/Search'
import Navigation from '../../components/Navigation/Navigation'
import {exportOrderAPI} from './api'
import {IMAGE_DOMAIN} from "../../utils/common"
import moment  from 'moment'
const FormItem = Form.Item;
const Option   = Select.Option;

const formItemLayout = {
  labelCol: { span: 8 }
};

class ManageOrder extends Component {
  state = {
    startValue   : null,
    endValue     : null,
    selectTime   : '0',
    startTime    : '',
    endTime      : '',
    selectState  : '9',
    filterMin    : '',
    filterMax    : '',
    orderFilter  : '',
    endOpen      : false,
    data         : [],
    value        : 0,
    checkAll     : false,
    loading      : true,
    visibleRemind: false,
    xyChecked    : false,
    xyChecked2   : false,

  }

  //表单提交
  handleSubmit = (e) => {
    e.preventDefault();
        let val={
          timeState     : this.state.selectTime,    // 筛选时间类型
          startTime     : this.state.startTime,     //  起始时间
          endTime       : this.state.endTime,       // 截止时间
          checkStatus   : this.state.selectState,   //审批状态
          mixOrderAmount: this.state.filterMin,     // 订单金额
          maxOrderAmount: this.state.filterMax,     // 订单金额
          filter        : this.state.orderFilter,   // 筛选条件
        }
        console.log(val)
        this.props.dispatch({type: 'manageOrder/groupOrderCheckListEFF',val })

  }
  //审批状态改变
  handleChangeState = (value) => {
    this.setState({selectState: value})
  }
  //时间状态改变（审批/下单）
  handleChangeTime = (value) => {
    this.setState({selectTime: value})
  }
  //时间选择
  disabledStartDate = (startValue) => {
    const endValue = this.state.endValue;
    if (!startValue || !endValue) {
      return false;
    }
    return startValue.valueOf() > endValue.valueOf();
  }
  disabledEndDate = (endValue) => {
    const startValue = this.state.startValue;
    if (!endValue || !startValue) {
      return false;
    }
    return endValue.valueOf() <= startValue.valueOf();
  }
  onStartOk = () => {
    if(this.state.startValue == null){
     let formatTime  = moment(Date.now()).format('YYYY-MM-DD');
     let formatValue = moment(Date.now());                       //参数换成毫秒
     if(this.state.endValue == null || formatValue <= this.state.endValue){
        this.setState({ startTime : formatTime, startValue : formatValue });
        //设置DatePicker的value
        this.props.form.setFieldsValue({
           startTime : formatTime,
           startValue: formatValue
        })
     }
    }
  }
  onEndOk = () => {
    if(this.state.endValue == null){
     let formatTime  = moment(Date.now()).format('YYYY-MM-DD');
     let formatValue = moment(Date.now());                       //参数换成毫秒
     if(this.state.startValue == null || formatValue >= this.state.startValue){
      this.setState({ endTime:formatTime, endValue:formatValue });
      //设置DatePicker的value
      this.props.form.setFieldsValue({
         endTime : formatTime,
         endValue: formatValue
      })
     }
    }
   }
   onStartChange = (value, dateString) => {
    this.setState({startTime:dateString,startValue:value })
   }
   onEndChange = (value, dateString) => {
    this.setState({endTime:dateString,endValue:value })
   }
   handleStartOpenChange = (open) => {
     if (!open) {
       this.setState({ endOpen: true });
     }
   }
   handleEndOpenChange = (open) => {
     this.setState({ endOpen: open });
   }
//分页
onChangePage = (pageNo) => {
   let val = {
    timeState     : this.state.selectTime,    // 筛选时间类型
    startTime     : this.state.startTime,     //  起始时间
    endTime       : this.state.endTime,       // 截止时间
    checkStatus   : this.state.selectState,   //审批状态
    mixOrderAmount: this.state.filterMin,     // 订单金额
    maxOrderAmount: this.state.filterMax,     // 订单金额
    filter        : this.state.orderFilter,   // 筛选条件
    pageNo        : pageNo,
   }
  this.props.dispatch({type: 'manageOrder/groupOrderCheckListEFF', val });

  window.scrollTo(0, 0)
}
goPage = () => {
  let maxPage = Math.ceil(this.props.manageOrder.count / 10);
  let pageNo  = this.refs.page.getElementsByTagName("input")[0].value;
      pageNo  = pageNo > maxPage ? maxPage : pageNo
  if (!!pageNo) {
    let val = {
      timeState     : this.state.selectTime,    // 筛选时间类型
      startTime     : this.state.startTime,     //  起始时间
      endTime       : this.state.endTime,       // 截止时间
      checkStatus   : this.state.selectState,   //审批状态
      mixOrderAmount: this.state.filterMin,     // 订单金额
      maxOrderAmount: this.state.filterMax,     // 订单金额
      filter        : this.state.orderFilter,   // 筛选条件
      pageNo        : pageNo,
    }
    this.props.dispatch({ type: 'manageOrder/groupOrderCheckListEFF', val });

   window.scrollTo(0, 0)
   this.refs.page.getElementsByTagName("input")[0].value = ""
  }
 }
 //导出订单明细
 exportOrder = () => {
  // let orderIds=this.props.myOrder.excelOrderListData? this.props.myOrder.excelOrderListData:'';
    let orderIds = this.props.manageOrder.orderIds?this.props.manageOrder.orderIds:'';
   exportOrderAPI({
     orderIds: orderIds,
   }).then(r=>{
     if(r.result==1){
       console.log(r.filePath)
       let url                  = `${IMAGE_DOMAIN}${r.filePath}`;
           window.location.href = url
     }else {
       message.error(r.msg,1.5);
     }

   })
 }

 showModalRemind = () => {
  this.setState({
    visibleRemind: true,
  });
}
onXyChecked = () => {
 this.setState({xyChecked: !this.state.xyChecked})
}
onXyChecked2 = () => {
 this.setState({xyChecked2: !this.state.xyChecked2})
}
remindSubmit = (e) => {
 e.preventDefault();
 this.props.form.validateFields((err, values) => {
  if (!err) {
         console.log(values)
     let  val={

         // isApprovalEmailNotify: values.noticeEmail&&values.noticeEmail== true ? '1': '0',   //是否邮箱                : '',
         // isApprovalPhoneNotify: values.noticeTel&&values.noticeTel== true ? '1'    : '0',

         isApprovalEmailNotify: this.props.manageOrder.checkAll&&this.props.manageOrder.checkAll==true?'1'  : '0',
         isApprovalPhoneNotify: this.props.manageOrder.checkAll2&&this.props.manageOrder.checkAll2==true?'1': '0'

     }
     console.log(val)
     this.props.dispatch({type:'manageOrder/setApprovalOrderNotifyAPIEFF',val})

      this.setState({
       visibleRemind: false,
     });
  }
 });
}
 //全选
 onCheckAllChange = (e) => {
  this.props.dispatch({type: 'manageOrder/checkAll', preload: e.target.checked})
 }
  //全选
  onCheckAllChange2 = (e) => {
   this.props.dispatch({type: 'manageOrder/checkAll2', preload: e.target.checked})
  }


  render() {
    const { getFieldDecorator }                                                                  = this.props.form
    const { startValue, endValue, endOpen }                                                      = this.state;
    const { groupOrderCheckListData,checkAll,checkAll2,count,pageNo,orderIds,getMyGroupInfoData} = this.props.manageOrder
   console.log(getMyGroupInfoData)
   const initialTel     = getMyGroupInfoData.memberMobile;
   const initialEmail   = getMyGroupInfoData.memberEmail;
   const formItemLayout = {
      labelCol  : { span: 2 },
      wrapperCol: { span: 2 },
     };
     const formItemLayout2 = {
      labelCol: {
       xs: {span: 24},
       sm: {span: 6},
      },
      wrapperCol: {
       xs: {span: 24},
       sm: {span: 14},
      },
     };
    return (
      <div>
        <Search></Search>
        <Navigation preson={true}>
          <div className={manageOrder}>
          <div className={my_account_dynamic_Topimg}></div>
            {/* <BodyHeadImg headImg={{url:'/upload/img/lmadv/1508217294561.png',id:'234'}}/> */}
            <Breadcrumb separator=">" className='security_nav_bar'>
              <Breadcrumb.Item href="/presonAccunt/myAccount">我的账户</Breadcrumb.Item>
              <Breadcrumb.Item href="/group/mianManage">我的群组</Breadcrumb.Item>
              <Breadcrumb.Item href="/group/manage-order" style={{fontSize:'16px', fontWeight:'bold' }}>群组审批订单</Breadcrumb.Item>
            </Breadcrumb>
            <div className="filter_bar">
              <div className="clear">
                <div>
                <Form onSubmit={this.handleSubmit} layout="inline">
                  <Row>
                    <Col span={2} style={{ marginRight: '10px'}}>
                      {getFieldDecorator('selectTime',{initialValue:'0'})(
                        <Select onChange={this.handleChangeTime}>
                          <Option value="0">下单时间</Option>
                          <Option value="1">审批时间</Option>
                        </Select>
                      )}
                    </Col>
                    <Col span={4}>
                      <FormItem
                        {...formItemLayout}>
                        {getFieldDecorator('startValue',{setFieldsValue:startValue})(
                          <DatePicker
                            disabledDate = {this.disabledStartDate}
                            showTime
                            format       = "YYYY-MM-DD"
                            placeholder  = "开始日期"
                            onOk         = {this.onStartOk}
                            onChange     = {this.onStartChange}
                            onOpenChange = {this.handleStartOpenChange}
                          />
                        )}
                      </FormItem>
                    </Col>
                    <Col span={1} style={{width:'10px',paddingTop:'8px',margin: '0 5px'}}>-</Col>
                    <Col span={4}>
                      <FormItem>
                        {getFieldDecorator('endValue',{setFieldsValue:endValue})(
                          <DatePicker
                            disabledDate = {this.disabledEndDate}
                            showTime
                            format       = "YYYY-MM-DD"
                            placeholder  = "结束日期"
                            onOk         = {this.onEndOk}
                            onChange     = {this.onEndChange}
                            open         = {endOpen}
                            onOpenChange = {this.handleEndOpenChange}
                          />
                        )}
                      </FormItem>
                    </Col>
                    <Col span={5} style={{marginLeft:'30px'}}>
                      <FormItem label="审批状态">
                        {getFieldDecorator('selectState',{initialValue:'9'})(
                          <Select onChange={this.handleChangeState} style={{ width:95}}>
                            <Option value="9">全部</Option>
                            <Option value="1">未审批</Option>
                            <Option value="2">审批通过</Option>
                            <Option value="3">审批不通过</Option>
                          </Select>
                        )}
                      </FormItem>
                    </Col>
                    <div className="r">
                      <b onClick={this.showModalRemind}  className="btn" style={{ background: '#3a98cc'}}>审批提醒设置</b>

                    </div>
                  </Row>
                  <Row style={{marginTop: '10px'}}>

                    <Col span={5} style={{width:'18.4%',display:'inline'}} >
                      <FormItem label="订单金额：">
                        {getFieldDecorator('filterMin')(
                            <Input style={{width: '100px'}}  onChange={(e)=>this.setState({filterMin:e.target.value})} />
                        )}
                      </FormItem>
                    </Col>
                    <Col span={1} style={{marginTop:'5px',width:'2%'}} >-</Col>
                    <Col span={4}>
                      <FormItem>
                        {getFieldDecorator('filterMax')(
                          <Input style={{width: '100px'}}  onChange={(e)=>this.setState({filterMax:e.target.value})} />
                        )}
                      </FormItem>
                    </Col>
                    <Col span={5} style={{marginLeft:'-8px'}}>
                      <FormItem>
                        {getFieldDecorator('orderNumber')(
                          <Input style={{width: '170px'}} placeholder="订单号/发起人/审批流名称" onChange={(e)=>this.setState({orderFilter:e.target.value})} />
                        )}
                      </FormItem>
                    </Col>
                    <Col span={2}>
                      <FormItem {...formItemLayout}>
                        <Button type="primary" htmlType="submit" ghost>搜索</Button>
                      </FormItem>
                    </Col>
                    <div className="r">
                      <span onClick={()=>this.exportOrder()}  className="btn" style={{ background: '#3a98cc'}}>导出订单明细</span>
                    </div>
                  </Row>
                </Form>
                </div>
              </div>
            </div>
            <div className="orderList_content">
              <table className="table">
                <tbody>
                  <tr>
                    <th >订单号</th>
                    <th>下单时间</th>
                    <th>发起人</th>
                    <th>订单金额</th>
                    <th>审批状态</th>
                    <th>审批时间</th>
                    <th>审批意见</th>
                    <th>操作</th>
                  </tr>
                     {
                      groupOrderCheckListData && groupOrderCheckListData.length>0?
                      groupOrderCheckListData.map((val,index)=>{
                       return(
                                    <tr key={index}>
                                      <td >{

                                        val.dangerousRemarkList.map((item,i)=>{
                                          return <Img key={i} style={{width: '23px', marginRight: '10px',verticalAlign:'middle'}} src={item}/>
                                        })
                                      }
                                      {val.orderSn}
                                      </td>
                                      <td>{val.createTimeStr}</td>
                                      <td>{val.buyerName}</td>
                                      <td>{val.orderAmount}</td>
                                      <td>{val.checkStatueStr}</td>
                                      <td>{val.checkTimeStr}</td>
                                      <td>{val.checkRemark}</td>
                                      {val.checkStatus=='1'?
                                          <td>
                                            <a title="审批" href={`/personOrder/orderDetailtype/${val.orderId}`} target='_blank' style={{ color: '#3599BB',cursor: 'pointer' ,}}>审批</a>
                                          </td>
                                          : 
                                          <td>
                                            <a title="查看详情" href={`/personOrder/orderDetailtype/${val.orderId}`} target='_blank'  style={{ color: '#3599BB',cursor: 'pointer' }}>查看详情</a>
                                          </td>

                                      }
                                    </tr>
                        )
                      })
                      :                                                                          <tr><td></td></tr>
                     }
                </tbody>
              </table>
            </div>
            <div className="cantent_paging" style={{width: '94%'}}   ref="page" key={pageNo}>
                <Pagination
                showQuickJumper
                defaultCurrent  = {1}
                defaultPageSize = {10}
                current         = {pageNo}
                total           = {groupOrderCheckListData&&groupOrderCheckListData.length>0? count: 1}
                onChange        = {this.onChangePage} />
                <Button onClick={this.goPage} style={{position:'absolute',right:'0'}}>确定</Button>
           </div>


           <Modal
                visible  = {this.state.visibleRemind}
                closable = {false}
                width    = {440}
                footer   = {false}
               >
              <div>
                    <p style={{margin:'10px 0',textAlign:'center',width:'100%',borderBottom:'1px solid #ccc',fontWeight:'bold',fontSize:'16px'}}>审批提醒设置</p>
                    <Form onSubmit={this.remindSubmit} >
                           <FormItem style={{textAlign:'center'}}>
                                 <div>
                                      <p>联系邮箱：{initialEmail}</p>
                                      <p>联系手机：{initialTel}</p>
                                 </div>
                           </FormItem>
                             <FormItem style={{textAlign:'center'}}  {...formItemLayout2}>
                                {getFieldDecorator('noticeEmail', )(
                                    <div>
                                        <Checkbox
                                          checked  = {checkAll}
                                          onChange = {this.onCheckAllChange}
                                         >
                                         </Checkbox> <span>接受邮件提醒</span>
                                    </div>
                                )}
                            </FormItem>
                            <FormItem style={{textAlign:'center'}}  {...formItemLayout2}>
                                {getFieldDecorator('noticeTel', )(
                                    <div>
                                        <Checkbox

                                         checked  = {checkAll2}
                                         onChange = {this.onCheckAllChange2}
                                        >
                                        </Checkbox> <span>接受手机提醒</span>
                                    </div>
                                )}
                            </FormItem>
                            <FormItem style={{textAlign:'center'}}>
                                    <Button type="primary" htmlType="submit" ghost>确定</Button>
                            </FormItem>
                    </Form>
              </div>
            </Modal>


          </div>
        </Navigation>
      </div>
    )
  }
}

export default connect(({ manageOrder }) => ({ manageOrder }), (dispatch,own) => { return { dispatch,own} })(Form.create()(ManageOrder))
