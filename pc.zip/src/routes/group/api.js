import {get, post} from '../../utils/request';




//用户名验证
export  function getCheckLoginName(loginName) {
  return get('/loginApi/checkLoginName',loginName);
}


// 导出审批订单
export function exportOrderAPI(val){
    return get('/groupApi/exportOrderCheckDetailExcel',val)
}
// 列表导出
export function exportOrderListAPI(val){
 return get('/groupApi/exportOrderListExcel',val)
}
// 明细导出
export function exportOrderDetailAPI(val){
 return get('/groupApi/exportOrderDetailExcel',val)
}

 // 群组收藏夹管理的上传模板下载
 export  function exportFavoritesExceApi(obj) {
  return  post('groupApi/exportFavoritesExcel',obj);
 }


 //新建成员下载模板
export function exportGroupMemberExcelAPI( obj){
 return post('/groupApi/exportGroupMemberExcel',obj)
}
 //新建成员导入
 export function importGroupMemberExcelAPI( obj){
  return post('/groupApi/importGroupMemberExcel',obj)
 }

