import React, { Component } from 'react'
import { BodyHeadImg } from '../../components/Advertising/Advertising'
import { Breadcrumb, Checkbox, Row, Col, Pagination, Input, Button, Form, Modal, Select, Switch,message,Upload,Icon } from 'antd'
import { Link } from 'dva/router'
import { connect } from 'dva'
import { manageMember,my_account_dynamic_Topimg } from './ManageMember.less'
import Img from "../../components/Img/Img"
import Search from '../../components/Search/Search'
import Navigation from '../../components/Navigation/Navigation'
import {getCheckLoginName,exportGroupMemberExcelAPI,importGroupMemberExcelAPI} from './api';
import {IMAGE_DOMAIN} from "../../utils/common"
const FormItem     = Form.Item;
const { TextArea } = Input;

class ManageMember extends Component {
  state = {
    value         : 0,
    checkAll      : false,
    visible       : false,
    visibleNew    : false,
    visible1      : false,
    visible2      : false,
    visible3      : false,
    visible4      : false,
    activeId      : '',
    load          : false,
    loading       : false,
    checkAll      : false,
    typeOne       : '',
    typeTwo       : '',
    typeThree     : '',
    typeFour      : '',
    id            : '',
    memberId      : '',
    userId        : '',
    contactName   : '',
    loginName     : '',
    loginNameNew  : '',
    roleAuthoritys: '',

   numApproval: Math.random(),
   numProject : Math.random(),
   numFund    : Math.random(),

    }
	searchName = (e) => {
		    e.preventDefault();
		    this.props.form.validateFields(['searchName'],(err, values) => {
		      if (!err) {
			        if(values.searchName==''||values.searchName==undefined){
      // message.error('请输入搜索内容',1.5);
      this.props.dispatch({type:'manageMember/getGroupMemberListEFF',})
					}else{
						let val = {userTrueName:values.searchName,	}
						console.log(val)
						this.props.dispatch({type:'manageMember/getGroupMemberListEFF',val})
					}
		      }
		    });
	}
		 //弃用
	disuseState=(memberId)=>{
			let val = {	isUse:'0',memberId:memberId }
			this.props.dispatch({type:'manageMember/groupChildInfoEFF',val})
			this.setState({
				load: !this.state.load
			})
	}
  //启用
  //0是禁用，1是启用
	enAble=(memberId)=>{
			let val = {	isUse:'1',memberId:memberId }
			this.props.dispatch({type:'manageMember/groupChildInfoEFF',val})
			this.setState({
				load: !this.state.load
			})
 }

//新建项目显示
showModalNew = () => {
	   this.setState({visibleNew: true,});
}
//新建项目显示,反显

showModal1 = (val) => {
  let info = val||{};
  console.log(info)
  let oneChecked   = info.memberRole.indexOf('管理')==-1? false          : true;
  let twoChecked   = info.memberRole.indexOf('审批')==-1? false          : true;
  let threeChecked = info.memberRole.indexOf('采购')==-1? false        : true;
  let fourChecked  = info.memberRole.indexOf('查看')==-1? false         : true;

 let                                                    roleAuthoritys=(oneChecked&&twoChecked&&threeChecked&&fourChecked)?'1,2,3,4': 
 (oneChecked&&twoChecked&&threeChecked&&!fourChecked)   ?'1,2,3'                                                                    : 
 (oneChecked&&twoChecked&&!threeChecked&&!fourChecked)  ?'1,2'                                                                      : 
 (oneChecked&&twoChecked&&!threeChecked&&fourChecked)   ?'1,2,4'                                                                    : 
 (oneChecked&&!twoChecked&&!threeChecked&&!fourChecked)?'1'                                                                         : 
 (oneChecked&&!twoChecked&&threeChecked&&fourChecked)   ?'1,3,4'                                                                    : 
 (oneChecked&&!twoChecked&&!threeChecked&&fourChecked)  ?'1,4'                                                                      : 
 (oneChecked&&!twoChecked&&threeChecked&&!fourChecked)  ?'1,3'                                                                      : 
 (!oneChecked&&twoChecked&&threeChecked&&fourChecked)   ?'2,3,4'                                                                    : 
 (!oneChecked&&twoChecked&&threeChecked&&!fourChecked)  ?'2,3'                                                                      : 
 (!oneChecked&&twoChecked&&!threeChecked&&fourChecked)  ?'2,4'                                                                      : 
 (!oneChecked&&twoChecked&&!threeChecked&&!fourChecked)?'2'                                                                         : 
 (!oneChecked&&!twoChecked&&threeChecked&&fourChecked)  ?'3,4'                                                                      : 
 (!oneChecked&&!twoChecked&&!threeChecked&&fourChecked)?'4'                                                                         : 
 (!oneChecked&&!twoChecked&&threeChecked&&!fourChecked)?'3'                                                                         : ''


  // let                                      roleAuthoritys=(oneChecked&&twoChecked&&threeChecked&&fourChecked)?'1,2,3':
  // (oneChecked&&twoChecked&&!threeChecked)  ?'1,2'                                                                    :
  // (oneChecked&&!twoChecked&&!threeChecked)?'1'                                                                       :
  // (!oneChecked&&twoChecked&&threeChecked)  ?'2,3'                                                                    :
  // (!oneChecked&&!twoChecked&&threeChecked)?'3'                                                                       :
  // (!oneChecked&&twoChecked&&!threeChecked)?'2'                                                                       :
                     // ''
  this.setState({
   visible1      : true,
   id            : info.memberId,
   memberId      : info.memberId,
   userId        : info.memberId,
   contactName   : info.memberTruename || "",
   loginName     : info.memberName || "",
   typeOne       : oneChecked?'1'           : '',
   typeTwo       : twoChecked?'2'           : '',
   typeThree     : threeChecked?'3'         : '',
   typeFour      : fourChecked?'4'          : '',
   roleAuthoritys: roleAuthoritys,

  });
}
  //搜索名字
handleSubmitSearch = (e) => {
    e.preventDefault();
		console.log(e)
	 let val = e.target.firstChild.value;
	 console.log(val)
	 if(val==''){
			message.warning('请键入关键字进行搜索！');
		 return
	 }
}
//新建项目下一步提交
ProjectHandleOkNew = (e) => {
	e.preventDefault();
 this.props.form.validateFields(['contactNameNew','loginNameNew',
 'passwordNew','confirmPasswordNew',
 'roleAuthoritysNew',],(err, values) => {
	 console.log(values)
	 if (!err) {
	    	let roleAuthoritys = ''
      if(this.state.typeOne!=''){
           if(this.state.typeTwo!=''&&this.state.typeThree!=''&&this.state.typeFour!=''){
            roleAuthoritys = '1,2,3,4'
           }else if(this.state.typeTwo==''&&this.state.typeThree!=''&&this.state.typeFour!=''){
            roleAuthoritys = '1,3,4'
           }else if(this.state.typeTwo==''&&this.state.typeThree!=''&&this.state.typeFour==''){
            roleAuthoritys = '1,3'
           }else if(this.state.typeTwo==''&&this.state.typeThree==''&&this.state.typeFour!=''){
            roleAuthoritys = '1,4'
           }else if(this.state.typeTwo!=''&&this.state.typeThree==''&&this.state.typeFour!=''){
            roleAuthoritys = '1,2,4'
           }else if(this.state.typeTwo!=''&&this.state.typeThree!=''&&this.state.typeFour==''){
            roleAuthoritys = '1,2,3'
           }else if(this.state.typeTwo!=''&&this.state.typeThree==''&&this.state.typeFour==''){
            roleAuthoritys = '1,2'
           }else{
            roleAuthoritys = '1'
           }
       }else if(this.state.typeOne==''){
           if(this.state.typeTwo!=''&&this.state.typeThree!=''&&this.state.typeFour!=''){
            roleAuthoritys = '2,3,4'
           }else if(this.state.typeTwo!=''&&this.state.typeThree!=''&&this.state.typeFour==''){
            roleAuthoritys = '2,3'
           }else if(this.state.typeTwo!=''&&this.state.typeThree==''&&this.state.typeFour!=''){
            roleAuthoritys = '2,4'
           }else if(this.state.typeTwo!=''&&this.state.typeThree==''&&this.state.typeFour==''){
            roleAuthoritys = '2'
           }else if(this.state.typeTwo==''&&this.state.typeThree!=''&&this.state.typeFour!=''){
            roleAuthoritys = '3,4'
           }else if(this.state.typeTwo==''&&this.state.typeThree!=''&&this.state.typeFour==''){
            roleAuthoritys = '3'
           }else if(this.state.typeTwo==''&&this.state.typeThree==''&&this.state.typeFour!=''){
            roleAuthoritys = '4'
           }else{
            roleAuthoritys = ''
           }
       }
      if(roleAuthoritys==''){
           message.error('请选择权限')
      }else{
         let  val={
          userTrueName: values.contactNameNew,   //联系人名称
          userName    : values.loginNameNew,     //用户名
          password    : values.passwordNew,      //密码
          // power:values.power,//权限
          roleAuthoritys: roleAuthoritys,   //权限
          // memberId      : this.state.memberId
          }
      this.props.dispatch({type:'manageMember/groupChildInfoEFF',val})
      this.props.dispatch({type:'manageMember/objectListListEFF',val:{userId:this.state.userId,}})//项目,反显userId
       this.setState({
        visibleNew: false,
        // visible2  : true,
        // visible3: true,
       });
       this.setTimeLoginName()

      }


	 }
	});
 }



//新建项目下一步提交,反显
 ProjectHandleOk = (e) => {
	e.preventDefault();
	this.props.form.validateFields(['contactName','loginName','roleAuthoritys',],(err, values) => {
	 console.log(values)
	 if (!err) {
	    	let roleAuthoritys = ''
       if(this.state.typeOne!=''){
          if(this.state.typeTwo!=''&&this.state.typeThree!=''&&this.state.typeFour!=''){
           roleAuthoritys = '1,2,3,4'
          }else if(this.state.typeTwo==''&&this.state.typeThree!=''&&this.state.typeFour!=''){
           roleAuthoritys = '1,3,4'
          }else if(this.state.typeTwo==''&&this.state.typeThree!=''&&this.state.typeFour==''){
           roleAuthoritys = '1,3'
          }else if(this.state.typeTwo==''&&this.state.typeThree==''&&this.state.typeFour!=''){
           roleAuthoritys = '1,4'
          }else if(this.state.typeTwo!=''&&this.state.typeThree==''&&this.state.typeFour!=''){
           roleAuthoritys = '1,2,4'
          }else if(this.state.typeTwo!=''&&this.state.typeThree!=''&&this.state.typeFour==''){
           roleAuthoritys = '1,2,3'
          }else if(this.state.typeTwo!=''&&this.state.typeThree==''&&this.state.typeFour==''){
           roleAuthoritys = '1,2'
          }else{
           roleAuthoritys = '1'
          }
       }else if(this.state.typeOne==''){
           if(this.state.typeTwo!=''&&this.state.typeThree!=''&&this.state.typeFour!=''){
            roleAuthoritys = '2,3,4'
           }else if(this.state.typeTwo!=''&&this.state.typeThree!=''&&this.state.typeFour==''){
            roleAuthoritys = '2,3'
           }else if(this.state.typeTwo!=''&&this.state.typeThree==''&&this.state.typeFour!=''){
            roleAuthoritys = '2,4'
           }else if(this.state.typeTwo!=''&&this.state.typeThree==''&&this.state.typeFour==''){
            roleAuthoritys = '2'
           }else if(this.state.typeTwo==''&&this.state.typeThree!=''&&this.state.typeFour!=''){
            roleAuthoritys = '3,4'
           }else if(this.state.typeTwo==''&&this.state.typeThree!=''&&this.state.typeFour==''){
            roleAuthoritys = '3'
           }else if(this.state.typeTwo==''&&this.state.typeThree==''&&this.state.typeFour!=''){
            roleAuthoritys = '4'
           }else{
            roleAuthoritys = ''
           }
       }
      if(roleAuthoritys==''){
           message.error('请选择权限')
      }else{
         let  val={
          userTrueName: values.contactName,   //联系人名称
          userName    : values.loginName,     //用户名
          // password:values.password,//密码
          // power:values.power,//权限
          roleAuthoritys: roleAuthoritys,        //权限
          memberId      : this.state.memberId,
         }
      this.props.dispatch({type:'manageMember/groupChildInfoEFF',val})

      // this.props.dispatch({type:'manageMember/groupApprovalsListEFF',val:{userId:this.state.userId,}})//审批流
       //调取项目列表
      this.props.dispatch({type:'manageMember/objectListListEFF',val:{userId:this.state.userId,}})//项目
       this.setState({
        visible1: false,
        // visible2: true,//去掉审批流
        // visible3: true,   //项目
       });
       this.setTimeLoginName()
      }
	 }
	});
 }

   setTimeLoginName(){
      var iTime=setInterval(()=>{
       console.log(this.props.manageMember.loginResult)
        if(this.props.manageMember.loginResult!='2')
          this.setState({
           visible3: true,   //项目关闭
          })

      },1000)
        setInterval(()=>{
            clearInterval(iTime);
        },2000)
   }

 	 //新建项目取消
   ProjectHandleCancelNew = (e) => {
    this.setState({ visibleNew: false });
   }
	 //新建项目取消,反显
 ProjectHandleCancel = (e) => {
	 this.setState({ visible1: false });
 }
 //审批流范围
 handleUserOkApproval = (getGroupMemberListData) => {
		let arrMember = []
		getGroupMemberListData.map((val,index)=>{
			 if(val.checked){
				arrMember.push(val.id)
			 }
		})
		console.log(arrMember)
		  this.props.dispatch({type:'manageMember/groupChildInfoEFF',val:{approvalIds:arrMember.join(','),id:this.state.id,}})
    this.props.dispatch({type:'manageMember/objectListListEFF',val:{userId:this.state.userId,}})//项目
  this.setState({
			visible2: false,
			visible3: true,
		});
 }
  //选中项目
  handleUserOkProject = (objectListListData) => {
   let arrMember = []
   objectListListData.map((val,index)=>{
     if(val.checked){ arrMember.push(val.id) }
   })

   if(this.state.id==''){//新建子账户
      this.props.dispatch({type:'manageMember/groupChildInfoEFF',val:{projectIds:arrMember.join(','),prevId:'prevId',}})
      this.props.dispatch({type:'manageMember/fundsListListEFF',val:{type:2}})//经费
   }else{
      //编辑的时候
      this.props.dispatch({type:'manageMember/groupChildInfoEFF',val:{projectIds:arrMember.join(','),memberId:this.state.memberId}})
      this.props.dispatch({type:'manageMember/fundsListListEFF',val:{userId:this.state.userId,type:2}})//经费
     }
   this.setState({
    visible3: false,
    visible4: true,
   });
  }
  //选中经费
  handleUserOkFund = (fundsListListData) => {
    let arrMember = []
    fundsListListData.map((val,index)=>{
      if(val.checked){ arrMember.push(val.id)}
    })

    if(this.state.id==''){//新建
        this.props.dispatch({type:'manageMember/groupChildInfoEFF',val:{type:2,fundsIds:arrMember.join(','), prevId:'prevId',}})
     }else{
        //编辑的时候
        this.props.dispatch({type:'manageMember/groupChildInfoEFF',val:{type:2,fundsIds:arrMember.join(','), memberId:this.state.memberId,}})
     }

    this.setState({ visible4: false});
   }
 handleUserCancelApproval = () => {
  this.setState({ visible2: false });
 }
 handleUserCancelProject = () => {
  this.setState({ visible3: false });
 }
 handleUserCancelFund = () => {
  this.setState({ visible4: false });
 }
 //全选
 onCheckAllChange = (e) => {
  this.props.dispatch({type:'manageMember/checkAll', preload: e.target.checked})
 }
//单选 选中商品
onChangeBox = (data, val, e) => {
	let value = {
	approvalsListData: data,
	checkedGoods     : val,
	checked          : e.target.checked
	}
	this.props.dispatch({type:'manageMember/checkGoods', value})
}
//全选项目
onCheckAllChange2 = (e) => {
	this.props.dispatch({type:'manageMember/checkAll2', preload: e.target.checked})
}
//单选 选中项目
onChangeBox2 = (data, val, e) => {
	let value = {
	objectListListData: data,
	checkedGoods      : val,
	checked           : e.target.checked
	}
	this.props.dispatch({type:'manageMember/checkGoods2', value})
}
//全选经费
onCheckAllChange3 = (e) => {
	this.props.dispatch({type:'manageMember/checkAll3', preload: e.target.checked})
}
//单选 选中经费
onChangeBox3 = (data, val, e) => {
	let value = {
	fundsListListData: data,
	checkedGoods     : val,
	checked          : e.target.checked
	}
	this.props.dispatch({type:'manageMember/checkGoods3', value})
}
	//分页
	onChangePage = (pageNo) => {
		console.log(pageNo)
	 this.props.dispatch({type: 'manageMember/getGroupMemberListEFF', val: {pageNo: pageNo}});
	 this.setState({
			update: true,
	 })
	 window.scrollTo(0, 0)
 }
goPage = () => {
		let maxPage = Math.ceil(this.props.manageMember.count / 10)
		let pageNo  = this.refs.page.getElementsByTagName("input")[0].value;
		    pageNo  = pageNo > maxPage ? maxPage : pageNo
		if (!!pageNo) {
		 this.setState({
			update: true
		 }, () => this.props.dispatch({
			type: 'manageMember/getGroupMemberListEFF',
			val : {pageNo: pageNo,}
		 }))
		 window.scrollTo(0, 0)
		 this.refs.page.getElementsByTagName("input")[0].value = ""
		}
}
 //新建用户判断用户名唯一性
 useNameVerificatNew = () => {
  this.props.form.validateFieldsAndScroll(['loginNameNew'], (err, values) => {
   if (!err) {
    console.log(values)
    getCheckLoginName({loginName:values.loginNameNew}).then(r => {
     if (r.result == 1) {
      message.success('用户名验证成功', 1.5);
      console.log(values)
     } else {
      message.error(r.msg, 1.5);
     }
    })
   }
  })
 }
  //判断用户名唯一性
  useNameVerificat = () => {
   this.props.form.validateFieldsAndScroll(['loginName'], (err, values) => {
    if (!err) {
     console.log(values)
     getCheckLoginName(values).then(r => {
      if (r.result == 1) {
       message.success('用户名验证成功', 1.5);
       console.log(values)
      } else {
       message.error(r.msg, 1.5);
      }
     })
    }
   })
  }
  //判断用户密码是否一样
  checkPasswordNew = (rule, value, callback) => {
   const form = this.props.form;
   if (value && value !== form.getFieldValue('passwordNew')) {
    callback('两次密码不一样!');
   } else {
    callback();
   }
  }
 //判断用户密码是否一样,回显
 checkPassword = (rule, value, callback) => {
  const form = this.props.form;
  if (value && value !== form.getFieldValue('password')) {
   callback('两次密码不一样!');
  } else {
   callback();
  }
 }
  onChangePowerOne=(val)=>{
   if(this.state.typeOne==''){
    this.setState({typeOne:'1',})
   }else{
    this.setState({typeOne:'',})
   }
  }
  onChangePowerTwo=(val)=>{
   if(this.state.typeTwo==''){
    this.setState({typeTwo:'2',})
   }else{
    this.setState({typeTwo:'',})
   }
  }
  onChangePowerThree=(val)=>{
  if(this.state.typeThree==''){
   this.setState({typeThree:'3',})
  }else{
   this.setState({typeThree:'',})
  }
  }
  onChangePowerFour=(val)=>{
   if(this.state.typeFour==''){
    this.setState({typeFour:'4',})
   }else{
    this.setState({typeFour:'',})
   }
   }


 //审批流搜索
 handleApprovalRange = (e) => {
  e.preventDefault();
  this.props.form.validateFields(['ApprovalRange'], (err, values) => {
   if (!err) {
    if (values.ApprovalRange == '' || values.ApprovalRange == undefined) {
     // message.error('请输入搜索内容', 1.5);
     this.props.dispatch({type: 'manageMember/groupApprovalsListEFF',})
    } else {
     let val = {approvalName: values.ApprovalRange, }
     this.props.dispatch({type: 'manageMember/groupApprovalsListEFF', val})
    }
   }
   this.setState({
    numApproval: this.state.numApproval + 1
   })
   // this.props.form.resetFields()
  });
 }
  //项目搜索
  handleProjectRange = (e) => {
   e.preventDefault();
   this.props.form.validateFields(['ProjectRange'], (err, values) => {
    if (!err) {
     if (values.ProjectRange == '' || values.ProjectRange == undefined) {
      // message.error('请输入搜索内容', 1.5);
      this.props.dispatch({type: 'manageMember/objectListListEFF',})
     } else {
      let val = {projectName: values.ProjectRange, }
      this.props.dispatch({type: 'manageMember/objectListListEFF', val})
     }
    }
    this.setState({
     numProject: this.state.numProject + 1
    })
    this.props.form.resetFields()
   });
  }

  //经费搜索
    handleFundRange = (e) => {
     e.preventDefault();
     this.props.form.validateFields(['FundRange'], (err, values) => {
      if (!err) {
       if (values.FundRange == '' || values.FundRange == undefined) {
        // message.error('请输入搜索内容', 1.5);
        this.props.dispatch({type: 'manageMember/fundsListListEFF', })
       } else {
        let val = {fundName: values.FundRange,type:2 }
        this.props.dispatch({type: 'manageMember/fundsListListEFF', val})
       }
      }
      this.setState({
       numFund: this.state.numFund + 1
      })
      this.props.form.resetFields()
     });
    }
    importManage=()=>{

    }
     //导入成员信息
    changeManage = (info) => {
     this.setState({ loading : true,fileList: {},})
     if (info.file.status === 'done') {
         this.setState({loading:false})
         if (info.file.response.result == 0) {
           //失败的情况
             message.error(info.file.response.msg)
           return
         } else if(info.file.response.result == 1) {
             let arr = info.file.response.data;
             let msg = info.file.response.msg||'';
             message.success(msg,3,()=>{});
             this.props.dispatch({ type:'manageMember/getGroupMemberListEFF' });
         }
     }else if(info.file.status === "error"){
      this.setState({loading:false})
      message.error("上传失败")
     }
   }
       //导出下载excel
       exportFavoritesExcelList = () => {

        exportGroupMemberExcelAPI({

        }).then(r=>{
          if(r.result==1){
            console.log(r.filePath)
            let url                  = `${IMAGE_DOMAIN}${r.filePath}`;
                window.location.href = url
          }else {
            message.error(r.msg,1.5);
          }

        })

   }

  render() {
    const { getFieldDecorator }                                                                                                                   = this.props.form
    const {loginResult, getGroupMemberListData,checkAll,checkAll2,checkAll3,count,pageNo,approvalsListData,objectListListData,fundsListListData } = this.props.manageMember

  let   {numApproval,numProject,numFund} = this.state;
  const formItemLayout                   = {
			labelCol: {
			 sm: { span: 8 },
			},
			wrapperCol: {
			 sm: { span: 12 },
			},
		 }
		 const formItemLayout2 = {
			labelCol: {
			 sm: { span: 10 },
			},
			wrapperCol: {
			 sm: { span: 14},
			},
		 }
    return (
      <div>
        <Search></Search>
        <Navigation preson={true}>
          <div className={manageMember}>
             <div className={my_account_dynamic_Topimg}></div>
            {/* <BodyHeadImg headImg={{url:'/upload/img/lmadv/1508217294561.png',id:'234'}}/> */}
            <Breadcrumb separator=">" className='security_nav_bar'>
              <Breadcrumb.Item  href="/presonAccunt/myAccount">我的账户</Breadcrumb.Item>
              <Breadcrumb.Item href="/group/mianManage">我的群组</Breadcrumb.Item>
              <Breadcrumb.Item href="/group/manage-member" style={{fontSize:'16px', fontWeight:'bold' }}>群组成员管理</Breadcrumb.Item>
            </Breadcrumb>
            <div className="filter_bar">
               <Form onSubmit={this.searchName}  layout="inline">
                <FormItem labelCol={{ span: 14 }}>
                 {getFieldDecorator('searchName')(
                  <Input placeholder="联系人名称" />
                 )}
                </FormItem>
                <FormItem labelCol={{ span: 4 }}>
                 <Button type="primary" htmlType="submit" ghost>搜索</Button>
                </FormItem>
                <FormItem labelCol={{ span: 4 }}>
                 <span style={{backgroundColor: '#37b5aa',}} className="top-btn" onClick={()=>this.showModalNew()}>新建子账户</span>
                </FormItem>
                <FormItem labelCol={{ span: 4 }}>
                 <span  onClick={()=>this.importManage()}></span>
                </FormItem>
               </Form>
               <span
                   onClick = {()=>this.exportFavoritesExcelList()}
                   style   = {{display:'inline-block',padding:'5px',background:'#108ee9',width:'105px',color:'#fff',borderRadius:'5px',cursor:'pointer',position:'absolute',right:'147px',top:'0' }}>
                  导出成员模板
               </span>
               <Form onSubmit={this.handleSubmitExport} style={{display:'inline-block',margin:'0 10px',cursor:'pointer',position:'absolute',right:'0',top:'0'}}>
                   <FormItem >
                      {getFieldDecorator('fileNewName', {
                          rules: [{ message: '选择文件'}]
                        })(
                          <div className='allFiles'>
                             <Upload
                               name           = 'files'
                               showUploadList = {false}
                               action         = '/reagent-front/groupApi/importGroupMemberExcel'
                               onChange       = {(info) => this.changeManage(info)}
                              >
                              <Button  type="primary"><Icon type="folder-add" />导入成员信息</Button>
                             </Upload>

                           </div>
                       )}
                   </FormItem>
                </Form>
            </div>
            <div className="orderList_content">
              <table className="table">
                <tbody>
                  <tr>
                    <th>联系人姓名</th>
                    <th>用户名</th>
                    <th>联系电话</th>
                    <th>联系邮箱</th>
                    <th>账户权限</th>
                    <th>最近登录时间</th>
                    <th>新建时间</th>
                    <th>操作</th>
                    </tr>
                     {
                      getGroupMemberListData && getGroupMemberListData.length>0?
                      getGroupMemberListData.map((val,index)=>{
                       return(
                       <tr key={index}>
                       <td>{val.memberTruename}</td>
                       <td>{val.memberName}</td>
                       <td>{val.memberMobile}</td>
                       <td>{val.memberEmail}</td>
                       <td>{val.memberRole}</td>
                       <td>{val.memberOldLoginTimestr}</td>
                       <td>{val.createTimeStr}</td>
                       {val.memberState=='1'?
                          <td>
                          <span style={{color: '#3a98cc',cursor: 'pointer'}}  onClick={()=>this.showModal1(val)} >编辑</span>
                          <span style={{color: 'orange', marginLeft: '5px',cursor: 'pointer'}} onClick={()=>this.disuseState(val.memberId)}>弃用</span>
                         </td>
                         : 
                         <td>
                          <span style={{color: '#3a98cc',cursor: 'pointer'}}  onClick={()=>this.showModal1(val)} >编辑</span>
                          <span style={{color: 'orange', marginLeft: '5px',cursor: 'pointer'}} onClick={()=>this.enAble(val.memberId)}>启用</span>
                         </td>

                       }
                      </tr>
                       )
                     })
                     :                                                                                                                                   <tr><td></td></tr>
                    }
                </tbody>
              </table>
            </div>
		        	<div className="cantent_paging" style={{width: '94%'}}   ref="page" key={pageNo}>
                <Pagination
                showQuickJumper
                defaultCurrent  = {1}
                defaultPageSize = {10}
                current         = {pageNo}
                total           = {getGroupMemberListData&&getGroupMemberListData.length>0? count: 1}
                onChange        = {this.onChangePage} />
                <Button onClick={this.goPage} style={{position:'absolute',right:'0'}}>确定</Button>
            </div>
      <Modal
								visible   = {this.state.visibleNew}
								title     = "创建子账号"
								closable  = {false}
								footer    = {null}
								className = 'fund_modal'
								>
								<Form onSubmit={this.ProjectHandleOkNew}>
          <FormItem
            {...formItemLayout}
           label = "联系人名称："
          >
           {getFieldDecorator('contactNameNew',{
             rules: [{	required: true, message: '请输入联系人名称!', }],
            } )(
                <Input />
           )}
          </FormItem>
								 	<div>
            <FormItem
            {...formItemLayout2}
            label = "用户名："
            style = {{display:'inline-block',width:'80%'}}
            >
            {getFieldDecorator('loginNameNew', {
             rules: [{	required: true, message: '请输入用户名!', }],
            })(
              <Input />
            )}
            </FormItem>
										 <span onClick={this.useNameVerificatNew} style={{display:'inline-block',background:'#108ee9',color:'#fff',marginLeft:'4px',padding:'6px',borderRadius:'10%',cursor:'pointer'}}>验证用户名</span>
									 </div>
          <FormItem
           {...formItemLayout}
           label = "初始密码："
           >
           {getFieldDecorator('passwordNew', {})(
             <p>123456</p>
           )}
									</FormItem>
									<FormItem
           {...formItemLayout}
           label = "确认密码："
           >
           {getFieldDecorator('confirmPasswordNew', {})(
               <p>123456</p>
           )}
									</FormItem>
          {/* <FormItem
           {...formItemLayout}
           label = "初始密码："
           >
           {getFieldDecorator('passwordNew', {
            rules: [{
            required: true, message: '字母+数字，8-15个字符之间', min: 8, max: 15,
            }],
           })(
            <Input />
           )}
								 	</FormItem>
									 <FormItem
           {...formItemLayout}
           label = "确认密码："
           >
           {getFieldDecorator('confirmPasswordNew', {
            rules: [{
            required: true, message: '字母+数字，8-15个字符之间', min: 8, max: 15,
            },{validator:this.checkPasswordNew}],
           })(
            <Input />
           )}
								 	</FormItem> */}
								 	<FormItem
            {...formItemLayout}
            label = "账户权限："
            >
            {  getFieldDecorator('roleAuthoritysNew', {
             rules: [{required: true,}],
            })(
             <div>
              <Checkbox value="1" onClick={()=>this.onChangePowerOne(1)}>管理员权限</Checkbox>
              <Checkbox value="2" onClick={()=>this.onChangePowerTwo(2)}>审批权限</Checkbox>
              <Checkbox value="3" onClick={()=>this.onChangePowerThree(3)}>采购权限</Checkbox>
             <Checkbox  value="4" onClick={()=>this.onChangePowerFour(4)}>查询权限</Checkbox>
             </div>
            )}
									 </FormItem>

          <FormItem style={{textAlign:'center'}}>
            <Button key="submit" htmlType="submit" type="primary" loading={this.state.loading} style={{marginRight:'50px'}}>下一步</Button>
            <Button key="back" onClick={this.ProjectHandleCancelNew} className='cancel'>关闭</Button>
          </FormItem>
								</Form>
						</Modal>
      {/* 编辑 */}
						<Modal
								visible   = {this.state.visible1}
								title     = "创建子账号"
								closable  = {false}
								footer    = {null}
								className = 'fund_modal'
								>
								<Form onSubmit={this.ProjectHandleOk}>
								 <FormItem
								  	{...formItemLayout}
									 label = "联系人名称："
									>
									{getFieldDecorator('contactName', {
               rules       : [{required: true,  message: '请输入联系人名称!', }],
               initialValue: this.state.contactName
         	})(
										<Input />
									)}
									</FormItem>
									<div>
										<FormItem
										{...formItemLayout2}
										label = "用户名："
										style = {{display:'inline-block',width:'80%'}}
										>
										{getFieldDecorator('loginName', {
										  	rules       : [{equired: true,}],
										  	initialValue: this.state.loginName
										})(
												<Input />
										)}
										</FormItem>
										<span onClick={this.useNameVerificat} style={{display:'inline-block',background:'#108ee9',color:'#fff',marginLeft:'4px',padding:'6px',borderRadius:'10%',cursor:'pointer'}}>验证用户名</span>
									</div>
									<FormItem
           {...formItemLayout}
           label = "初始密码："
           >
           {getFieldDecorator('password', {})(
             <p>123456</p>
           )}
									</FormItem>
									<FormItem
           {...formItemLayout}
           label = "确认密码："
           >
           {getFieldDecorator('confirmPassword', {})(
               <p>123456</p>
           )}
									</FormItem>
									<FormItem
									{...formItemLayout}
									label = "账户权限："
									>
									{getFieldDecorator('roleAuthoritys', {
          rules       : [{required: true,}],
          initialValue: this.state.roleAuthoritys
									})(
										<div>
											<Checkbox  checked={this.state.typeOne=='1'?true:false} value="1" onClick={()=>this.onChangePowerOne(1)}>管理员权限</Checkbox>
											<Checkbox  checked={this.state.typeTwo=='2'?true:false}  value="2" onClick={()=>this.onChangePowerTwo(2)}>审批权限</Checkbox>
											<Checkbox  checked={this.state.typeThree=='3'?true:false}   value="3" onClick={()=>this.onChangePowerThree(3)}>采购权限</Checkbox>
           <Checkbox  checked={this.state.typeFour=='4'?true:false}   value="3" onClick={()=>this.onChangePowerFour(4)}>查询权限</Checkbox>
										</div>
									)}
									</FormItem>

									<FormItem style={{textAlign:'center'}}>
								  	<Button key="submit" htmlType="submit" type="primary" loading={this.state.loading} style={{marginRight:'50px'}}>下一步</Button>
									  <Button key="back" onClick={this.ProjectHandleCancel} className='cancel'>关闭</Button>
									</FormItem>
								</Form>
						</Modal>

						 <Modal
									visible  = {this.state.visible2}
									closable = {false}
									width    = {640}
									okText   = "完成"
									onOk     = {()=>this.handleUserOkApproval(approvalsListData)}
									onCancel = {this.handleUserCancelApproval}
									footer   = {<div style={{textAlign:'center'}}>
								            <Button key="submit2" onClick={()=>this.handleUserOkApproval(approvalsListData)}>下一步</Button>
								            <Button key="back"  onClick={this.handleUserCancelApproval}>关闭</Button>,
                          </div>}
						 >
									<div style={{textAlign:'center', fontSize: '16px', paddingBottom: '20px', borderBottom: '1px solid #e4e4e4', marginBottom: '20px'}}>
										设置审批流
									</div>
									<div  style={{textAlign:'center',marginBottom:'15px'}}>
								   	<span>
											<Checkbox
												onChange = {this.onCheckAllChange}
												checked  = {checkAll}

											>全选</Checkbox>
									</span>
									 	 <Form onSubmit={(e) => this.handleApprovalRange(e)} style={{display:'inline-block'}}>
										  <FormItem labelCol={{span: 10}} style={{display: 'inline-block'}}>
             {getFieldDecorator('ApprovalRange', {
             })(
               <Input key={numApproval} style={{ width:'270px',marginRight:'10px' }} />
             )}
            </FormItem>
             {/* <Input style={{ width:'270px',marginRight:'10px' }}></Input> */}
											  <Button  htmlType="submit"  style={{color: '#fff', borderRadius: '4px', textAlign: 'center', padding: '8px 12px', background: '#3a98cc',}}>搜索</Button>
            </Form>
									</div>
									{
										approvalsListData&&approvalsListData.map((val,index)=>{
											     return(
												<Checkbox key={index} checked={val.checked} onChange={(e) => this.onChangeBox(approvalsListData, val, e)} >{val.approvalName}</Checkbox>
											)
										 })
									}
						 </Modal>
						 <Modal
									visible  = {this.state.visible3}
									closable = {false}
									width    = {640}
									okText   = "完成"
									onOk     = {()=>this.handleUserOkProject(objectListListData)}
									onCancel = {this.handleUserCancelProject}
									footer   = {<div style={{textAlign:'center'}}>
								            <Button key="submit2" onClick={()=>this.handleUserOkProject(objectListListData)}>下一步</Button>
								            <Button key="back"  onClick={this.handleUserCancelProject}>关闭</Button>,
                          </div>}
						 >
									<div style={{textAlign:'center', fontSize: '16px', paddingBottom: '20px', borderBottom: '1px solid #e4e4e4', marginBottom: '20px'}}>
										设置群组项目
									</div>
									<div  style={{textAlign:'center',marginBottom:'15px'}}>
								   	<span>
											<Checkbox
												onChange = {this.onCheckAllChange2}
												checked  = {checkAll2}
											>全选</Checkbox>
									</span>
									 	 <Form onSubmit={(e) => this.handleProjectRange(e)} style={{display:'inline-block'}}>
            <FormItem labelCol={{span: 10}} style={{display: 'inline-block'}}>
             {getFieldDecorator('ProjectRange', {})(
               <Input key={numProject} style={{ width:'270px',marginRight:'10px' }} />
             )}
            </FormItem>
             {/* <Input style={{ width:'270px',marginRight:'10px' }}></Input> */}
											  <Button  htmlType="submit"  style={{color: '#fff', borderRadius: '4px', textAlign: 'center', padding: '8px 12px', background: '#3a98cc',}}>搜索</Button>
                                         </Form>
									</div>
									{
										objectListListData&&objectListListData.map((val,index)=>{
											     return(
												<Checkbox key={index} checked={val.checked} onChange={(e) => this.onChangeBox2(objectListListData, val, e)} >{val.projectName}</Checkbox>
											)
										 })
									}
						 </Modal>
						 <Modal
									visible  = {this.state.visible4}
									closable = {false}
									width    = {640}
									okText   = "完成"
									onOk     = {()=>this.handleUserOkFund(fundsListListData)}
									onCancel = {this.handleUserCancelFund}
									footer   = {<div style={{textAlign:'center'}}>
								            <Button key="submit2" onClick={()=>this.handleUserOkFund(fundsListListData)}>下一步</Button>
								            <Button key="back"  onClick={this.handleUserCancelFund}>关闭</Button>,
                          </div>}
						 >
									<div style={{textAlign:'center', fontSize: '16px', paddingBottom: '20px', borderBottom: '1px solid #e4e4e4', marginBottom: '20px'}}>
										设置群组经费
									</div>
									<div  style={{textAlign:'center',marginBottom:'15px'}}>
								   	<span>
											<Checkbox
												onChange = {this.onCheckAllChange3}
												checked  = {checkAll3}

											>全选</Checkbox>
									</span>
									 	 <Form onSubmit={(e) => this.handleFundRange(e)} style={{display:'inline-block'}}>
            <FormItem labelCol={{span: 10}} style={{display: 'inline-block'}}>
              {getFieldDecorator('FundRange', {})(
                <Input key={numFund} style={{ width:'270px',marginRight:'10px' }}/>
              )}
             </FormItem>
             {/* <Input style={{ width:'270px',marginRight:'10px' }}></Input> */}
											  <Button  htmlType="submit"  style={{color: '#fff', borderRadius: '4px', textAlign: 'center', padding: '8px 12px', background: '#3a98cc',}}>搜索</Button>
                                         </Form>
									</div>
									{
										fundsListListData&&fundsListListData.map((val,index)=>{
											     return(
												<Checkbox key={index} checked={val.checked} onChange={(e) => this.onChangeBox3(fundsListListData, val, e)} >{val.fundsName}</Checkbox>
											)
										 })
									}
						 </Modal>
          </div>
        </Navigation>
      </div>
    )
  }
}

export default connect(({ manageMember }) => ({ manageMember }), (dispatch,own) => { return { dispatch,own } })(Form.create()(ManageMember))
