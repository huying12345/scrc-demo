import React, {Component} from 'react'
import {BodyHeadImg} from '../../components/Advertising/Advertising'
import {Breadcrumb, Checkbox, Row, Col, Pagination, Input, Button, Form, Modal, message,Upload,Icon} from 'antd'
import {Link} from 'dva/router'
import {connect} from 'dva'
import {fav_list} from './ManageFav.less'
import Img from "../../components/Img/Img"
import Search from '../../components/Search/Search'
import Navigation from '../../components/Navigation/Navigation'
import ManageFavOperaFloor from './ManageFavOperaFloor'
import {exportFavoritesExceApi} from './api'
import {IMAGE_DOMAIN} from "../../utils/common"

const FormItem = Form.Item;

class groupFavOpear extends Component {
 state = {
  value    : 0,
  checkAll : false,
  moveToTop: false,
  visible1 : false,
  fileList : {},
  loading  : false,
 }
 handleSubmit = (e) => {
  e.preventDefault();
  this.props.form.validateFields((err, values) => {
   if (!err) {
       console.log(values)
    this.props.dispatch({type: "groupFavOpear/searchFavGoods", values})
   }
  });
 }

 // 选择商品
 checkGoods = (checkedGoods, checked) => {
  let value = {
   checkedGoods,
   checked
  }
  this.props.dispatch({type: 'groupFavOpear/checkGoodsEFF', payload: value})
 }
 delGoods = (goodsId) => {
  const value = {
   goodsId: goodsId
  }
  console.log(value)
  Modal.confirm({
   title  : '您确定要删除吗?',
   content: '',
   onOk   : () => {
    console.log(value)
    this.props.dispatch({type: 'groupFavOpear/deleteGoodsFavoritesEFF', payload: value});
   },
   onCancel() {
    console.log('取消');
   },
  });
 }
 //删除选中的商品
 delSelGoods = () => {
  let goodsId = [];
  this.props.groupFavOpear.goodsFavoritesList.forEach(goods => {
   if (goods.checked) {
    goodsId.push(goods.goodsId);
   }
  })
  if (goodsId.length == 0) {
   message.info('请先选择商品', 1)
   return;
  }
  Modal.confirm({
   title     : '提示',
   content   : '确定删除吗',
   okText    : '确定',
   cancelText: '取消',
   onOk      : () => {
    let value = {
     goodsId: goodsId.join(',')
    }
    this.props.dispatch({type: 'groupFavOpear/deleteGoodsFavoritesEFF', payload: value});
   },
   maskClosable: true
  });

 }
 //全选
 checkAll = (checked) => {
  this.props.dispatch({type: 'groupFavOpear/checkAllEFF', payload: checked});
 }
 addCart = (goodsId, goodsPrice,goodsMaterial) => {
  let val = {
   goodsId      : goodsId,
   count        : 1,
   goodsPrice   : goodsPrice,
   saveType     : 0,
   goodsMaterial: goodsMaterial,
  }
  console.log(val)
  this.props.dispatch({type: 'groupFavOpear/addCart', val});
 }
 handleAddCarts = () => {
  let purTemplateItems = [];
  this.props.groupFavOpear.goodsFavoritesList.forEach(function (v, index, array) {
   if (v.checked) {
    if(v.goodsStorePrice > 0 && v.isControlInfo == 1){
     purTemplateItems.push({goodsId: v.goodsId, newGoodsPrice: v.goodsStorePrice, goodsNum: 1, goodsSource: 0,goodsMaterial:v.goodsMaterial})
    }
   }
  });
  if (purTemplateItems.length == 0) {
   message.info('请先选择商品', 1)
   return;
  }
  this.props.dispatch({
   type: 'groupFavOpear/getAddCartBachEFF',
   arr : purTemplateItems
  })

  if (this.props.initState) {
   this.setState({
    dataSource: []
   })
  }
 }

 getScroollHieght = () => {
  let winH = document.documentElement.clientHeight || document.body.clientHeight;
  // let documentH = document.documentElement.scrollHeight || document.body.scrollHeight;
  let dataTableH   = this.refs.favListTab.offsetHeight;
  let ElescrollTop = document.body.scrollTop || document.documentElement.scrollTop;
  if (dataTableH > winH && ElescrollTop > 485) {
   this.setState({
    moveToTop: true
   })
  } else {
   this.setState({
    moveToTop: false
   })
  }
 }
 componentDidMount = () => {
  document.addEventListener("scroll", this.getScroollHieght, false);
 }
 componentWillUnmount = () => {
  document.removeEventListener("scroll", this.getScroollHieght, false)
 }


  //显示
  showModal1 = () => {
   this.setState({ visible1  : true,});
  }
  handleChange = (info) => {
    this.setState({ loading : true,fileList: {},})
    if (info.file.status === 'done') {
        this.setState({loading:false})
        if (info.file.response.result == 0) {
          //失败的情况
            message.error(info.file.response.msg)
          return
        } else if(info.file.response.result == 1) {
            //上传成功的情况
            // message.success(info.file.response.msg)
            // console.log("获取的数据"+info.file.response.data)
            let arr = info.file.response.data;
            let msg = info.file.response.msg||'';

            message.success(msg,1.5,()=>{});
            // this.props.dispatch({ type:'QuickOrder/addSelectData', arr });
        }
    }else if(info.file.status === "error"){
     this.setState({loading:false})
     message.error("上传失败")
    }
  }
   //下载上传模板
   exportFavoritesExcel = () => {
    exportFavoritesExceApi({
        type: 0,
     }).then(r=>{
       if(r.result==1){
         console.log(r.filePath)
         let url                  = `${IMAGE_DOMAIN}${r.filePath}`;
             window.location.href = url
       }else {
         message.error(r.msg,1.5);
       }

     })
  }
   //删除选中的商品
 // delSelGoods = () => {
 //  let goodsId = [];
 //  this.props.groupFavOpear.goodsFavoritesList.forEach(goods => {
 //   if (goods.checked) {
 //    goodsId.push(goods.goodsId);
 //   }
 //  })
 //  if (goodsId.length == 0) {
 //   message.info('请先选择商品', 1)
 //   return;
 //  }

 // }
     //导出收藏夹目录
     exportFavoritesExcelList = () => {
         // let goodsErpCodes = [];
         //  this.props.groupFavOpear.goodsFavoritesList.forEach(goods => {
         //   if (goods.checked) {
         //    goodsErpCodes.push(goods.goodsErpCode);
         //   }
         //  })
         //  if (goodsErpCodes.length == 0) {
         //   message.info('请先选择商品', 1)
         //   return;
         //  }
          // console.log(goodsErpCodes)
          let GoodsEntityArr = [];
         this.props.groupFavOpear.goodsFavoritesList.forEach(goods => {
          let GoodsEntity = {};
          if (goods.checked) {
            GoodsEntity.goodsErpCode  = goods.goodsErpCode&& goods.goodsErpCode!=''? goods.goodsErpCode:'';
            GoodsEntity.goodsMaterial = goods.goodsMaterial&&goods.goodsMaterial!=''? goods.goodsMaterial:'';
            GoodsEntityArr.push(GoodsEntity);
          }
         })

         if (GoodsEntityArr.length == 0) {
          message.info('请先选择商品', 1)
          return;
         }
         // let GoodsEntityArr2 = JSON.stringify(GoodsEntityArr);

        exportFavoritesExceApi({
          type       : 1,
          GoodsEntity: JSON.stringify(GoodsEntityArr)
          // goodsNos     : goodsMaterial.join(','),
          // goodsErpCodes: goodsErpCodes.join(','),
         }).then(r=>{
           if(r.result==1){
             console.log(r.filePath)
             let url                  = `${IMAGE_DOMAIN}${r.filePath}`;
                 window.location.href = url
           }else {
             message.error(r.msg,1.5);
           }

         })

    }

 render() {
  const {goodsFavoritesList, checkAll,role,getMyGroupInfoDate} = this.props.groupFavOpear
  const {getFieldDecorator}                                    = this.props.form;
  // console.log(getMyGroupInfoDate)
  // const _this          = this;
  const formItemLayout = {
    labelCol: {
     sm: { span: 7 },
    },
    wrapperCol: {
     sm: { span: 16 },
    },
 }
  return (
   <div>
    <Search></Search>
    <Navigation preson={true}>
     <div className={fav_list}>
     <div className="my_account_dynamic_Topimg"></div>
      <Breadcrumb separator=">" className='security_nav_bar'>
       <Breadcrumb.Item href="/presonAccunt/myAccount">我的账户</Breadcrumb.Item>
       <Breadcrumb.Item href="/group/mianManage" >我的群组</Breadcrumb.Item>
       <Breadcrumb.Item href="/group/manageFav" style={{fontSize:'16px', fontWeight:'bold' }}>群组收藏夹</Breadcrumb.Item>
      </Breadcrumb>

          <div>
           <div>
              <span
                onClick = {()=>this.exportFavoritesExcelList()}
                style   = {{display:'inline-block',padding:'5px',background:'#108ee9',width:'105px',color:'#fff',borderRadius:'5px',marginTop:'20px',cursor:'pointer',textAlign:'center' }}>
                导出收藏夹目录
              </span>

                <Form onSubmit={this.handleSubmit} style={{display:'inline-block',margin:'0 10px',cursor:'pointer'}}>
                   <FormItem >
                      {getFieldDecorator('fileNewName', {
                          rules: [{ message: '选择文件'}]
                        })(
                          <div className='allFiles'>
                             <Upload
                               name           = 'files'
                               showUploadList = {false}
                               action         = '/reagent-front/groupApi/importFavoritesExcel'
                               onChange       = {(info) => this.handleChange(info)}
                              >
                              <Button  type="primary"><Icon type="folder-add" />导入产品清单</Button>
                             </Upload>

                           </div>
                       )}
                   </FormItem>
                </Form>
              <p style={{display:'inline-block',margin:'0 10px',cursor:'pointer',}}><a onClick={()=>this.exportFavoritesExcel()} >点击下载上传模板</a></p>
           </div>
           <p>群组名称：{getMyGroupInfoDate&&getMyGroupInfoDate[0]&&getMyGroupInfoDate[0].sinoOrgName?
               getMyGroupInfoDate[0].sinoOrgName:''}
           </p>
           {
              getMyGroupInfoDate&&getMyGroupInfoDate[0]&&getMyGroupInfoDate[0].orgContactList&&
              getMyGroupInfoDate[0].orgContactList.length?
              getMyGroupInfoDate[0].orgContactList.map((item,index)=>{
                    return(
                     <div key={index} className="group_detail">
                       <i style={{fontStyle:'normal',marginLeft:'12px'}}> 管理员： </i>
                       {item.orgContacts}(联系方式：{item.orgTel})
                     </div>
                    )
                  })
                  : 
                   <div>
                         <i style={{fontSize:'14px',fontStyle:'normal'}}> 管理员：</i>
                         联系方式：
                   </div>
             }

          </div>

      <div className="filter_bar">
       <Form onSubmit={this.handleSubmit} layout="inline">
        <FormItem 	{...formItemLayout} label="产品查询：">
         {getFieldDecorator('goodsName')(
          <Input placeholder="商品编号/名称"/>
         )}
        </FormItem>
        <FormItem>
         <Button type="primary" htmlType="submit" ghost>搜索</Button>
        </FormItem>
       </Form>
      </div>
      <div className="orderList_content">
       <Row className="orderList_content_head">
        <Col span={2}>
         <Checkbox
          onChange = {(e) => this.checkAll(e.target.checked)}
          checked  = {checkAll}
         >
          全选
         </Checkbox></Col>
        <Col span={8}>基本信息</Col>
        <Col span={7}>商品属性</Col>
        <Col span={4}>交易信息</Col>
        <Col span={3}>操作</Col>
       </Row>
      </div>
      {goodsFavoritesList && goodsFavoritesList.length > 0 ?
       <div>
       <div ref='favListTab'>
        {goodsFavoritesList.map((list, index) => {
         return (<ManageFavOperaFloor data={list || []} key={index} delGoods={this.delGoods} checkGoods={this.checkGoods}
                               addCart={this.addCart}></ManageFavOperaFloor>)
        })}
       </div>
        {goodsFavoritesList && goodsFavoritesList.length > 0 ? <div className={this.state.moveToTop ? "gift_cart_settlement moveToTop" : "gift_cart_settlement"}>
       <Checkbox
       onChange = {(e) => this.checkAll(e.target.checked)}
       checked  = {checkAll}
       >
       全选
       </Checkbox>
       {<a onClick={() => this.delSelGoods()}>删除选中商品</a>}

       <button onClick={() => this.handleAddCarts()}>加入购物车</button>
       </div> : <p style={{textAlign: "center", margin: '10px'}}>无数据</p>}
       </div>
       :                                                                                    <p style={{textAlign: "center", margin: '10px'}}>无数据</p>
      }
     </div>


    </Navigation>
   </div>
  )
 }
}

export default connect(({groupFavOpear}) => ({groupFavOpear}), (dispatch) => {
 return {dispatch}
})(Form.create()(groupFavOpear))
