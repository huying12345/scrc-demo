/**
 * 群组主页
 */
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import {connect} from 'dva';
import {BodyHeadImg} from '../../components/Advertising/Advertising'
import Img from '../../components/Img/Img';
import {mianManage,my_account_dynamic_Topimg} from './mianManage.less';
import Search from '../../components/Search/Search';
import Navigation from '../../components/Navigation/Navigation';
import EditableCell from './EditableCell';
import {Form,Breadcrumb,Row,Col,Button,Checkbox,Tabs,Modal,message,Table,Input,Icon,} from 'antd'

const FormItem = Form.Item;


class MianManage extends Component {
 constructor(props) {
  super(props);

  this.state = {
   visible: false,

   contTelData  : '',
   contEmailData: '',
   xyChecked    : false,
  }
 }

 columns = [
     {
        title    : '用户名',
        dataIndex: 'goodsName1',
        key      : 'goodsName1',
        width    : '5%',
    },
    {
        title    : '联系人',
        dataIndex: 'goodsName2',
        key      : 'goodsName2',
        width    : '5%',
    },
  {
    title    : '联系电话',
    dataIndex: 'goodsName3',
    key      : 'goodsName3',
    width    : '5%',
    render   : (text, record) => {
        console.log(record)
        let dataSource = record
      return (<EditableCell
          dataSource = {dataSource}
      />)
    }
  },{
    title    : '操作',
    dataIndex: 'goodsName4',
    key      : 'goodsName4',
    width    : '5%',
    // render: (text, record, index) => {
    //   return (
    //     record.goodsId!='' ?
    //       (
    //         <Popconfirm title="确定要删除吗？" onConfirm={() => this.onDelete(record.goodsId)}>
    //           <a href="#"><Icon type="delete" style={{color:'#3497ce'}} /></a>
    //         </Popconfirm>
    //       ) : null
    //   );
    // },
  }];





handleSubmit = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
     if (!err) {
        let  val={
            email: values.contEmail? values.contEmail: '',
            tel  : values.contTel? values.contTel    : '',
        }
        console.log(val)
        this.props.dispatch({type:'mianManage/getMyGroupInfoEFF',val})
     }
    });
 }
 showModal = () => {
    this.setState({
      visible: true,
    });
  }
// handleOk = (e) => {
//     this.setState({
// 		visible: false,
//     });
//  }
 onXyChecked = () => {
    this.setState({xyChecked: !this.state.xyChecked})
 }
 remindSubmit = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
     if (!err) {
            console.log(this.props.mianManage.checkAll)
        let  val={
            email: values.contEmail? values.contEmail: '',
            // isEmailNotify: values.noticeEmail&&values.noticeEmail== true ? '1': '0',
            isEmailNotify: this.props.mianManage.checkAll&&this.props.mianManage.checkAll==true?'1': '0'
        }
        this.props.dispatch({type:'mianManage/getMyGroupInfoEFF',val})
        this.setState({visible: false});
     }
    });
 }
 //全选
 onCheckAllChange = (e) => {
   console.log( '选择'+e.target.checked )
   this.props.dispatch({type: 'mianManage/checkAll', preload: e.target.checked})
 }

 render() {
    const {getFieldDecorator}            = this.props.form;
    const { getMyGroupInfoData,checkAll} = this.props.mianManage
    const { contTelData,contEmailData }  = this.state;

    const initialTel   = getMyGroupInfoData.memberMobile;
    const initialEmail = getMyGroupInfoData.memberApprovalEmail;
    console.log('传过来checkAll'+checkAll)
   const formItemLayout = {
    labelCol: {
     xs: {span: 24},
     sm: {span: 6},
    },
    wrapperCol: {
     xs: {span: 24},
     sm: {span: 14},
    },
   };
  return (
   <div>
    <Search></Search>
    <Navigation preson={true}>
     <div  className={mianManage}>
      <div className={my_account_dynamic_Topimg}></div>
      {/*头部单行条*/}
      <div className="used_nva_bar">
       <Breadcrumb separator=">" className='security_nav_bar'>
        <Breadcrumb.Item  href="/presonAccunt/myAccount" style={{fontSize:'12px', fontWeight:'normal' }}>我的账户</Breadcrumb.Item>
        <Breadcrumb.Item href="/group/mianManage" style={{fontSize:'16px', fontWeight:'bold' }}>我的群组</Breadcrumb.Item>
       </Breadcrumb>
      </div>
      {/*列表*/}
      <div style={{position:'relative'}}>
         <div className='title'>
             <p><span>公司名称：</span>{getMyGroupInfoData.companyName}</p>

             {getMyGroupInfoData.orgContactList&&getMyGroupInfoData.orgContactList.length?
                getMyGroupInfoData.orgContactList.map((item,index)=>{
                  return(
                   <div key={index}>
                     <i style={{fontSize:'14px',fontStyle:'normal',fontWeight:'bold',marginLeft:'24px'}}> 管理员： </i>
                     {item.orgContacts}(联系方式：{item.orgTel})
                   </div>
                  )
                })
                : 
                 <div>
                       <i style={{fontSize:'14px',fontStyle:'normal'}}> 管理员：</i>
                       联系方式：
                 </div>
             }

              {/* <span>管理员：</span>{getMyGroupInfoData.orgContacts} 联系方式：{getMyGroupInfoData.orgTel} */}

             <b onClick={this.showModal}>审批完成提醒设置</b>
         </div>
         <div style={{overflow:'hidden'}}>
            <Form onSubmit={this.handleSubmit} style={{float:'left',display:'none'}}>
                <table className='tableDeail' cellSpacing='0' >
                    <tbody>
                    <tr>
                        <td colSpan="4" style={{fontWeight: 'bold'}}>我的群名片</td>
                    </tr>
                    <tr>
                        <td  style={{fontWeight: 'bold'}}>用户名</td>
                        <td  style={{fontWeight: 'bold'}}>联系人名称</td>
                        <td  style={{fontWeight: 'bold'}}>联系电话</td>
                        <td  style={{fontWeight: 'bold'}}>联系邮箱</td>
                    </tr>
                    <tr>
                        <td>{getMyGroupInfoData.memberName}</td>
                        <td>{getMyGroupInfoData.memberTruename}</td>
                        <td>
                            <FormItem>
                                {getFieldDecorator('contTel', {setFieldsValue: contTelData,initialValue:initialTel })(
                                    <Input size="large" placeholder="联系电话" />
                                )}
                            </FormItem>
                        </td>
                        <td>
                            <FormItem>
                                {getFieldDecorator('contEmail', {setFieldsValue: contEmailData,initialValue:initialEmail  } )(
                                    <Input size="large" placeholder="联系邮箱" />
                                )}
                            </FormItem>
                        </td>
                    </tr>
                    </tbody>
                </table>
                <Row>
                <FormItem style={{textAlign:'center'}}>
                        <Button type="primary" htmlType="submit" ghost>提交</Button>
                </FormItem>
                </Row>
            </Form>
            <div style={{float:'right',border:'1px solid #ccc',
            minHeight:'300px',width:'250px',position:'absolute',right:'0',top:'70px'}}>
                 <p style={{margin:'10px 0',textAlign:'center',width:'100%',fontSize:'16px',fontWeight:'bold'}} >群组公告</p>
                 <p >{getMyGroupInfoData.notice}</p>
            </div>
            <Modal
                visible  = {this.state.visible}
                closable = {false}
                width    = {440}
                footer   = {false}
                // onOk={this.handleOk}
                        // onCancel={this.handleCancel}
               >
              <div>
                    <p style={{margin:'10px 0',textAlign:'center',width:'100%',borderBottom:'1px solid #ccc',fontWeight:'bold',fontSize:'16px'}}>审批完成提醒设置</p>
                    <Form onSubmit={this.remindSubmit} style={{}}>
                            <FormItem
                            label = "联系邮箱"
                            {...formItemLayout}
                            >
                                {getFieldDecorator('contEmail', {setFieldsValue: contEmailData,initialValue:initialEmail  } )(
                                    <Input size="large" placeholder="联系邮箱" />
                                )}
                            </FormItem>
                            <FormItem style={{textAlign:'center'}}  {...formItemLayout}>
                                {getFieldDecorator('noticeEmail',{
                                } )(
                                    <div>
                                        <Checkbox
                                          checked  = {checkAll}
                                          onChange = {this.onCheckAllChange}
                                           >
                                        </Checkbox> <span>接受邮件提醒</span>
                                    </div>
                                )}
                            </FormItem>
                            <div>
                                <p>说明：</p>
                                <p>可设置最多3个联系邮箱，以分号“；”隔开；用于接收本账户提交的订单确认邮件。</p>
                            </div>
                            <FormItem style={{textAlign:'center'}}>
                                    <Button type="primary" htmlType="submit" ghost>确定</Button>
                            </FormItem>
                    </Form>
              </div>
            </Modal>
         </div>
      </div>
     </div>
    </Navigation>

   </div>
  );
 }
}


export default connect(({mianManage}) => ({mianManage}), (dispatch, own) => {return {dispatch, own}})(Form.create()(MianManage));

