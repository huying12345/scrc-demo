/**
 * 群组管理信息管理
 */
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import {connect} from 'dva';
import {BodyHeadImg} from '../../components/Advertising/Advertising'
import Img from '../../components/Img/Img';
import {address,my_account_dynamic_Topimg} from './informatManage.less';
import {getAreaData} from '../../utils/getArea';
import Search from '../../components/Search/Search';
import Navigation from '../../components/Navigation/Navigation';

import {Form,Breadcrumb,Row,Col,Button,Tree,Checkbox,Tabs,Modal,message,Table,Input,Icon,Popconfirm,Collapse,Select,Cascader,} from 'antd'


const FormItem     = Form.Item;
const { TextArea } = Input;



class AddressList extends Component {
 constructor(props) {
  super(props);
  this.label = '';
  this.area  = getAreaData();
  this.state = {
   visible: false,
   //收货地址初始值
   initAddress: {
    provinceId    : "",
    cityId        : "",
    areaId        : "",
    address       : "",
    orderAddressId: ""
   },

  }
 }

 showModal = () => {
  this.setState({
   visible: true,
  });
 }
 handleCancel = () => {
  this.setState({
   visible: false,
  });
 }


 showAddressModal = (msg) => {
  let info = msg || {};
  this.setState({
   visible    : true,
   initAddress: {
    provinceId    : info.province || "",
    cityId        : info.city || "",
    areaId        : info.county || "",
    fouthAreaId   : info.fourthArea || "",
    address       : info.addressFixedPrefix || "",
    orderAddressId: info.id || "",
   }
  });
 }

//默认地址
 setDefaultAdderss = (info) => {
  console.log(info)
  this.props.dispatch({type: 'address/setDefaultAddressEFF',orderAddressId:info.id});
 }

 saveAddress = (e) => {
  this.props.form.validateFields(["receiverRegion", "address"], (err, values) => {
   if (!err) {
    let value = {
     provinceId    : values.receiverRegion[0],
     cityId        : values.receiverRegion[1],
     areaId        : values.receiverRegion[2],
     fouthAreaId   : values.receiverRegion[3],
     address       : values.address,
     orderAddressId: this.state.initAddress.orderAddressId
    }
    this.props.dispatch({type: 'address/saveAddressEFF', payload: value})
    this.setState({
     visible: false
    });
    this.props.form.resetFields()
   }
  });

 }
 deleteAddress = (v) => {
  Modal.confirm({
   title  : '您确定要删除吗?',
   content: '',
   onOk   : () => {
    this.props.dispatch({type: 'address/deleteAddressEFF',addressId:v.id});
   },
   onCancel() {
    console.log('取消');
   },
  });
 }
 closeAddress = (e) => {
  this.setState({
   visible: false,
  });
  this.props.form.resetFields()
 }
 noticeSubmit = (e) => {
  e.preventDefault();
  this.props.form.validateFields(['notice',],(err, values) => {
      if (!err) {
        console.log(values.values);
        this.props.dispatch({type: 'address/editorGroupNoticeAPIEFF',notice:values.notice});
        this.props.form.resetFields()
      }
   });
 }




 render() {
  const {getFieldDecorator} = this.props.form;
  const {visible}           = this.state;
  const {areaDataList}      = this.props.address;
  const {addressList}       = this.props.address;
  console.log(addressList);
  const formItemLayout = {
   labelCol: {
    xs: {span: 24},
    sm: {span: 6},
   },
   wrapperCol: {
    xs: {span: 24},
    sm: {span: 16},
   },
  };



  const columns = [
   {
   title    : '收货地区',
   dataIndex: 'areaInfo',
   key      : 'areaInfo',
   render   : (list,record)=>{
    let addressprovince = areaDataList.filter(address => {
     return record.province == address.value
    });
    let addresscity = addressprovince[0] && addressprovince[0].children.length > 0 && addressprovince[0].children.filter(address => {
     return record.city == address.value
    });
    let addressarea = addresscity[0] && addresscity[0].children.length > 0 && addresscity[0].children.filter(address => {
     return record.county == address.value
    });
    let addressfouthArea = addressarea[0] && addressarea[0].children.length > 0 && addressarea[0].children.filter(address => {
     return record.fourthArea == address.value
    });
    let addressfouthAreaInfo = addressfouthArea && addressfouthArea[0] ? addressfouthArea[0].label : ""
    return (
     <span>{addressprovince[0].label}&nbsp;&nbsp;&nbsp;{addresscity[0].label}&nbsp;&nbsp;&nbsp;{addressarea[0].label}&nbsp;&nbsp;&nbsp;{addressfouthAreaInfo}</span>
    )
   }
  }, {
   title    : '收货地址固定前缀',
   dataIndex: 'address',
   key      : 'address',
   render   : (list, record) => {
     return <span>{record.addressFixedPrefix}</span>
    }
  },
   {
   title : '操作',
   key   : 'action',
   render: (list, record) => (
    <span>
      {record.isDefault==0 ?
       <Button href="javascript:void(0);" className='edit_btn' onClick={()=>{this.setDefaultAdderss(record)}} style={{ marginRight:'5px'}}>设置默认收货地址</Button>

       : <Button style={{ marginRight:'5px'}} type="primary">默认收货地址</Button>
      }
     <Button href="javascript:void(0);" className='edit_btn' style={{ marginRight:'5px'}} onClick={() => this.showAddressModal(list)}>编辑</Button>
       <Button href="javascript:void(0);" className='edit_btn' style={{ marginRight:'5px'}} onClick={() => this.deleteAddress(record)}>删除</Button>
    </span>

   ),
  }];
  return (
   <div>
    <Search></Search>
    <Navigation preson={true}>
     <div className="myconsult_content">
      <div className={my_account_dynamic_Topimg}></div>
      {/*头部单行条*/}
      <div className="used_nva_bar">
       <Breadcrumb separator=">">
        <Breadcrumb.Item  href="/presonAccunt/myAccount" style={{fontSize:'12px', fontWeight:'normal' }}>我的账户</Breadcrumb.Item>
        <Breadcrumb.Item href="/presonAccount/personalInformation" style={{fontSize:'12px', fontWeight:'normal' }}>我的群组</Breadcrumb.Item>
        <Breadcrumb.Item href="/presonAccount/addressList" style={{fontSize:'16px', fontWeight:'bold' }}>群组信息管理</Breadcrumb.Item>
       </Breadcrumb>
      </div>
      {/*列表*/}
      <div className={address}>

           <Form onSubmit={(e) => this.noticeSubmit(e)}>
              <Row>
              <Col span={3} style={{fontSize:'14px',fontWeight:'bold'}}>群组公告编辑: </Col>
              {/* <span style={{fontSize:'14px',fontWeight:'bold'}}>群组公告编辑:</span> */}
              <Col span={10}>
                <FormItem>
                {getFieldDecorator('notice', {
                })(
                    <TextArea rows={6} />
                )}
                </FormItem>
              </Col>
              <Col span={2}>   <Button type="primary"  htmlType="submit" >提交</Button> </Col>
              </Row>
          </Form>

       <Row type="flex" justify="space-between" style={{height: '50px', lineHeight: '50px'}}>
        <Col className='title' span={4}></Col>
        <Col><Button onClick={this.showAddressModal} icon="environment-o" style={{marginRight: '10px'}} type="primary">新增收货地址</Button></Col>
       </Row>
       <Table columns={columns}
              dataSource = {addressList}
              rowKey     = {record => record.id}
              pagination = {false}

       />

       <Modal
        title        = "新建收货人信息"
        visible      = {visible}
        onOk         = {this.saveAddress}
        onCancel     = {this.closeAddress}
        maskClosable = {false}
        footer       = {
         <Row type="flex" justify="space-around">
          <Col> <Button onClick={this.closeAddress}>取消</Button></Col>
          <Col> <Button onClick={this.saveAddress}
                        style={{color: '#108ee9', border: '1px solid #108ee9'}}>保存</Button></Col>
         </Row>
        }
       >
        <FormItem
         {...formItemLayout}
         label = {<span style={{fontSize: '14px'}}>收货地区</span>}
        >
         {getFieldDecorator('receiverRegion', {
          rules       : [{required: true, message: '请选择所属地区'}],
          initialValue: [this.state.initAddress.provinceId, this.state.initAddress.cityId, this.state.initAddress.areaId,this.state.initAddress.fouthAreaId]
         })(
          <Cascader options={areaDataList} style={{width: '100%'}}/>
         )}
        </FormItem>
        <FormItem
         {...formItemLayout}
         label = {<span style={{fontSize: '14px'}}>收货地址</span>}
        >
         {getFieldDecorator('address', {
          rules       : [{required: true, message: '请填写收货地址固定前缀'}],
          initialValue: this.state.initAddress.address
         })(
          <Input/>
         )}
        </FormItem>
       </Modal>
      </div>

     </div>
    </Navigation>

   </div>
  );
 }
}


export default connect(({address}) => ({address}), (dispatch, own) => {return {dispatch, own}})(Form.create()(AddressList));

