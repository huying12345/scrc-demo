/**
 * Created by leimingtech-lhm on 2017/8/10.
 */
import React , { Component } from 'react';
import { connect } from 'dva';
import {Button,Modal,Form,Row,Col,Tag,Radio,message, Input } from 'antd';
import {price} from './price.less'
import {isLogin} from '../../utils/request'
const FormItem = Form.Item;
/***
 * useClass 传入的样式名称 只能传loginBtn.less中的样式 且只传'-'之前部分
 * pj 商品牌价
 * bz 原币币种
 * bj 原币币价
 * scj 布尔值,传true表示要显示市场价,false表示成交价
 * 示例 <LoginBtn useClass='priceBtn' title={'￥100.00'} clickHandle={function()}/>
 */
class LoginBtn extends Component{
  constructor(props){
    super(props);
    this.state={
      isLogin : isLogin(),
      useClass: this.props.useClass,
      visible : false,
    }
  }

  //需要执行的函数
  clickHandle=()=> {
    if (this.props.isChannelPrice != 0) {
      if (this.props.clickHandle) {
        this.props.clickHandle();
      }
    }
  }
  showModal = () => {
    this.setState({
      visible: true,
    });
  }

  handleCancel = (e) => {
    this.setState({
      visible: false,
    });
  }

  goLogin = () => {
    window.location.href = "/login"
  }


 handleOk = (e) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        console.log(values.remark);
        if (!values.remark || values.remark.trim() == '') {
          message.info('备注信息不能为空');
          return;
        }
        if (!values.applyUser || values.applyUser.trim() == '') {
          message.info('联系人姓名不能为空');
          return;
        }
        if (!values.tel || values.tel.trim() == '') {
          message.info('联系人手机号不能为空');
          return;
        }
        if (!/^((13[0-9])|(14[5|7])|(15([0-3]|[5-9]))|(18[0,5-9]))\d{8}$/.test(values.tel.replace(/\s/g,''))) {
          message.info('手机号格式不正确');
          return;
        }
        this.props.dispatch({ type:'app/applyChannelEFF' , goodsId:this.props.goodsId, ...values });
        this.setState({
          visible: false,
        });
      }
    });
  }


  render(){
    const formItemLayout = {
      labelCol  : { span: 6 },
      wrapperCol: { span: 14 },
    };
   // console.log(typeof(this.props.pj));

/***
 * useClass 传入的样式名称 只能传loginBtn.less中的样式 且只传'-'之前部分
 * pj 商品牌价
 * bz 原币币种
 * bj 原币币价
 * scj 布尔值,传true表示要显示市场价,false表示成交价
 * 示例 <LoginBtn useClass='priceBtn' title={'￥100.00'} clickHandle={function()}/>
 */

   const { getFieldDecorator } = this.props.form;
   let   { visible }           = this.state;
    return(
      <div className={price} >
        <div className={this.state.useClass+'-'+this.state.isLogin.toString()} onClick={this.clickHandle}>
         {Number(this.props.scj) ?
           (Number(this.props.pj)> 0 ?
            // (Number(this.props.pj).toFixed(2) + "  CNY")
            ( "￥"+Number(this.props.pj).toFixed(2))
            : (this.props.bj>0&&this.props.bz ? (Number(this.props.bj) + this.props.bz)
            : <span>请询价</span> ))
            // : (Number(this.props.pj) > 0 ? (this.state.isLogin ? (Number(this.props.pj).toFixed(2) + "  CNY")
            : (Number(this.props.pj) > 0 ? (this.state.isLogin ?  "￥"+(Number(this.props.pj).toFixed(2))
            : <span onClick={this.goLogin}>登录可见</span>)
            : <span>请询价</span>)}
        </div>

      </div>
    )
  }
}

export default connect(({app})=>({app}),(dispatch,own)=>{return {dispatch,own}})(Form.create()(LoginBtn));

