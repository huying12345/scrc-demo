
import React , { Component } from 'react';
import { connect } from 'dva';
import {Button,Modal,Form,Row,Col,Tag,Radio,message, Input } from 'antd';
import {price} from './price.less'
import {isLogin} from '../../utils/request'
/***
 * useClass 传入的样式名称 只能传loginBtn.less中的样式 且只传'-'之前部分
 * pj 商品牌价
 * bz 原币币种
 * bj 原币币价
 * scj 布尔值,传true表示要显示市场价,false表示成交价
 * 示例 <LoginBtn useClass='priceBtn' title={'￥100.00'} clickHandle={function()}/>
 */
class LoginBtnPrice extends Component{
  constructor(props){
    super(props);
    this.state={
      isLogin : isLogin(),
      useClass: this.props.useClass,

    }
  }
  //需要执行的函数
  clickHandle=()=> {
    if (this.props.isChannelPrice != 0) {
      if (this.props.clickHandle) {
        this.props.clickHandle();
      }
    }
  }
  goLogin = () => {
    window.location.href = "/login"
  }
  render(){

   const memberType = localStorage.getItem("memberType") ;

    return(
      <div className={price} >
        <div onClick={this.clickHandle}>
         {
          Number(this.props.scj) ?
          (this.state.isLogin?
              (memberType=='0'?
                 (Number(this.props.pj)> 0?
                     <div>
                       <span style={{color:'#000',opacity:'0.6'}}> 市场价：</span>{Number(this.props.pj).toFixed(2)}
                     </div>
                     :                                      ''
                 )
                 : 
                 (Number(this.props.pj)> 0?
                    <div>
                       <span style={{color:'#000',opacity:'0.6'}}> 市场价：</span>{Number(this.props.pj).toFixed(2)}
                    </div>
                     :                                      ''
                 )
              )
            : 
             (memberType=='0'?
                  (Number(this.props.pj)> 0?
                      <div>
                        <span style={{color:'#000',opacity:'0.6'}}> 市场价：</span>{Number(this.props.pj).toFixed(2)}
                      </div>
                      : 
                       <div><span style={{color:'#000',opacity:'0.6'}}> 市场价：</span>请询价</div>

                  )
                  : 
                  (Number(this.props.pj)> 0?
                     <div>
                        <span style={{color:'#000',opacity:'0.6'}}> 市场价：</span>{Number(this.props.pj).toFixed(2)}
                     </div>
                      : 
                      <div><span style={{color:'#000',opacity:'0.6'}}> 市场价：</span>请询价</div>
                  )
               )

            )
            : 
            (this.state.isLogin?
              (memberType=='0'?
                  null
                 : 
                 (Number(this.props.pj)> 0?
                    <div>
                         <span style={{color:'#000',opacity:'0.6'}}> 成交价：</span>{Number(this.props.pj).toFixed(2)}
                    </div>
                     :                                      ''
                 )
              )
               :                                      null
             )


         }

        </div>
      </div>
    )
  }
}

export default connect(({app})=>({app}),(dispatch,own)=>{return {dispatch,own}})(LoginBtnPrice);

