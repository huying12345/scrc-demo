/**
 * Created by 10400 on 2017/8/14.
 * 商城首页页面-navleft
 */
import React , { Component } from 'react';
import { Carousel, Icon, Menu, Dropdown, Popover, Button} from 'antd';
import { fenlei_every, navigation, nav, left_right_layout, preson_my_nav } from './Navigation.less';
import Img from '../../components/Img/Img';
import { routerRedux, Link } from 'dva/router';
//import Sidebar from '../Sidebar/Sidebar';
import { connect ,Row, Col,} from 'dva';
const SubMenu       = Menu.SubMenu;
const MenuItemGroup = Menu.ItemGroup;



class  Navigation extends Component{
  constructor(props){
    super(props);
    this.state={
      open    : false,
      openKeys: [ '0' ],
      // openKeys:['0','1','2','3','4','5','6','7','8','9','10','20' ],
      openKeys2: ['0','1','2','3','4','5','6','7','8','9','10','20' ],

      data  : [],
      ifShow: false,

    }
  }


  rootSubmenuKeys = ['0','1','2','3','4','5','6','7'];
  onOpenChange    = (openKeys) => {
    const latestOpenKey = openKeys.find(key => this.state.openKeys.indexOf(key) === -1);
    if (this.rootSubmenuKeys.indexOf(latestOpenKey) === -1) {
      this.setState({ openKeys });
    } else {
      this.setState({
        openKeys: latestOpenKey ? [latestOpenKey]: [],
      });
    }
  }
  rootSubmenuKeys2 = ['10','11','12','13','14','15','16','17'];
  onOpenChange2    = (openKeys2) => {
    const latestOpenKey = openKeys2.find(key => this.state.openKeys2.indexOf(key) === -1);
    if (this.rootSubmenuKeys.indexOf(latestOpenKey) === -1) {
      this.setState({ openKeys2 });
    } else {
      this.setState({
        openKeys2: latestOpenKey ? [latestOpenKey]: [],
      });
    }
  }


  onClickJump=(type,parentId,path,inputPath,articleId,headImage,navId)=>{

   if(parentId=='1'){
      parentId = '';
   }

   if(type=='-1'){

     if(path=='/'){
      // window.location.href = '/';
      this.props.dispatch(routerRedux.push(`/`));
     }
     console.log('不跳转');
      // this.props.dispatch({ type: 'getArticleContentEFF',val: obj});
         //内部跳转navUrl
      if(!!path&&path!=''){
          console.log(path);
            let values = "parentId=" + parentId+"";
           this.props.dispatch(routerRedux.push(`${path}?${values}`));
      }else{
        console.log('不跳转')
      }
   }else if(type=='0'){

      //  跳转外部
      let outlinkPath = window.open('about:blank');
      console.log('跳转url');
       if(!!inputPath&&inputPath!=''){
         console.log(inputPath);
         outlinkPath.location.href = inputPath
       }
      //跳转url动态页面
        // if(!!path&&path!=''){
        // let values = "parentId=" + parentId+"";
        // this.props.dispatch(routerRedux.push(`${path}?${values}`));
        // var obj={};
        // var name,value;
        // var str=window.location.href;
        // var num=str.indexOf("?");
        // str=str.substr(num+1);
        // var arr={};
        // arr=str.split("&");
        // for(var i=0;i<arr.length;i++){
        //   var Cstr=arr[i]
        //   var Barr=Cstr.split("=")
        //   obj[Barr[0]]=decodeURI(Barr[1])
        // }
    //  console.log(obj)
    //   this.props.dispatch({type:'app/getNavSideEFF',val: obj})
    //  }else{
    //    console.log('不跳转');
    //  }

   }else if(type=='1'){
    console.log('跳转图片');
   }else if(type=='2'){
      if(articleId==''||articleId=='undefined'){
        console.log('文章没有articleId')
      }else{
        // let obj1={parentId:parentId,articleId:articleId,navType:navId};
        // let obj2={parentId:parentId,articleId:articleId}
        let values = ''
        if(navId!=1){
         values = "parentId=" + parentId +"&articleId=" + articleId+"&navType="+navId+"";
        }else{
          values = "parentId=" + parentId +"&articleId=" + articleId+"";
        }
        this.props.dispatch(routerRedux.push(`${path}?${values}`));

        // this.props.dispatch({type:'app/getNavSideEFF',val: obj2})
        // this.props.dispatch({type:'app/getNavSixEFF',val: obj1});
        // this.props.dispatch({ type: 'app/getArticleContentEFF',val: obj1});

      }
   }

  }

  onClickJump2=(parentId,type,path,inputPath,articleId,headImage,navId)=>{

    if(parentId=='1'){
      parentId = '';
   }

   if(type=='-1'){
     //什么都不跳
     console.log("什么都不跳转")

     if(!!path&&path!=''){
      console.log(path);
        let values = "parentId=" + parentId+"";
       this.props.dispatch(routerRedux.push(`${path}?${values}`));
     }

   }else if(type=='0'){
       let outlinkPath = window.open('about:blank');

       console.log('跳转url');
        if(!!inputPath&&inputPath!=''){
          console.log(inputPath);
          outlinkPath.location.href = inputPath
        }

         //跳转url动态页面
      //  if(!!path&&path!=''){
      //  //   let values = "parentId=" + parentId+"";
      //     this.props.dispatch(routerRedux.push(`${path}?`));
      //     var obj={};
      //     var name,value;
      //     var str=window.location.href;
      //     var num=str.indexOf("?");
      //     str=str.substr(num+1);
      //     var arr={};
      //     arr=str.split("&");
      //     for(var i=0;i<arr.length;i++){
      //       var Cstr=arr[i]
      //       var Barr=Cstr.split("=")
      //       obj[Barr[0]]=decodeURI(Barr[1])
      //     }
      // //  console.log(obj)
      //   this.props.dispatch({type:'app/getNavSideEFF',val: obj})
      //  }else{
      //    console.log('不跳转');
      //  }

   }else if(type=='1'){
      console.log('跳转图片');
   } else if(type=='2'){
      if(articleId==''||articleId=='undefined'){
          console.log('文章没有articleId')
      }else{
         let obj1 = {parentId:parentId,articleId:articleId,navType:navId};
         let obj2 = {parentId:parentId,articleId:articleId}
        console.log()
        let values = ''
        if(navId!=1){
         values = "parentId=" + parentId +"&articleId=" + articleId+"&navType="+navId+"";
        }else{
          values = "parentId=" + parentId +"&articleId=" + articleId+"";
        }
        this.props.dispatch(routerRedux.push(`${path}?${values}`));

      }
   }

  }

 //跳转到静态页面
  goArticleDetail=(articleId)=>{
   // console.log(articleId)
   // console.log(e.target);
   this.props.dispatch({ type: 'app/getArticleContentEFF',val:articleId});
  }


  componentDidMount(){
    if(!this.props.app.navList.length>0){
     this.props.dispatch({ type: 'app/getNavEFF'});
    }
   if(!this.props.app.goodsClass.length>0){
    this.props.dispatch({ type: 'app/getGoodsClassEFF'});
   }

  }

  Expand = () => {
    this.setState({
      open: !this.state.open
    })
  };

  navmap=(arr)=>{

  let mewArr = arr.map((v,i,a)=>{
    if(v.nextArr){
      return <SubMenu style={{ padding:'0px' }} key={v.id} title={
        <Link to={v.navUrl} className="nav_link" activeClassName='actived_link' >{v.title} <Icon type="down" /></Link>
      }>
        {this.navmap(v.nextArr)}
      </SubMenu>
    }
      return <Menu.Item style={{ padding:'0px' }} key={v.id}>
        <Link to={v.navUrl} className="nav_link" activeClassName='actived_link' >{v.title}</Link>
        </Menu.Item>
    })
    return mewArr
  }



 onVisiable = () => {
  // this.props.dispatch(routerRedux.push(`/product/productsort`));
  const {visiable=false } = this.props;

  if(!visiable){
   console.log(visiable)
   if(this.state.ifShow){
    this.setState({
     ifShow: false
    })
   }else {
    this.setState({
     ifShow: true
    })
   }
  }
 }


  render (){
   const { goodsClass:data, navList, classId, navStaticList, navStaticListLeft=[],navlistSide } = this.props.app;
   const { leftComponent, preson=false, leftComponentPreson, visiable=false ,isPreson=true }    = this.props;
   const rootSubmenuKeys                                                                        = ['0','1','2','3','4','5','6','7'];
   const memberType                                                                             = localStorage.getItem("memberType") ;
   const saleAssistant                                                                          = localStorage.getItem("saleAssistant") ;    //销售助理
   const assistantMobile                                                                        = localStorage.getItem("assistantMobile") ;  //销售助理联系方式
   const saler                                                                                  = localStorage.getItem("saler") ;            // 销售员：
   const salerMobile                                                                            = localStorage.getItem("salerMobile") ;      // /销售员联系方式
   const salerQQ                                                                                = localStorage.getItem("salerQQ") ;
   const assistantQQ                                                                            = localStorage.getItem("assistantQQ") ;
   const memberRole                                                                             = localStorage.getItem("memberRole") ;       //管理权限判断

    let newData = data.slice(0,6);
    return (
      <div
        //style={{borderBottom:"2px solid #3497ce"}}
      >
        <div className={ navigation }>
          <div className="nav_left">
            <a target='_blank' className="fenlei" onClick={this.onVisiable} href={`/product/productsort`}  >商品分类</a>
            <div className={ `${ visiable==true ? "visiable" :this.state.ifShow ?'hover_block' :'hover' } ${fenlei_every}` } >

              {
                newData ?
                  newData.map((bigClass,index)=>{
                    return (
                      <div className={`fenlei${index} classification_content`} key={index}>
                        <div to={`/home/PeoductSearch/gcIdSearch/${bigClass.gcId}`}>
                          <div className="fl_title">
                            <div className="fl_title_top"><a href={`/goodsDetail/relevantGoods/gcFirstIdSearch/${bigClass.gcId}`}>{bigClass.gcName}</a></div>
                            <div className="fl_title_bottom">
                              {bigClass.classList.map((v,i)=>{
                                return (<a key={i} href={`/goodsDetail/relevantGoods/gcSecondIdSearch/${v.gcId}`}>{v.gcName}</a>)
                              })}
                            </div>
                          </div>
                        </div>


                        <div className="fl_hover_show">
                          <div className="cat_pannel">
                            <div className="hd_sort_list">
                              {bigClass.classList.map((smallClass,index)=>{
                                return(
                                  <dl key={index}>
                                    <dt><a className='hd_sort_list_erji' href={`/goodsDetail/relevantGoods/gcSecondIdSearch/${smallClass.gcId}`}>{smallClass.gcName}></a> </dt>
                                    <dd>

                                        {smallClass.classList.map((good,index)=>{
                                          if(classId && classId == good.gcName){
                                            return (<a key={index} style={{color:'#3497ce'}} href={`/goodsDetail/relevantGoods/gcIdSearch/${good.gcId}`}>{good.gcName}</a>)
                                          }else{
                                            return (<a key={index} href={`/goodsDetail/relevantGoods/gcIdSearch/${good.gcId}`} className="gc3">{good.gcName}</a>)
                                          }
                                        })}
                                    </dd>
                                  </dl>
                                )
                              })}
                            </div>

                          </div>
                        </div>

                      </div>
                    )
                  })  : null }

            </div>
          </div>
          <div className="nav_right">

            <Menu  mode="horizontal"
                   openKeys = {this.state.openKeys}
                  // defaultOpenKeys={['0','1' ,'2','3','4','5','6','7','8','9','10']}
                   onOpenChange = {this.onOpenChange}
                   >
              { !!navList&&navList.length>0 && navList.map((list,index)=>{
                let path      = list.navUrl;
                let inputPath = list.url;
                let type      = list.type;
             //   let newpath = path.replace("http://10.37.1.101","");
                let tiaoNavTitle = list.navTitle;
                let parentId     = list.navId;
                let articleId    = list.articleId;
                let headImage1   = list.headImage;
                let navId        = '1';

                  return (
                      <SubMenu key={list.navId}
                            title={
                                <i  className='title_nav'
                                  onClick={()=>this.onClickJump(type,parentId,path,inputPath,articleId,headImage1,navId)}>
                                      <span>{list.navTitle}
                                        {
                                          list.childrenList.length>0 ?
                                          <Icon type="down"/>: null
                                        }
                                      </span>
                                  </i>
                                  }
                       >
                      { !!list && list.childrenList.length>0 ? list.childrenList.map((item,ind2)=>{
                        let path       = item.navUrl;
                        let inputPath  = item.url;
                        let type       = item.type;
                        let articleId  = item.articleId;
                        let headImage2 = item.headImage;
                        let navId      = '1'
                        return(
                        <SubMenu key={item.navId}
                            title={
                              <i
                                onClick   = {()=>this.onClickJump(type,parentId,path,inputPath,articleId,headImage2,navId)}
                                className = 'title_nav_two'
                                style     = {{margin:'0',padding:'0',fontStyle:'normal'}}
                               >
                                {item.navTitle}
                              </i>
                             } >
                             { !!item && item.childrenList.length>0 ? item.childrenList.map((goods,ind3)=>{
                                let path       = goods.navUrl;
                                let inputPath  = goods.url;
                                let type       = goods.type;
                                let articleId  = goods.articleId;
                                let headImage3 = goods.headImage;
                                let navId      = '1'
                                return(
                                  <SubMenu key={goods.navId}
                                      title={
                                        <i
                                          onClick = {()=>this.onClickJump(type,parentId,path,inputPath,articleId,headImage3,navId)}
                                          style   = {{margin:'0',padding:'0',fontStyle:'normal',minWidth:'136px',display:'inline-block'}}
                                        >
                                          {goods.navTitle}
                                        </i>
                                      } >

                                        { !!goods&&goods.childrenList ? goods.childrenList.map((nav,indx4)=>{
                                          let path       = nav.navUrl;
                                          let inputPath  = nav.url;
                                          let type       = nav.type;
                                          let articleId  = nav.articleId;
                                          let headImage4 = nav.headImage;
                                          let navId      = '1'
                                          return(
                                            <SubMenu key={nav.navId}
                                              title={
                                                <i
                                                onClick = {()=>this.onClickJump(type,parentId,path,inputPath,articleId,headImage4,navId)}
                                                style   = {{margin:'0',padding:'0',fontStyle:'normal',minWidth:'136px',display:'inline-block'}}
                                                >
                                                  {nav.navTitle}
                                                </i>
                                              } >
                                                  { !!nav&&nav.childrenList&&nav.childrenList.length>0 ? nav.childrenList.map((nav5,indx5)=>{
                                                      let path       = nav5.navUrl;
                                                      let inputPath  = nav5.url;
                                                      let type       = nav5.type;
                                                      let articleId  = nav5.articleId;
                                                      let headImage5 = nav5.headImage;
                                                      let navId      = nav5.navId
                                                            return (
                                                              <Menu.Item key={nav5.navId} >
                                                                <i
                                                                  onClick = {()=>this.onClickJump(type,parentId,path,inputPath,articleId,headImage5,navId)}
                                                                  style   = {{margin:'0',padding:'0',fontStyle:'normal',minWidth:'136px',display:'inline-block'}}
                                                                  >{nav5.navTitle}</i>
                                                              </Menu.Item>
                                                              )

                                                        }) :null
                                                  }
                                            </SubMenu>
                                          )
                                        }):null
                                      }


                                  </SubMenu>
                                )
                               }) :null
                            }


                          </SubMenu>)
                        }) :null
                      }
                    </SubMenu>
                  )
              })
              }
           </Menu>
          </div>
        </div>
        <div style={{ width:'1366px', border:'1px solid #3497ce', margin:'-1px auto 0px auto' , position:"relative", zIndex:'100'}}></div>
        <div style={{display:isPreson ==true ? 'flex' : 'none'}} className={left_right_layout}>
          {
            preson==false ?
              <div className='layout_left'>
                  {
                    leftComponent ? leftComponent: 
                    <div className='layout_navLeft'>
                      <Menu
                       mode     = "inline"
                       openKeys = {this.state.openKeys2}
                      //  onOpenChange={this.onOpenChange2}
                       defaultOpenKeys = {['0','1' ,'2','3','4','5','6','7','8','9','10']}
                       >
                        {navlistSide.map((list,index)=>{
                          let path         = list.navUrl;
                          let parentId     = list.navId
                          let inputPath    = list.url;
                          let type         = list.type;
                          let tiaoNavTitle = list.navTitle
                          let articleId    = list.articleId;
                          let headImage1   = list.headImage;
                          let navId        = '1'
                            return (
                                <SubMenu
                                   key   = {index}
                                   title = {
                                            <i
                                             style   = {{margin:'0',padding:'0',fontStyle:'normal'}}
                                             onClick = {()=>this.onClickJump2(parentId,type,path,inputPath,articleId,headImage1,navId,navId)}
                                              >
                                                <span>{list.navTitle}</span>
                                            </i>
                                            }
                                      >
                            { list.childrenList.length>0 ? list.childrenList.map((item,ind2)=>{
                              let path       = item.navUrl;
                              let inputPath  = item.url;
                              let type       = item.type;
                              let articleId  = item.articleId;
                              let headImage2 = item.headImage;
                              let navId      = '1'
                              return(
                              <SubMenu key={ind2}
                                  title={
                                    <i

                                    onClick   = {()=>this.onClickJump2(parentId,type,path,inputPath,articleId,headImage2,navId)}
                                    className = 'title_nav_two' style = {{margin:'0',padding:'0',fontStyle:'normal'}}>
                                    {item.navTitle}
                                    </i>
                                  }
                                  >
                                  { !!item && item.childrenList.length>0 ? item.childrenList.map((goods,ind3)=>{
                                      let path       = goods.navUrl;
                                      let inputPath  = goods.url;
                                      let type       = goods.type;
                                      let articleId  = goods.articleId;
                                      let headImage3 = goods.headImage;
                                      let navId      = '1'
                                      return(
                                        <SubMenu key={ind3}
                                            title={
                                              // <Popover title="Title">
                                                <i
                                                title   = {goods.navTitle}
                                                onClick = {()=>this.onClickJump2(parentId,type,path,inputPath,articleId,headImage3,navId)}
                                                style   = {{margin:'0',padding:'0',fontStyle:'normal'}}
                                                >
                                                  {goods.navTitle}
                                                </i>
                                              // </Popover>
                                            }
                                        >
                                          { !!goods&&goods.childrenList ? goods.childrenList.map((nav,ind4)=>{
                                            let path       = nav.navUrl;
                                            let inputPath  = nav.url;
                                            let type       = nav.type;
                                            let articleId  = nav.articleId;
                                            let headImage4 = nav.headImage;
                                            let navId      = nav.navId
                                                  return (
                                                    <Menu.Item key={ind4+''+ind3+ind2+index-0} >
                                                        <i
                                                          onClick = {()=>this.onClickJump2(parentId,type,path,inputPath,articleId,headImage4,navId)}
                                                          style   = {{margin:'0',padding:'0',fontStyle:'normal'}}
                                                          >{nav.navTitle}</i>
                                                    </Menu.Item>
                                                  )
                                              }) :null
                                          }
                                        </SubMenu>
                                      )
                                      }) :null
                                    }

                              </SubMenu>)
                              }) :null
                            }
                          </SubMenu>
                         )
                        })
                        }
                      </Menu>
                    </div>
                   }
              </div>: 
              <div className='layout_left_preson'>
                {
                  leftComponentPreson ? leftComponentPreson: 
                    <div className={preson_my_nav}>
                      <div className="my_account">
                        <div><Link activeClassName='actived_link' to="/presonAccunt/myAccount">我的账户</Link></div>
                      </div>

                      <div className="my_nav_list_all">

                        <div className="my_nav_list">
                          <div className="my_nav_title">
                            <div className="my_nav_title_img order_img"></div><div>我的交易</div>
                          </div>
                          <div className="my_nav_link_list">
                            <Link activeClassName='actived_link' to="/personOrder/myOrder">我的订单</Link>
                            <Link activeClassName='actived_link' to="/personOrder/myConsultList">我的询价单</Link>
                            {/*  询价单列表
                              <Link activeClassName='actived_link' to="/personOrder/consultList">我的询价单</Link>
                            */}
                            <Link activeClassName='actived_link' to="/personOrder/cart">我的购物车</Link>
                            <Link activeClassName='actived_link' to="/personOrder/favList">我的收藏夹</Link>

                              <Link activeClassName='actived_link' to="/personOrder/order">常购清单</Link>
                              {
                               memberType =='0'?
                                  <Link activeClassName='actived_link' to="/personOrder/returnApply">售后申请</Link>
                                 :                                                               null
                              }


                          </div>
                        </div>

                        <div className="my_nav_list">
                          <div className="my_nav_title">
                            <div className="my_nav_title_img Integral_img"></div><div>我的积分</div>
                          </div>
                          <div className="my_nav_link_list">
                          <Link activeClassName='actived_link' to="/customservice?parentId=6&articleId=a9d8438e63f54f96986e93f559701b30">兑换说明</Link>
                            <Link target="_blank" to="/reagent-front/points/index">积分商城</Link>
                            {/* <Link activeClassName='actived_link' to="/personIntegral/giftShoppingCart">礼品购物车</Link> */}
                            <Link activeClassName='actived_link' to="/presonAccount/point">积分历史记录</Link>
                          </div>
                        </div>

                        <div className="my_nav_list">
                          <div className="my_nav_title">
                            <div className="my_nav_title_img Info_img"></div><div>我的信息</div>
                          </div>
                          <div className="my_nav_link_list">

                            <Link activeClassName='actived_link' to="/presonAccount/personalInformation">基本信息</Link>

                            {
                                memberType =='3'?
                                 null: <Link activeClassName='actived_link' to="/presonAccount/addressList">收货信息</Link>
                            }
                            {
                                memberType !='0'?
                              null: <Link activeClassName='actived_link' to="/presonInvoice/invoiceInfo">开票信息</Link>
                            }
                            {
                                memberType =='0'?
                                <Link activeClassName='actived_link' to="/presonAccount/deposit">预存款信息</Link>
                               :                                                               null
                            }

                           <Link activeClassName='actived_link' to="/presonAccount/intelligentUp">资质上传</Link>
                           {/*<Link activeClassName='actived_link' to="/presonAccount/managerTemplates">采购模板管理</Link>*/}
                           <Link activeClassName='actived_link' to="/presonAccount/presonAccount">账户安全性</Link>
                           <Link activeClassName='actived_link' to="/presonAccount/purchaseTemplet">采购模板管理</Link>

                          </div>
                        </div>
                     { memberType&&memberType =='3'?
                       <div className="my_nav_list">
                          <div className="my_nav_title">
                            <div className="my_nav_title_img group_img"></div><div>我的群组</div>
                          </div>
                          <div className="my_nav_link_list">
                            <Link activeClassName='actived_link' to="/group/mianManage">群组主页</Link>
                            {memberRole.indexOf('2')=='-1'?
                                null: 
                                <Link activeClassName='actived_link' to="/group/manage-order">群组审批订单</Link>
                            }
                            {memberRole.indexOf('1')=='-1'&&memberRole.indexOf('4')=='-1'?
                                null: 
                                <Link activeClassName='actived_link' to="/group/opproval-order">群组订单管理</Link>
                            }
                            {memberRole.indexOf('1')=='-1'?
                                null: 
                               <p>
                                  <Link activeClassName='actived_link' to="/group/address">群组信息管理</Link>
                                  <Link activeClassName='actived_link' to="/group/manage-member">群组成员管理</Link>
                               </p>
                            }
                            <Link activeClassName='actived_link' to="/group/manageFav">群组收藏夹</Link>
                            {memberRole.indexOf('1')=='-1'?
                                null: 
                               <p>
                                  <Link activeClassName='actived_link' to="/group/opproval">群组审批流管理</Link>
                                  <Link activeClassName='actived_link' to="/group/manage">群组项目管理</Link>
                                  <Link activeClassName='actived_link' to="/group/fund">群组经费管理</Link>
                               </p>
                            }
                          </div>
                        </div>
                        :                                                             null
                       }
                      </div>
                      {
                        memberType =='0'?
                         <div className="my_saler">
                           <div><span style={{ color:'#000' }}>销售员：</span>中国试剂网</div>
                           <div><span style={{ color:'#000' }}>会员热线：</span>021-63210123</div>
                           <div><span style={{ color:'#000' }}>联系传真：</span>021-63290778</div>
                         </div>
                         : 
                         <div className="my_saler">
                           {saler&&saler!=''&&saler!='undefined'?
                               <div><span style={{ color:'#000' }}>销售员：</span>{saler}</div>
                                 :                                        null
                           }
                           {salerMobile&&salerMobile!=''&&salerMobile!='undefined'?
                               <div><span style={{ color:'#000' }}>联系方式：</span>{salerMobile}</div>
                                 :                                        null
                           }
                           {salerQQ&&salerQQ!=''&&assistantQQ!='undefined'?
                                <div><span style={{ color:'#000' }}>销售员QQ：</span>{salerQQ}</div>
                                :                                        null
                           }
                           {saleAssistant&&saleAssistant!=''&&saleAssistant!='undefined'?
                              <div><span style={{ color:'#000' }}>销售助理：</span>{saleAssistant}</div>
                                :                                        null
                           }
                           {assistantMobile&&assistantMobile!=''&&assistantMobile!='undefined'?
                              <div><span style={{ color:'#000' }}>联系方式：</span>{assistantMobile}</div>
                                :                                        null
                           }
                           {assistantQQ&&assistantQQ!=''&&assistantQQ!='undefined'?
                                <div><span style={{ color:'#000' }}>销售助理QQ：</span>{assistantQQ}</div>
                                :                                        null
                           }

                         </div>
                      }
                    </div>
                }
              </div>
          }
          <div className={ preson==false ? 'layout_right': 'layout_right_preson' }>{ this.props.children }</div>
        </div>


      </div>


    )
  }
}
export default connect(({app})=>({app}),(dispatch,own)=>{return {dispatch,own}})(Navigation);
