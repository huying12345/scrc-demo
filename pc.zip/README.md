# leiming-dva



---

阿里iconfont图标本地化步骤：
 1、把文件夹\fonts复制到node_modules\antd\lib\style\core\目录下。


生产环境 dva/index.html

记录：
 dll:307kb
 dll:311kb



https://github.com/jasonslyvia/react-lazyload img懒加载

## Getting Started
Install dependencies.

```bash
$ npm install
```

Start server.

```bash
$ npm start
```


  207.68 KB  dist\index.js
  164.03 KB  dist\2.async.js
  62.72 KB   dist\0.async.js
  48.99 KB   dist\6.async.js
  46.64 KB   dist\3.async.js
  46.46 KB   dist\4.async.js
  44.11 KB   dist\index.css
  43.51 KB   dist\7.async.js
  43.01 KB   dist\9.async.js
  42.45 KB   dist\5.async.js
  28.7 KB    dist\8.async.js
  21.98 KB   dist\10.async.js
  10.59 KB   dist\11.async.js

If success, app will be open in your default browser automatically.
